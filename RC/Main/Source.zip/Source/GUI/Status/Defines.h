// Copyright 2012 Peter Stegemann

#ifndef GUI_STATUS_H
#define GUI_STATUS_H

#define GUI_STATUS_MAIN_FONT			FONT::FID_Normal

#endif
