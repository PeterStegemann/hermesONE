// Copyright 2008 Peter Stegemann

#ifndef GUI_SETUP_H
#define GUI_SETUP_H

#define GUI_SETUP_BLINK_COUNT		140

#define GUI_SETUP_MAIN_FONT			FONT::FID_Normal

#endif
