// Copyright 2012 Peter Stegemann

#ifndef GUI_SETUP_TIMELABEL_H
#define GUI_SETUP_TIMELABEL_H

#include "Label.h"

class GUI_Setup_TimeLabel : public GUI_Setup_Label
{
	private:
		char timeLabelText[ 7];

	public:
		void SetTime( int16_t Time);
};

#endif
