// Copyright 2008 Peter Stegemann

#include "Select.h"

#include "Defines.h"
#include "Gauge.h"
#include "Label.h"
#include "Marker.h"

#include "Main/Setup.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"

bool GUI_Setup_Select::DoSelect( int8_t* Value, int8_t LowerLimit, int8_t UpperLimit,
								 int8_t StepWidth, GUI_Setup_Marker* Marker, GUI_Setup_Label* Label,
								 void* Object, void ( *Update)( void* Object),
								 void ( *UpdateLabel)( void* Object, GUI_Setup_Label* Label,
								 int8_t Value))
{
	int16_t NewValue = *Value;

	NewValue -= NewValue % StepWidth;

	// Saves some write cycles with this flag.
	bool ValueChanged = false;

	uint8_t BlinkCount = 0;

	Marker->ForegroundColor = LCD_65K_RGB::Red;
	Marker->Display();

	Label->SetInverted( true);
	Label->Display();

	bool Exit = false;

	while( Exit == false)
	{
		if( Update != NULL)
		{
			Update( Object);
		}

		int8_t RotarySelect;
		uint8_t RotaryButton;

		GLOBAL.InputService.GetRotary( &RotarySelect, &RotaryButton);

		if( RotaryButton > 0)
		{
			Exit = true;
		}

		// Set new position.
		if( RotarySelect != 0)
		{
			ValueChanged = true;

			NewValue += RotarySelect * StepWidth;

			if( NewValue > UpperLimit)
			{
				NewValue -= (( int16_t) UpperLimit - ( int16_t) LowerLimit) + StepWidth;
			}
			else if( NewValue < LowerLimit)
			{
				NewValue += (( int16_t)  UpperLimit - ( int16_t) LowerLimit) + StepWidth;
			}

			*Value = NewValue;

			// Refresh label.
			UpdateLabel( Object, Label, *Value);
		}

		// Blink cursor.
		BlinkCount++;

		if( BlinkCount == ( GUI_SETUP_BLINK_COUNT / 2))
		{
			Label->SetInverted( false);
			Label->Display();
		}
		else if( BlinkCount == GUI_SETUP_BLINK_COUNT)
		{
			Label->SetInverted( true);
			Label->Display();

			BlinkCount = 0;
		}
	
		UTILITY::Pause( 5);
	}

	// Unselect.
	Marker->ForegroundColor = LCD_65K_RGB::WarmYellow;
	Marker->Display();

	Label->SetInverted( false);
	Label->Display();

	return( ValueChanged);
}

bool GUI_Setup_Select::DoSelect( int16_t* Value, int16_t LowerLimit, int16_t UpperLimit,
								 int16_t StepWidth, GUI_Setup_Marker* Marker,
								 GUI_Setup_Label* Label, void* Object,
								 void ( *Update)( void* Object),
								 void ( *UpdateLabel)( void* Object, GUI_Setup_Label* Label,
													   int16_t Value))
{
	int32_t NewValue = *Value;

	// Align to stepwidth.
	NewValue -= NewValue % StepWidth;

	// Saves some write cycles with this flag.
	bool ValueChanged = false;
	
	uint8_t BlinkCount = 0;
	
	Marker->ForegroundColor = LCD_65K_RGB::Red;
	Marker->Display();
	
	Label->SetInverted( true);
	Label->Display();
	
	bool Exit = false;
	
	while( Exit == false)
	{
		if( Update != NULL)
		{
			Update( Object);
		}

		int8_t RotarySelect;
		uint8_t RotaryButton;

		GLOBAL.InputService.GetRotary( &RotarySelect, &RotaryButton);

		if( RotaryButton > 0)
		{
			Exit = true;
		}

		// Set new position.
		if( RotarySelect != 0)
		{
			ValueChanged = true;

			NewValue += RotarySelect * StepWidth;

			if( NewValue > UpperLimit)
			{
				NewValue -= (( int32_t) UpperLimit - ( int32_t) LowerLimit) + StepWidth;
			}
			else if( NewValue < LowerLimit)
			{
				NewValue += (( int32_t) UpperLimit - ( int32_t) LowerLimit) + StepWidth;
			}

			*Value = NewValue;

			// Refresh label.
			UpdateLabel( Object, Label, *Value);
		}

		// Blink cursor.
		BlinkCount++;

		if( BlinkCount == ( GUI_SETUP_BLINK_COUNT / 2))
		{
			Label->SetInverted( false);
			Label->Display();
		}
		else if( BlinkCount == GUI_SETUP_BLINK_COUNT)
		{
			Label->SetInverted( true);
			Label->Display();

			BlinkCount = 0;
		}
		
		UTILITY::Pause( 5);
	}

	// Unselect.
	Marker->ForegroundColor = LCD_65K_RGB::WarmYellow;
	Marker->Display();
	
	Label->SetInverted( false);
	Label->Display();
	
	return( ValueChanged);
}

bool GUI_Setup_Select::DoGaugeSelect( uint8_t* Value, uint8_t LowerLimit, uint8_t UpperLimit,
									  uint8_t StepWidth, GUI_Setup_Marker* Marker,
									  GUI_Setup_Gauge* Gauge, void ( *UpdateGauge)( uint8_t Value))
{
	int16_t NewValue = *Value;

	// Align to stepwidth.
	NewValue -= NewValue % StepWidth;

	// Saves some write cycles with this flag.
	bool ValueChanged = false;

	// Select.
	Marker->ForegroundColor = LCD_65K_RGB::Red;
	Marker->Display();
	Gauge->SetDetailColor( LCD_65K_RGB::Red);

	bool Exit = false;

	while( Exit == false)
	{
		Gauge->Display( LowerLimit, UpperLimit, *Value);

		int8_t RotarySelect;
		uint8_t RotaryButton;

		GLOBAL.InputService.GetRotary( &RotarySelect, &RotaryButton);

		if( RotaryButton > 0)
		{
			UpdateGauge( *Value);

			Exit = true;
		}

		if( RotarySelect != 0)
		{
			ValueChanged = true;

			NewValue += RotarySelect * StepWidth;

			if( NewValue < LowerLimit)
			{
				NewValue = LowerLimit;
			}
			else if( NewValue > UpperLimit)
			{
				NewValue = UpperLimit;
			}

			*Value = NewValue;

			UpdateGauge( NewValue);
		}

		UTILITY::Pause( 5);
	}

	// Unselect.
	Marker->ForegroundColor = LCD_65K_RGB::WarmYellow;
	Marker->Display();
	Gauge->SetDetailColor( LCD_65K_RGB::WarmYellow);
	Gauge->Display( LowerLimit, UpperLimit, *Value);

	return( ValueChanged);
}

bool GUI_Setup_Select::DoTimeSelect( int16_t* Value, int16_t LowerLimit, int16_t UpperLimit,
									 uint8_t StepWidth, GUI_Setup_Marker* Marker,
									 GUI_Setup_Label* Label, void* Object,
									 void ( *UpdateLabel)( void* Object, GUI_Setup_Label* Label,
														   int16_t Value))
{
	int32_t NewValue = *Value;

	// Align to stepwidth.
	NewValue -= NewValue % StepWidth;

	// Saves some write cycles with this flag.
	bool ValueChanged = false;

	uint8_t BlinkCount = 0;

	Marker->ForegroundColor = LCD_65K_RGB::Red;
	Marker->Display();

	Label->SetInverted( true);
	Label->Display();

	bool Exit = false;

	while( Exit == false)
	{
		int8_t RotarySelect;
		uint8_t RotaryButton;

		GLOBAL.InputService.GetRotary( &RotarySelect, &RotaryButton);

		if( RotaryButton > 0)
		{
			Exit = true;
		}

		// Set new position.
		if( RotarySelect != 0)
		{
			ValueChanged = true;

			NewValue += RotarySelect * StepWidth;

			if( NewValue > UpperLimit)
			{
				NewValue = UpperLimit;
			}
			else if( NewValue < LowerLimit)
			{
				NewValue = LowerLimit;
			}

			*Value = NewValue;

			// Refresh label.
			UpdateLabel( Object, Label, *Value);
		}

		// Blink cursor.
		BlinkCount++;

		if( BlinkCount == ( GUI_SETUP_BLINK_COUNT / 2))
		{
			Label->SetInverted( false);
			Label->Display();
		}
		else if( BlinkCount == GUI_SETUP_BLINK_COUNT)
		{
			Label->SetInverted( true);
			Label->Display();

			BlinkCount = 0;
		}

		UTILITY::Pause( 5);
	}

	// Unselect.
	Marker->ForegroundColor = LCD_65K_RGB::WarmYellow;
	Marker->Display();

	Label->SetInverted( false);
	Label->Display();

	return( ValueChanged);
}

bool GUI_Setup_Select::DoSourceSelect( uint8_t* SignalSourceId, uint16_t* SetupSourceId,
									   GUI_Setup_Marker* Marker, GUI_Setup_Label* Label,
									   GUI_Setup_Gauge* Gauge,
									   char SourceName[ SETUP_SOURCE_NAME_SIZE + 1], void* Object,
									   void ( *Update)( void* Object), bool HasFixed,
									   Signal_Source_Source::Level SourceLevel,
									   Signal_Source_Source::Type SourceType)
{
	// Saves some write cycles with this flag.
	bool SourceChanged = false;

	uint8_t BlinkCount = 0;

	Marker->ForegroundColor = LCD_65K_RGB::Red;
	Marker->Display();

	Label->SetInverted( true);
	Label->Display();

	bool Exit = false;

	while( Exit == false)
	{
		if( Update != NULL)
		{
			Update( Object);
		}

		int8_t RotarySelect;
		uint8_t RotaryButton;

		GLOBAL.InputService.GetRotary( &RotarySelect, &RotaryButton);

		if( RotaryButton > 0)
		{
			Exit = true;
		}

		// Set new position.
		if( RotarySelect != 0)
		{
			SourceChanged = true;

			*SignalSourceId = GLOBAL.SignalProcessor.FindNextSource(
				*SignalSourceId, RotarySelect, HasFixed, SourceLevel, SourceType);

			// Refresh label.
			Label->Clear();

			if( Gauge != NULL)
			{
				Gauge->Clear();
			}

			if( *SignalSourceId == SIGNAL_SOURCE_NONE)
			{
				*SetupSourceId = SETUP_SOURCE_NONE;

				Label->SetText_P( Text::None);
			}
			else if( *SignalSourceId == SIGNAL_SOURCE_FIXED)
			{
				*SetupSourceId = SETUP_SOURCE_FIXED;

				Label->SetText_P( Text::Fixed);
			}
			else
			{
				const Signal_Source_Source* SignalSource =
					GLOBAL.SignalProcessor.GetSource( *SignalSourceId);

				*SetupSourceId = SignalSource->GetSetupSourceId();

				GLOBAL.SetupService.GetSourceName( SignalSource->GetSetupSourceId(), SourceName,
												   SETUP_SOURCE_NAME_SIZE + 1);
				Label->SetText( SourceName);
			}

			Label->Display();
		}

		// Blink cursor.
		BlinkCount++;

		if( BlinkCount == ( GUI_SETUP_BLINK_COUNT / 2))
		{
			Label->SetInverted( false);
			Label->Display();
		}
		else if( BlinkCount == GUI_SETUP_BLINK_COUNT)
		{
			Label->SetInverted( true);
			Label->Display();

			BlinkCount = 0;
		}

		UTILITY::Pause( 5);
	}

	// Unselect.
	Marker->ForegroundColor = LCD_65K_RGB::WarmYellow;
	Marker->Display();

	Label->SetInverted( false);
	Label->Display();

	return( SourceChanged);
}
