// Copyright 2007 Peter Stegemann

#include "Graph.h"

#include "Main/Setup.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"

#define GUI_SETUP_GRAPH_LABEL_FONT		FONT::FID_Medium

GUI_Setup_Graph::GUI_Setup_Graph( void)
			   : left( 0)
			   , top( 0)
			   , size( 0)
			   , remembered( false)
			   , graphPoints( 0)
			   , marker( -1)
			   , ForegroundColor( LCD_65K_RGB::White)
			   , BackgroundColor( LCD_65K_RGB::Black)
			   , DetailColor( LCD_65K_RGB::WarmYellow)
{
}

int16_t GUI_Setup_Graph::getPoint( const Setup_Source_Tupel Point[], uint8_t PointId)
{
	uint8_t SignalSourceId =
		GLOBAL.SignalProcessor.GetSignalSourceId( Point[ PointId].SetupSourceId);
	int16_t Volume = Point[ PointId].Volume;

	if( SignalSourceId == SIGNAL_SOURCE_NONE)
	{
		// No source, use neutral value.
		return( SIGNAL_NEUTRAL_VALUE);
	}
	else if( SignalSourceId == SIGNAL_SOURCE_FIXED)
	{
		return( Volume);
	}
	else
	{
		int32_t Value = GLOBAL.SignalProcessor.CalculateSourceValue( SignalSourceId);

		Value *= Volume;
		Value /= SIGNAL_CHANNEL_100_PERCENT_VALUE;

		if( Value < SIGNAL_MINIMUM_VALUE)
		{
			Value = SIGNAL_MINIMUM_VALUE;
		}
		else if( Value > SIGNAL_MAXIMUM_VALUE)
		{
			Value = SIGNAL_MAXIMUM_VALUE;
		}

		return( Value);
	}
}

bool GUI_Setup_Graph::calculateGraph( const int16_t Point[], uint8_t Points)
{
	bool Updated = false;

	// Number of points we can do is limited...
	if( Points > GUI_SETUP_GRAPH_POINTS)
	{
		Points = GUI_SETUP_GRAPH_POINTS;
	}

	uint8_t GraphId = 0;

	for( uint8_t PointId = 0; PointId < Points; PointId++)
	{
		int32_t CurrentPoint = Point[ PointId];

		if( CurrentPoint >= SIGNAL_MINIMUM_VALUE)
		{
			uint32_t NormalizedPoint = CurrentPoint - SIGNAL_MINIMUM_VALUE;
			int16_t NewGraphPoint =
				(( NormalizedPoint * ( uint32_t)( size - 5)) / ( uint32_t) SIGNAL_VALUE_RANGE);

			if( NewGraphPoint != graphPoint[ GraphId])
			{
				Updated = true;
			}

			newGraphPoint[ GraphId] = NewGraphPoint;

			GraphId++;
		}
	}

	if( graphPoints != GraphId)
	{
		Updated = true;
	}

	newGraphPoints = GraphId;

	return( Updated);
}

bool GUI_Setup_Graph::calculateGraph( const Setup_Source_Tupel Point[], uint8_t Points)
{
	bool Updated = false;

	// Number of points we can do is limited...
	if( Points > GUI_SETUP_GRAPH_POINTS)
	{
		Points = GUI_SETUP_GRAPH_POINTS;
	}

	uint8_t GraphId = 0;

	for( uint8_t PointId = 0; PointId < Points; PointId++)
	{
		if( Point[ PointId].SetupSourceId != SETUP_SOURCE_NONE)
		{
			int32_t CurrentPoint = getPoint( Point, PointId);
			uint32_t NormalizedPoint = CurrentPoint - SIGNAL_MINIMUM_VALUE;
			int16_t NewGraphPoint =
				(( NormalizedPoint * ( uint32_t)( size - 5)) / ( uint32_t) SIGNAL_VALUE_RANGE);

			if( NewGraphPoint != graphPoint[ GraphId])
			{
				Updated = true;
			}

			newGraphPoint[ GraphId] = NewGraphPoint;

			GraphId++;
		}
	}

	if( graphPoints != GraphId)
	{
		Updated = true;
	}

	newGraphPoints = GraphId;

	return( Updated);
}

void GUI_Setup_Graph::updateGraph( void)
{
	for( uint8_t PointId = 0; PointId < newGraphPoints; PointId++)
	{
		graphPoint[ PointId] = newGraphPoint[ PointId];
	}

	graphPoints = newGraphPoints;
}

void GUI_Setup_Graph::display( ClearOrPrintMode ClearOrPrint)
{
	if( size == 0)
	{
		return;
	}

	LCD_65K_RGB::Color LineColor;
	LCD_65K_RGB::Color DotColor;

	switch( ClearOrPrint)
	{
		case COP_Clear :
		{
			LineColor = BackgroundColor;
			DotColor = BackgroundColor;
		}
		break;

		default :
		case COP_Print :
		{
			LineColor = ForegroundColor;
			DotColor = DetailColor;
		}
		break;
	}

	const FONT_Type* Font = FONT::GetFont( GUI_SETUP_GRAPH_LABEL_FONT);

	uint16_t LabelLeft = left - 3 * Font->CellWidth;
	uint16_t LabelTop = ( top - Font->CellHeight);

	GLOBAL.SetupDisplay.Print_P( LabelLeft, LabelTop, GUI_SETUP_GRAPH_LABEL_FONT, DetailColor,
								 BackgroundColor, LCD_65K_RGB::PO_Fixed, Text::Minus100Percent);

	LabelLeft += size / 2;
	GLOBAL.SetupDisplay.Print_P( LabelLeft, LabelTop, GUI_SETUP_GRAPH_LABEL_FONT, DetailColor,
								 BackgroundColor, LCD_65K_RGB::PO_Fixed, Text::PaddedZeroPercent);

	LabelLeft += size / 2 + 1;
	LabelLeft += ( 1 * Font->CellWidth);
	GLOBAL.SetupDisplay.Print_P( LabelLeft, LabelTop, GUI_SETUP_GRAPH_LABEL_FONT, DetailColor,
								 BackgroundColor, LCD_65K_RGB::PO_Fixed, Text::Plus100Percent);

	LabelTop += size / 2;
	LabelTop += Font->CellHeight / 2;
	LabelLeft += ( 2 * Font->CellWidth) + 1;
	GLOBAL.SetupDisplay.Print_P( LabelLeft, LabelTop, GUI_SETUP_GRAPH_LABEL_FONT, DetailColor,
								 BackgroundColor, LCD_65K_RGB::PO_Fixed, Text::ZeroPercent);

	LabelTop += size / 2;
	LabelTop += ( Font->CellHeight / 2) + 1;
	LabelLeft -= ( 3 * Font->CellWidth);
	GLOBAL.SetupDisplay.Print_P( LabelLeft, LabelTop, GUI_SETUP_GRAPH_LABEL_FONT, DetailColor,
								 BackgroundColor, LCD_65K_RGB::PO_Fixed, Text::Minus100Percent);

	displayGraph( ClearOrPrint);
}

void GUI_Setup_Graph::displayGraph( ClearOrPrintMode ClearOrPrint)
{
	if( size == 0)
	{
		return;
	}

	GLOBAL.SetupDisplay.DrawRect( left, top, size, size, ForegroundColor, LCD::RO_Rounded);
	GLOBAL.SetupDisplay.DrawRect( left + 1, top + 1, size - 2, size - 2, ForegroundColor,
								  LCD::RO_Boxed);

	LCD_65K_RGB::Color UseForegroundColor;
	LCD_65K_RGB::Color UseDetailColor;

	switch( ClearOrPrint)
	{
		case COP_Clear :
		{
			UseForegroundColor = BackgroundColor;
			UseDetailColor = BackgroundColor;
		}
		break;

		default :
		case COP_Print :
		{
			UseForegroundColor = ForegroundColor;
			UseDetailColor = DetailColor;
		}
		break;
	}

	// Move graph inside frame.
	uint16_t Left = left + 2;
	uint16_t Top = top + 2;

	if( marker >= 0)
	{
		GLOBAL.SetupDisplay.DrawVerticalLine( Left + marker, Top, size - 4, UseDetailColor);
	}

	uint16_t Size = size - 5;

	if( graphPoints == 0)
	{
		// Done.
	}
	else if( graphPoints == 1)
	{
		uint16_t X = Left;
		uint16_t Y = Top + Size - graphPoint[ 0];

		GLOBAL.SetupDisplay.DrawLine( X, Y, X + Size + 1, Y, UseForegroundColor);

		X = Left + Size / 2;

		GLOBAL.SetupDisplay.DrawDot( X, Y, UseDetailColor);
	}
	else
	{
		uint16_t LastX = 0;
		uint16_t LastY = 0;

		for( uint8_t GUI_Setup_GraphId = 0; GUI_Setup_GraphId < graphPoints; GUI_Setup_GraphId++)
		{
			uint16_t X = Left + ( GUI_Setup_GraphId * Size) / ( graphPoints - 1);
			uint16_t Y = Top + Size - graphPoint[ GUI_Setup_GraphId];

			if( GUI_Setup_GraphId != 0)
			{
				GLOBAL.SetupDisplay.DrawLine( LastX, LastY, X, Y, UseForegroundColor);
			}

			GLOBAL.SetupDisplay.DrawDot( X, Y, UseDetailColor);

			LastX = X;
			LastY = Y;
		}
	}
}

void GUI_Setup_Graph::SetDimensions( uint16_t Left, uint16_t Top, uint16_t Size)
{
	left = Left;
	top = Top;
	size = Size;

	const FONT_Type* Font = FONT::GetFont( GUI_SETUP_GRAPH_LABEL_FONT);

	size -= UTILITY_Maximum( Font->CellHeight, Font->CellWidth);

	// First draw will redraw everything.
	remembered = false;
}

void GUI_Setup_Graph::Display( int16_t Marker)
{
	int32_t NewMarker = Marker;
	NewMarker -= SIGNAL_MINIMUM_VALUE;
	NewMarker *= ( uint32_t)( size - 5);
	NewMarker /= ( uint32_t) SIGNAL_VALUE_RANGE;
	
	if( NewMarker == marker)
	{
		// No change.
		return;
	}
	
	// Clear old marker?
	if( marker >= 0)
	{
		GLOBAL.SetupDisplay.DrawVerticalLine( left + 2 + marker, top + 2, size - 4, BackgroundColor);
	}
	
	marker = NewMarker;
	
	displayGraph( COP_Print);
}

void GUI_Setup_Graph::Display( const int16_t Point[], uint8_t Points)
{
	display( marker, Point, Points);
}

void GUI_Setup_Graph::Display( int16_t Marker, const int16_t Point[], uint8_t Points)
{
	int32_t NewMarker = Marker;
	NewMarker -= SIGNAL_MINIMUM_VALUE;
	NewMarker *= ( uint32_t)( size - 5);
	NewMarker /= ( uint32_t) SIGNAL_VALUE_RANGE;

	display( NewMarker, Point, Points);
}

void GUI_Setup_Graph::Display( const Setup_Source_Tupel Point[], uint8_t Points)
{
	display( marker, Point, Points);
}

void GUI_Setup_Graph::Display( int16_t Marker, const Setup_Source_Tupel Point[], uint8_t Points)
{
	int32_t NewMarker = Marker;
	NewMarker -= SIGNAL_MINIMUM_VALUE;
	NewMarker *= ( uint32_t)( size - 5);
	NewMarker /= ( uint32_t) SIGNAL_VALUE_RANGE;

	display( NewMarker, Point, Points);
}

void GUI_Setup_Graph::display( int16_t Marker, const int16_t Point[], uint8_t Points)
{
	if( remembered == false)
	{
		// Remember new values.
		calculateGraph( Point, Points);

		updateGraph();

		marker = Marker;

		display( COP_Print);

		remembered = true;
	}
	else
	{
		bool MarkerUpdated = Marker != marker;
		bool GUI_Setup_GraphUpdated = calculateGraph( Point, Points);

		if( GUI_Setup_GraphUpdated)
		{
			// Clear graph.
			displayGraph( COP_Clear);

			updateGraph();

			marker = Marker;

			// Display graph.
			displayGraph( COP_Print);
		}
		else if( MarkerUpdated)
		{
			// Clear old marker?
			if( marker >= 0)
			{
				GLOBAL.SetupDisplay.DrawVerticalLine( left + 2 + marker, top + 2, size - 4,
												  BackgroundColor);
			}

			marker = Marker;

			displayGraph( COP_Print);
		}
	}
}

void GUI_Setup_Graph::display( int16_t Marker, const Setup_Source_Tupel Point[], uint8_t Points)
{
	if( remembered == false)
	{
		// Remember new values.
		calculateGraph( Point, Points);

		updateGraph();

		marker = Marker;

		display( COP_Print);

		remembered = true;
	}
	else
	{
		bool MarkerUpdated = Marker != marker;
		bool GUI_Setup_GraphUpdated = calculateGraph( Point, Points);

		if( GUI_Setup_GraphUpdated)
		{
			// Clear graph.
			displayGraph( COP_Clear);

			updateGraph();

			marker = Marker;

			// Display graph.
			displayGraph( COP_Print);
		}
		else if( MarkerUpdated)
		{
			// Clear old marker?
			if( marker >= 0)
			{
				GLOBAL.SetupDisplay.DrawVerticalLine( left + 2 + marker, top + 2, size - 4,
													  BackgroundColor);
			}

			marker = Marker;

			displayGraph( COP_Print);
		}
	}
}

void GUI_Setup_Graph::Clear( void)
{
	// If we have don't have remembered values, we can't do anything.
	if( remembered == true)
	{
		// Clear graph.
		display( COP_Clear);
	}
	else
	{
		// Clear display area.
		GLOBAL.SetupDisplay.FillRect( left + 2, top + 2, size - 4, size - 4, BackgroundColor);
	}
}
