// Copyright 2007 Peter Stegemann

#ifndef GUI_SETUP_GRAPH_H
#define GUI_SETUP_GRAPH_H

#include "Setup/Source/Tupel.h"

#include "AVR/Components/LCD/LCD_65K_RGB.h"

#define GUI_SETUP_GRAPH_POINTS		10

class GUI_Setup_Graph
{
	private:
		// Location.
		uint16_t left, top, size;

		// Marks wether we have remembered values from last draw.
		bool remembered;
		// Remembered values.
		int16_t graphPoint[ GUI_SETUP_GRAPH_POINTS];
		int16_t newGraphPoint[ GUI_SETUP_GRAPH_POINTS];
		uint8_t graphPoints;
		uint8_t newGraphPoints;
		int16_t marker;

		// Internal display with a "print" or "clear" mode.
		enum ClearOrPrintMode
		{
			COP_Clear,
			COP_Print
		};

		int16_t getPoint( const Setup_Source_Tupel Point[], uint8_t PointId);
		bool calculateGraph( const int16_t Point[], uint8_t Points);
		bool calculateGraph( const Setup_Source_Tupel Point[], uint8_t Points);
		void updateGraph( void);

		// With print, the whole content with numbers and everything is shown. With clear, only the
		// graph will be removed.
		void display( ClearOrPrintMode ClearOrPrint);
		void displayGraph( ClearOrPrintMode ClearOrPrint);

		void display( int16_t Marker, const int16_t Point[], uint8_t Points);
		void display( int16_t Marker, const Setup_Source_Tupel Point[], uint8_t Points);

	public:
		LCD_65K_RGB::Color ForegroundColor;
		LCD_65K_RGB::Color BackgroundColor;
		LCD_65K_RGB::Color DetailColor;

	public:
		GUI_Setup_Graph( void);

		// Set the location of the map on the screen.
		void SetDimensions( uint16_t Left, uint16_t Top, uint16_t Size);

		void SetSignalMinimumValue( int16_t SignalMinimumValue);
		void SetSignalValueRange( uint16_t SignalValueRange);

		// This will update the view to reflect the given map.
		void Display( int16_t Marker);
		void Display( const int16_t Point[], uint8_t Points);
		void Display( int16_t Marker, const int16_t Point[], uint8_t Points);
		void Display( const Setup_Source_Tupel Point[], uint8_t Points);
		void Display( int16_t Marker, const Setup_Source_Tupel Point[], uint8_t Points);

		void Clear( void);
};

#endif
