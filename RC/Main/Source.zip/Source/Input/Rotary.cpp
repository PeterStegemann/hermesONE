// Copyright 2008 Peter Stegemann

#include "Rotary.h"

#include "Ports.h"

// 00 10 11 01 (0 2 3 1) clockwise
// 00 01 11 10 (0 1 3 2) anticlockwise
static const int8_t RotaryTable[] =
{
	// 1111 1110 1101 1100
	//   00   01   10   11
	      0,  +1,  -1,   0,
	// 1011 1010 1001 1000
	//   01   11   11   10
	     -1,   0,   0,  +1,
	// 0111 0110 0101 0100
	//   10   11   00   01
	     +1,   0,   0,  -1,
	// 0011 0010 0001 0000
	//   11   10   01   00
	      0,  -1,  +1,   0
};

#define INPUT_ROTARY_RESETCOUNT		500

void Input_Rotary::Initialize( void)
{
	rotarySubValue = 0;
	lastRotarySelect = 0;
	resetCount = 0;
}

int8_t Input_Rotary::CalculateDifference( bool InputA, bool InputB)
{
	int8_t Result = 0;

	// Rotary select
	uint8_t NewRotarySelect = 0;

	if( InputA)	NewRotarySelect |= 0x01;
	if( InputB)	NewRotarySelect |= 0x02;

	if( NewRotarySelect != lastRotarySelect)
	{
		int8_t Step = RotaryTable[ ( lastRotarySelect << 2) | NewRotarySelect];
		rotarySubValue += Step;

		// For substeps are one step.
		if( rotarySubValue == 4)
		{
			Result++;
			rotarySubValue = 0;
		}
		else if( rotarySubValue == -4)
		{
			Result--;
			rotarySubValue = 0;
		}

		lastRotarySelect = NewRotarySelect;

		resetCount = INPUT_ROTARY_RESETCOUNT;
	}

	// If we miss a step, we will become misalinged. So if there is no change for some time, we
	// assume the rotary to be in zero position and reset the sub counter.
	resetCount--;

	if( resetCount == 0)
	{
		resetCount = INPUT_ROTARY_RESETCOUNT;

		rotarySubValue = 0;
	}

	return( Result);
}
