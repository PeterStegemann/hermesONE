// Copyright 2008 Peter Stegemann

#ifndef INPUT_ROTARY_H
#define INPUT_ROTARY_H

#include "AVR/Components/Types.h"

class Input_Rotary
{
	private:
		int8_t rotarySubValue;
		uint8_t lastRotarySelect;

		uint16_t resetCount;

	public:
		void Initialize( void);

		int8_t CalculateDifference( bool InputA, bool InputB);
};

#endif
