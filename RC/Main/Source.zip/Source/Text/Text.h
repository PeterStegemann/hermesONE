// Copyright 2008 Peter Stegemann

#ifndef TEXT_H
#define TEXT_H

#include <avr/pgmspace.h>

class Text
{
	public:
		static const prog_char ThreeDigitPercentFormat[];
		static const prog_char FourDigitPercentFormat[];
		static const prog_char EmptyDigitPercent[];
		static const prog_char Int8Format[];
		static const prog_char FourDigitInt16Format[];
		static const prog_char SixDigitInt16Format[];
		static const prog_char CharacterFormat[];
		static const prog_char TwinCharacterFormat[];
		static const prog_char TimeFormat[];
		static const prog_char NegativeTimeFormat[];
		static const prog_char VoltageFormat[];
		static const prog_char MillisecondFormat[];

		static const prog_char Plus100Percent[];
		static const prog_char PaddedZeroPercent[];
		static const prog_char Minus100Percent[];
		static const prog_char ZeroPercent[];
		static const prog_char PaddedOff[];

		static const prog_char hermesONE[];

		static const prog_char Add[];
		static const prog_char Analog[];
		static const prog_char AlarmCritical[];
		static const prog_char AlarmLow[];
		static const prog_char Backlight[];
		static const prog_char Battery[];
		static const prog_char BlankTime[];
		static const prog_char Button[];
		static const prog_char Calibration[];
		static const prog_char Cancel[];
		static const prog_char Channel[];
		static const prog_char ChannelMapping[];
		static const prog_char Channels[];
		static const prog_char Contrast[];
		static const prog_char Critical[];
		static const prog_char Delete[];
		static const prog_char Follower[];
		static const prog_char Followers[];
		static const prog_char Display[];
		static const prog_char Empty[];
		static const prog_char Exit[];
		static const prog_char Fixed[];
		static const prog_char Global[];
		static const prog_char Info[];
		static const prog_char Init[];
		static const prog_char Input[];
		static const prog_char InputA[];
		static const prog_char InputB[];
		static const prog_char Inputs[];
		static const prog_char PPMInverted[];
		static const prog_char Limit[];
		static const prog_char Low[];
		static const prog_char Main[];
		static const prog_char Map[];
		static const prog_char Maps[];
		static const prog_char Maximum[];
		static const prog_char Minimum[];
		static const prog_char Mix[];
		static const prog_char Mixers[];
		static const prog_char Model[];
		static const prog_char Models[];
		static const prog_char Name[];
		static const prog_char None[];
		static const prog_char Ok[];
		static const prog_char Owner[];
		static const prog_char PPMCenter[];
		static const prog_char Range[];
		static const prog_char Reset[];
		static const prog_char ResetCheck[];
		static const prog_char Reverse[];
		static const prog_char Rotary[];
		static const prog_char Serial[];
		static const prog_char SerialShort[];
		static const prog_char SerialAsk[];
		static const prog_char Setup[];
		static const prog_char ShowIntro[];
		static const prog_char Source[];
		static const prog_char Sources[];
		static const prog_char Status[];
		static const prog_char Step[];
		static const prog_char Stop[];
		static const prog_char Store[];
		static const prog_char Stores[];
		static const prog_char Switch[];
		static const prog_char System[];
		static const prog_char Target[];
		static const prog_char Ticker[];
		static const prog_char Time[];
		static const prog_char Timer[];
		static const prog_char Timers[];
		static const prog_char Toggle[];
		static const prog_char Trigger[];
		static const prog_char TriggerLowLimit[];
		static const prog_char TriggerHighLimit[];
		static const prog_char Trim[];
		static const prog_char Type[];
		static const prog_char Types[];
		static const prog_char unknown[];
		static const prog_char Volume[];
		static const prog_char Warn[];

		static const prog_char Yes[];
		static const prog_char No[];

		static const prog_char Bottom[];
		static const prog_char Center[];
		static const prog_char Top[];

		static const prog_char RFEnabled[];
		static const prog_char RFDisabled[];

		static const prog_char ChannelNameFormat[];
		static const prog_char FollowerNameFormat[];
		static const prog_char InputNameFormat[];
		static const prog_char MapNameFormat[];
		static const prog_char MixNameFormat[];
		static const prog_char StoreNameFormat[];
		static const prog_char TimerNameFormat[];
		static const prog_char ModelNameFormat[];
		static const prog_char TypeNameFormat[];

		static const prog_char StatusUsageFormat[];

		static const prog_char CantDeleteCurrentModel[];
		static const prog_char CantDeleteCurrentType[];
		static const prog_char SwitchTypeWarning[];

		static const prog_char DeleteModelFormat[];
		static const prog_char DeleteSourceFollowerFormat[];
		static const prog_char DeleteSourceInputFormat[];
		static const prog_char DeleteSourceMapFormat[];
		static const prog_char DeleteSourceMixFormat[];
		static const prog_char DeleteSourceStoreFormat[];
		static const prog_char DeleteSourceTimerFormat[];
		static const prog_char DeleteSourceUnknownFormat[];
		static const prog_char DeleteTypeFormat[];

		static const prog_char NoModelStorage[];
		static const prog_char NoSystemStorage[];

		static const prog_char ModelsCount[];
		static const prog_char TypesCount[];
		static const prog_char SourcesCount[];
		static const prog_char InternalEEPROMSize[];
		static const prog_char ExternalEEPROMSize[];
		static const prog_char CPUType[];

		static const prog_char LeftSide[];
		static const prog_char LeftBottom[];
		static const prog_char RightSide[];
		static const prog_char RightBottom[];
	};

#endif
