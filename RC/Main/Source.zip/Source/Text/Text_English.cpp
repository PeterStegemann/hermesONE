// Copyright 2008 Peter Stegemann

#include "Text.h"

#include "System.h"

const prog_char Text::ThreeDigitPercentFormat[]		= "%3d%%";
const prog_char Text::FourDigitPercentFormat[]		= "%4d%%";
const prog_char Text::EmptyDigitPercent[]			= "---%";
const prog_char Text::Int8Format[]					= "%d";
const prog_char Text::FourDigitInt16Format[]		= "%4d";
const prog_char Text::SixDigitInt16Format[]			= "%6d";
const prog_char Text::CharacterFormat[]				= "%c";
const prog_char Text::TwinCharacterFormat[]			= "%c%c";
const prog_char Text::TimeFormat[]					= "%02d:%02d ";
const prog_char Text::NegativeTimeFormat[]			= "-%02d:%02d ";
const prog_char Text::VoltageFormat[]				= "%2u.%1uv ";
const prog_char Text::MillisecondFormat[]			= "%1u.%1u ms ";

const prog_char Text::Plus100Percent[]				= "100%";
const prog_char Text::PaddedZeroPercent[]			= "  0%";
const prog_char Text::Minus100Percent[]				= "-100%";
const prog_char Text::ZeroPercent[]					= "0%";
const prog_char Text::PaddedOff[]					= "  Off";

const prog_char Text::hermesONE[]					= "hermesONE";

const prog_char Text::Add[]							= "Add";
const prog_char Text::Analog[]						= "Analog";
const prog_char Text::AlarmCritical[]				= "Critical";
const prog_char Text::AlarmLow[]					= "Alarm Low";
const prog_char Text::Backlight[]					= "Backlight";
const prog_char Text::Battery[]						= "Battery";
const prog_char Text::BlankTime[]					= "Blank Time";
const prog_char Text::Button[]						= "Button";
const prog_char Text::Calibration[]					= "Calibration";
const prog_char Text::Cancel[]						= "Cancel";
const prog_char Text::Channel[]						= "Channel";
const prog_char Text::ChannelMapping[]				= "Channelmapping";
const prog_char Text::Channels[]					= "Channels";
const prog_char Text::Contrast[]					= "Contrast";
const prog_char Text::Critical[]					= "Critical";
const prog_char Text::Follower[]					= "Follower";
const prog_char Text::Followers[]					= "Followers";
const prog_char Text::Delete[]						= "Delete";
const prog_char Text::Display[]						= "Display";
const prog_char Text::Empty[]						= "Empty";
const prog_char Text::Exit[]						= "Exit";
const prog_char Text::Fixed[]						= "Fixed";
const prog_char Text::Global[]						= "Global";
const prog_char Text::Info[]						= "Info";
const prog_char Text::Init[]						= "Initial";
const prog_char Text::Input[]						= "Input";
const prog_char Text::InputA[]						= "Input High";
const prog_char Text::InputB[]						= "Input Low";
const prog_char Text::Inputs[]						= "Inputs";
const prog_char Text::PPMInverted[]					= "Invert PPM";
const prog_char Text::Limit[]						= "Limit";
const prog_char Text::Low[]							= "Low";
const prog_char Text::Main[]						= "Main";
const prog_char Text::Map[]							= "Map";
const prog_char Text::Maps[]						= "Maps";
const prog_char Text::Maximum[]						= "Maximum";
const prog_char Text::Minimum[]						= "Minimum";
const prog_char Text::Mix[]							= "Mix";
const prog_char Text::Mixers[]						= "Mixers";
const prog_char Text::Model[]						= "Model";
const prog_char Text::Models[]						= "Models";
const prog_char Text::Name[]						= "Name";
const prog_char Text::None[]						= "No Source";
const prog_char Text::Ok[]							= "Ok";
const prog_char Text::Owner[]						= "Owner";
const prog_char Text::PPMCenter[]					= "PPM Center";
const prog_char Text::Range[]						= "Range";
const prog_char Text::Reset[]						= "Reset";
const prog_char Text::ResetCheck[]					= "Reset all settings?";
const prog_char Text::Reverse[]						= "Reverse";
const prog_char Text::Rotary[]						= "Rotary";
const prog_char Text::Serial[]						= "Serial";
const prog_char Text::SerialShort[]					= "Serial";
const prog_char Text::SerialAsk[]					= "Serial connection active...";
const prog_char Text::Setup[]						= "Setup";
//const prog_char Text::SetupBacklight[]				= "Setup Backlight";
const prog_char Text::ShowIntro[]					= "Show Intro";
const prog_char Text::Source[]						= "Source";
const prog_char Text::Sources[]						= "All Sources";
const prog_char Text::Status[]						= "Status";
const prog_char Text::Store[]						= "Store";
const prog_char Text::Stores[]						= "Stores";
const prog_char Text::Stop[]						= "Stop";
const prog_char Text::Switch[]						= "Switch";
const prog_char Text::System[]						= "System";
const prog_char Text::Target[]						= "Target";
const prog_char Text::Ticker[]						= "Ticker";
const prog_char Text::Time[]						= "Time";
const prog_char Text::Timer[]						= "Timer";
const prog_char Text::Timers[]						= "Timers";
const prog_char Text::Toggle[]						= "Toggle";
const prog_char Text::Trigger[]						= "Trigger";
const prog_char Text::TriggerLowLimit[]				= "Limit Low";
const prog_char Text::TriggerHighLimit[]			= "High";
const prog_char Text::Trim[]						= "Trim";
const prog_char Text::Type[]						= "Type";
const prog_char Text::Types[]						= "Types";
const prog_char Text::unknown[]						= "unknown";
const prog_char Text::Volume[]						= "Volume";
const prog_char Text::Warn[]						= "Warn";

const prog_char Text::Yes[]							= "Yes";
const prog_char Text::No[]							= "No";

const prog_char Text::Bottom[]						= "Bottom";
const prog_char Text::Center[]						= "Center";
const prog_char Text::Top[]							= "Top";

const prog_char Text::RFEnabled[]					= " RF Enabled";
const prog_char Text::RFDisabled[]					= "RF Disabled";

const prog_char Text::ChannelNameFormat[]			= "Channel %d";
const prog_char Text::FollowerNameFormat[]				= "Follower %d";
const prog_char Text::InputNameFormat[]				= "Input %d";
const prog_char Text::MapNameFormat[]				= "Map %d";
const prog_char Text::MixNameFormat[]				= "Mix %d";
const prog_char Text::StoreNameFormat[]				= "Store %d";
const prog_char Text::TimerNameFormat[]				= "Timer %d";
const prog_char Text::ModelNameFormat[]				= "Model %d";
const prog_char Text::TypeNameFormat[]				= "Type %d";

const prog_char Text::StatusUsageFormat[]			= "Models %d/%d Sources %d/%d";

const prog_char Text::CantDeleteCurrentModel[]		= "Can't delete current model!";
const prog_char Text::CantDeleteCurrentType[]		= "Can't delete current type!";
const prog_char Text::SwitchTypeWarning[]			= "This can make your model unusable!";

const prog_char Text::DeleteModelFormat[]			= "Delete model \"%s\"?";
const prog_char Text::DeleteSourceFollowerFormat[]	= "Delete follower \"%s\"?";
const prog_char Text::DeleteSourceInputFormat[]		= "Delete input \"%s\"?";
const prog_char Text::DeleteSourceMapFormat[]		= "Delete map \"%s\"?";
const prog_char Text::DeleteSourceMixFormat[]		= "Delete mix \"%s\"?";
const prog_char Text::DeleteSourceStoreFormat[]		= "Delete store \"%s\"?";
const prog_char Text::DeleteSourceTimerFormat[]		= "Delete timer \"%s\"?";
const prog_char Text::DeleteSourceUnknownFormat[]	= "Delete unknown \"%s\"?";
const prog_char Text::DeleteTypeFormat[]			= "Delete type \"%s\"?";

const prog_char Text::NoModelStorage[]				= "No model storage available!";
const prog_char Text::NoSystemStorage[]				= "No system storage available!";

const prog_char Text::ModelsCount[]					= "Models: %3u";
const prog_char Text::TypesCount[]					= "Types: %3u";
const prog_char Text::SourcesCount[]				= "Sources: %4u";
const prog_char Text::InternalEEPROMSize[]			= "Internal EEPROM: %5u / %5u";
const prog_char Text::ExternalEEPROMSize[]			= "External EEPROM: %5u / %5lu";
const prog_char Text::CPUType[]						= "CPU: "SYSTEM_MCU;

const prog_char Text::LeftSide[]					= "Left Side";
const prog_char Text::LeftBottom[]					= "Left Bottom";
const prog_char Text::RightSide[]					= "Right Side";
const prog_char Text::RightBottom[]					= "Right Bottom";
