// Copyright 2008 Peter Stegemann

#include "Text.h"

#include "System.h"

const prog_char Text::ThreeDigitPercentFormat[]		= "%3d%%";
const prog_char Text::FourDigitPercentFormat[]		= "%4d%%";
const prog_char Text::EmptyDigitPercent[]			= "---%";
const prog_char Text::Int8Format[]					= "%d";
const prog_char Text::FourDigitInt16Format[]		= "%4d";
const prog_char Text::SixDigitInt16Format[]			= "%6d";
const prog_char Text::CharacterFormat[]				= "%c";
const prog_char Text::TwinCharacterFormat[]			= "%c%c";
const prog_char Text::TimeFormat[]					= "%02d:%02d ";
const prog_char Text::NegativeTimeFormat[]			= "-%02d:%02d ";
const prog_char Text::VoltageFormat[]				= "%2u.%1uv ";
const prog_char Text::MillisecondFormat[]			= "%1u.%1u ms ";

const prog_char Text::Plus100Percent[]				= "100%";
const prog_char Text::PaddedZeroPercent[]			= "  0%";
const prog_char Text::Minus100Percent[]				= "-100%";
const prog_char Text::ZeroPercent[]					= "0%";
const prog_char Text::PaddedOff[]					= "  Aus";

const prog_char Text::hermesONE[]					= "hermesONE";

const prog_char Text::Add[]							= "Hinzufuegen";
const prog_char Text::Analog[]						= "Analog";
const prog_char Text::AlarmCritical[]				= "Kritisch";
const prog_char Text::AlarmLow[]					= "Alarm Niedrig";
const prog_char Text::Backlight[]					= "Licht";
const prog_char Text::Battery[]						= "Batterie";
const prog_char Text::Button[]						= "Taster";
const prog_char Text::BlankTime[]					= "Bildschirm Aus";
const prog_char Text::Calibration[]					= "Kalibrierung";
const prog_char Text::Cancel[]						= "Abbrechen";
const prog_char Text::Channel[]						= "Kanal";
const prog_char Text::ChannelMapping[]				= "Kanalzuweisung";
const prog_char Text::Channels[]					= "Kanaele";
const prog_char Text::Contrast[]					= "Kontrast";
const prog_char Text::Critical[]					= "Kritisch";
const prog_char Text::Follower[]					= "Folger";
const prog_char Text::Followers[]					= "Folger";
const prog_char Text::Delete[]						= "Loeschen";
const prog_char Text::Display[]						= "Display";
const prog_char Text::Empty[]						= "Leer";
const prog_char Text::Exit[]						= "Zurueck";
const prog_char Text::Fixed[]						= "Fest";
const prog_char Text::Global[]						= "Global";
const prog_char Text::Info[]						= "Info";
const prog_char Text::Init[]						= "Startwert";
const prog_char Text::Input[]						= "Geber";
const prog_char Text::InputA[]						= "Geber Oben";
const prog_char Text::InputB[]						= "Geber Unten";
const prog_char Text::Inputs[]						= "Geber";
const prog_char Text::PPMInverted[]					= "PPM invertieren";
const prog_char Text::Limit[]						= "Limit";
const prog_char Text::Low[]							= "Niedrig";
const prog_char Text::Main[]						= "Main";
const prog_char Text::Map[]							= "Map";
const prog_char Text::Maps[]						= "Maps";
const prog_char Text::Maximum[]						= "Maximum";
const prog_char Text::Minimum[]						= "Minimum";
const prog_char Text::Mix[]							= "Mischer";
const prog_char Text::Mixers[]						= "Mischer";
const prog_char Text::Model[]						= "Modell";
const prog_char Text::Models[]						= "Modelle";
const prog_char Text::Name[]						= "Name";
const prog_char Text::None[]						= "Keine Quelle";
const prog_char Text::Ok[]							= "Ok";
const prog_char Text::Owner[]						= "Besitzer";
const prog_char Text::PPMCenter[]					= "PPM Mitte";
const prog_char Text::Range[]						= "Bereich";
const prog_char Text::Reset[]						= "Reset";
const prog_char Text::ResetCheck[]					= "Alle Einstellungen zuruecksetzen?";
const prog_char Text::Reverse[]						= "Umkehr";
const prog_char Text::Rotary[]						= "Drehgeber";
const prog_char Text::Serial[]						= "Serielle Verbindung";
const prog_char Text::SerialShort[]					= "Seriell";
const prog_char Text::SerialAsk[]					= "Serielle Verbindung aktiv...";
const prog_char Text::Setup[]						= "Einstellung";
const prog_char Text::ShowIntro[]					= "Prolog an";
const prog_char Text::Source[]						= "Quelle";
const prog_char Text::Sources[]						= "Alle Quellen";
const prog_char Text::Status[]						= "Status";
const prog_char Text::Store[]						= "Speicher";
const prog_char Text::Stores[]						= "Speicher";
const prog_char Text::Step[]						= "Schrittweite";
const prog_char Text::Stop[]						= "Stop";
const prog_char Text::Switch[]						= "Schalter";
const prog_char Text::System[]						= "System";
const prog_char Text::Target[]						= "Soll";
const prog_char Text::Ticker[]						= "Ticker";
const prog_char Text::Time[]						= "Uhr";
const prog_char Text::Timer[]						= "Uhr";
const prog_char Text::Timers[]						= "Uhren";
const prog_char Text::Toggle[]						= "Wechsel";
const prog_char Text::Trigger[]						= "Trigger";
const prog_char Text::TriggerLowLimit[]				= "Limit Unten";
const prog_char Text::TriggerHighLimit[]			= "Oben";
const prog_char Text::Trim[]						= "Trimm";
const prog_char Text::Type[]						= "Typ";
const prog_char Text::Types[]						= "Typen";
const prog_char Text::unknown[]						= "unbekannt";
const prog_char Text::Volume[]						= "Volumen";
const prog_char Text::Warn[]						= "Warnung";

const prog_char Text::Yes[]							= "Ja";
const prog_char Text::No[]							= "Nein";

const prog_char Text::Bottom[]						= "Unten";
const prog_char Text::Center[]						= "Mitte";
const prog_char Text::Top[]							= "Oben";

const prog_char Text::RFEnabled[]					= " HF Aktiviert ";
const prog_char Text::RFDisabled[]					= "HF Deaktiviert";

const prog_char Text::ChannelNameFormat[]			= "Kanal %d";
const prog_char Text::FollowerNameFormat[]			= "Folger %d";
const prog_char Text::InputNameFormat[]				= "Geber %d";
const prog_char Text::MapNameFormat[]				= "Map %d";
const prog_char Text::MixNameFormat[]				= "Mischer %d";
const prog_char Text::StoreNameFormat[]				= "Speicher %d";
const prog_char Text::TimerNameFormat[]				= "Uhr %d";
const prog_char Text::ModelNameFormat[]				= "Modell %d";
const prog_char Text::TypeNameFormat[]				= "Typ %d";

const prog_char Text::StatusUsageFormat[]			= "Modelle %d/%d Quellen %d/%d";

const prog_char Text::CantDeleteCurrentModel[]		= "Das Modell kann nicht geloescht werden!";
const prog_char Text::CantDeleteCurrentType[]		= "Der Typ kann nicht geloescht werden!";
const prog_char Text::SwitchTypeWarning[]			= "Wirklich den Typ wechseln?";

const prog_char Text::DeleteModelFormat[]			= "Model \"%s\" loeschen?";
const prog_char Text::DeleteSourceFollowerFormat[]	= "Folger \"%s\" loeschen?";
const prog_char Text::DeleteSourceInputFormat[]		= "Geber \"%s\" loeschen?";
const prog_char Text::DeleteSourceMapFormat[]		= "Map \"%s\" loeschen?";
const prog_char Text::DeleteSourceMixFormat[]		= "Mischer \"%s\" loeschen?";
const prog_char Text::DeleteSourceStoreFormat[]		= "Speicher \"%s\" loeschen?";
const prog_char Text::DeleteSourceUnknownFormat[]	= "Quelle \"%s\" loeschen?";
const prog_char Text::DeleteSourceTimerFormat[]		= "Uhr \"%s\" loeschen?";
const prog_char Text::DeleteTypeFormat[]			= "Typ \"%s\" loeschen?";

const prog_char Text::NoModelStorage[]				= "Kein Modellspeicher verfuegbar!";
const prog_char Text::NoSystemStorage[]				= "Kein Systemspeicher verfuegbar!";

const prog_char Text::ModelsCount[]					= "Modelle:  %3u";
const prog_char Text::TypesCount[]					= "Typen:   %3u";
const prog_char Text::SourcesCount[]				= "Quellen: %4u";
const prog_char Text::InternalEEPROMSize[]			= "Internes EEPROM: %5u / %5u";
const prog_char Text::ExternalEEPROMSize[]			= "Externes EEPROM: %5u / %5lu";
const prog_char Text::CPUType[]						= "CPU: "SYSTEM_MCU;

const prog_char Text::LeftSide[]					= "Linke Seite";
const prog_char Text::LeftBottom[]					= "Links Unten";
const prog_char Text::RightSide[]					= "Rechte Seite";
const prog_char Text::RightBottom[]					= "Rechts Unten";
