// Copyright 2010 Peter Stegemann

#include "Base.h"

#include "AVR/Components/Utility.h"

#include <avr/interrupt.h>
#include <avr/wdt.h>

//#define RFOFF_BLINK_DELAY	20

uint8_t ResetReason __attribute__ (( section ( ".noinit")));

void ResetWatchdog( void) __attribute__(( naked)) __attribute__(( section( ".init3")));

void ResetWatchdog( void)
{
	ResetReason = MCUSR;
	MCUSR = 0;
	wdt_disable();
}

Main_Base::Main_Base( void)
		 : lastStoreModifiedTime( 0)
{
}

Main_Base::~Main_Base( void)
{
}

void Main_Base::Run( void)
{
	// Init SPI.
	Spi.Initialize();
	
	// Set up head lcd.
	StatusDisplay.Initialize( SetupService.GetStatusBacklight(), SetupService.GetStatusContrast());
	
	// Show intro on head screen.
	StatusScreen.ShowIntro();

	// Enable interrupts.
	sei();

	// Run ppm engine.
	SignalService.Start();

	// Initialize status.
	StatusService.Initialize();
	//	StatusService.Beep();

	// Initialize input.
	InputService.Initialize();

	// Initialize processing.
	SignalProcessor.Initialize();

	// Run timer.
	StatusTime.Initialize();

	// Run interrupt service last.
	InterruptService.Start();

	// Wait a moment for all services to come up.
	UTILITY::Pause( 5);

	run();
}

void Main_Base::checkRFOff( void)
{
	// Check button turn on state.
	bool CurrentButton;
	
	InputService.GetRotary( NULL, NULL, &CurrentButton);
	
	if( CurrentButton == false)
	{
		// Turn on RF only if the button is _not_ pressed during start.
		SignalService.SetRFEnable( true);
	}
	else
	{
		doRFOff();
	}
}

void Main_Base::doRFOff( void)
{
/*
	// Show rf state on head screen.
	StatusScreen.ShowRfOff();

	bool CurrentButton = true;

	// Wait for button release.
	while( CurrentButton)
	{
		InputService.GetRotary( NULL, NULL, &CurrentButton);
	
		UTILITY::Pause( 5);
	}
*/
	/*	FONT::FontId UseFont = FONT::FID_Medium;
	 
	 LcdSetup->Clear( LCD_65K_RGB::Black);
	 
	 const FONT_Type* Font = FONT::GetFont( UseFont);
	 
	 uint8_t TextLeft = ( LcdSetup->GetWidth() - strlen_P( Text::RFDisabled) * Font->CellWidth) / 2;
	 uint8_t TextTop = ( LcdSetup->GetHeight() - Font->CellHeight) / 2;
	 
	 uint8_t ColorCount = RFOFF_BLINK_DELAY;

	 bool CurrentButton = true;
	 
	 // Wait for button release.
	 while( CurrentButton)
	 {
	 if( ColorCount == RFOFF_BLINK_DELAY)
	 {
	 LcdSetup->Print_P( TextLeft, TextTop, UseFont, LCD_65K_RGB::White, LCD_65K_RGB::Black,
	 LCD::PO_Proportional, Text::RFDisabled);
	 }
	 else if( ColorCount == ( RFOFF_BLINK_DELAY * 2))
	 {
	 LcdSetup->Print_P( TextLeft, TextTop, UseFont, LCD_65K_RGB::Red, LCD_65K_RGB::Black,
	 LCD::PO_Proportional, Text::RFDisabled);
	 
	 ColorCount = 0;
	 }
	 
	 ColorCount++;
	 
	 InputService.GetRotary( NULL, NULL, &CurrentButton);
	 
	 UTILITY::Pause( 5);
	 }*/
}

void Main_Base::Update( void)
{
	uint16_t Uptime = StatusTime.GetUptime();

	// Store modified sources on a regular basis.
	if(( Uptime - lastStoreModifiedTime) >= SYSTEM_STORE_MODIFIED_DELAY)
	{
		lastStoreModifiedTime = Uptime;

		GLOBAL.SignalProcessor.StoreModifiedSources();
	}
}
