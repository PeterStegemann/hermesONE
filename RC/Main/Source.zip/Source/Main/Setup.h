// Copyright 2010 Peter Stegemann

#ifndef MAIN_SETUP_H
#define MAIN_SETUP_H

#include "Base.h"

//#include "AVR/Components/LCD/LCD_S65.h"
#include "AVR/Components/LCD/LCD_SerialOled.h"

class Main_Setup : public Main_Base
{
	private:
		bool hasSetupDisplay;

		uint16_t setupBlankTime;
		uint16_t statusBlankTime;

	public:
//		LCD_S65 SetupDisplay;
		LCD_SerialOled SetupDisplay;

	private:
		virtual void run( void);

		void runOnStatusDisplay( void);
		void doStatusStatus( void);		
		void doStatusMain( void);

		void runOnSetupDisplay( void);
		void doShowIntro( void);
		void doSetupStatus( void);		
		void doSetupMain( void);

	public:
		Main_Setup( void);
		virtual ~Main_Setup( void);

		virtual void Update( void);

		// Set new setup blank time.
		void SetSetupBlankTime( uint16_t SetupBlankTime);
		// Set new status blank time.
		void SetStatusBlankTime( uint16_t StatusBlankTime);
};

extern Main_Setup MainInstance;

#endif
