// Copyright 2010 Peter Stegemann

#ifndef MAIN_NOSCREEN_H
#define MAIN_NOSCREEN_H

#include "AVR/Components/SPI.h"
#include "AVR/Components/LCD/LCD_DOG.h"

class Main_NoScreen
{
	public:
		SPI Spi;
		LCD_DOG LcdStatus;

		void Run( void);

	public:
		~Main_NoScreen( void);
};

#endif
