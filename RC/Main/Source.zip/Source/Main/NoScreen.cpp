// Copyright 2010 Peter Stegemann

#include "Main_NoScreen.h"

#include "Ports.h"

#include "AVR/Components/Utility.h"

#include <avr/interrupt.h>
#include <avr/wdt.h>

#define UTILITY_BitValue( Bit)			( _BV( Bit))

uint8_t ResetReason __attribute__ (( section ( ".noinit")));

void ResetWatchdog( void) __attribute__(( naked)) __attribute__(( section( ".init3")));

void ResetWatchdog( void)
{
	ResetReason = MCUSR;
	MCUSR = 0;
	wdt_disable();
}

Main_NoScreen* Main;
Main_NoScreen MainNoScreen;

int main( void)
{
	// Disable watchdog.
	wdt_disable();
/*
	DDRB |= UTILITY_BitValue( PB5) | UTILITY_BitValue( PB7);

//	OCR1A = 0x00FA; //Tastverhältnis für OC1A
//	OCR1C = 0x00FA; //Tastverhältnis für OC1A
//	ICR1 = 0x01F4; //TOP-Wert einstellen

	OCR1C = 0x0060;
	OCR1A = 0x0060;
	ICR1 = 0x0180; //TOP-Wert einstellen

//	TCCR1A = ( 1 << COM1A1) | ( 1 << COM1C1) | ( 1 << WGM10);
//	TCCR1B = ( 1 << WGM13) | ( 1 << CS11) | ( 1 << CS10);

	while( true)
	{
	}
*/
	Main = &MainNoScreen;
	GLOBAL.Run();

	return( 0);
}

Main_NoScreen::~Main_NoScreen( void)
{
}

void Main_NoScreen::Run( void)
{
	// Enable interrupts.
	sei();

	// Init SPI.
	Spi.Initialize();

	// Set up head lcd.
	LcdStatus.Initialize();

	uint16_t Backlight = 0;

	while( true)
	{
		LcdStatus.PrintFormat( 0, 0, FONT::FID_Medium, "Light: %02d", Backlight);

		LcdStatus.SetBacklight( Backlight);

		Backlight += 1;

		if( Backlight > LCD_DOG_BACKLIGHT_FULL)
		{
			Backlight = 0;
		}

		// Wait a moment for all services to come up.
		UTILITY::Pause( 1000);
	}
}
