// Copyright 2008 Peter Stegemann

#ifndef SIGNAL_SOURCE_SOURCE_H
#define SIGNAL_SOURCE_SOURCE_H

#include "Follower.h"
#include "Input.h"
#include "Map.h"
#include "Mix.h"
#include "Store.h"
#include "Timer.h"

#include "AVR/Components/Types.h"

union Signal_Source_Union
{
	Signal_Source_Follower Follower;
	Signal_Source_Input Input;
	Signal_Source_Map Map;
	Signal_Source_Mix Mix;
	Signal_Source_Store Store;
	Signal_Source_Timer Timer;
};

class Signal_Source_Source
{
	public:
		typedef enum
		{
			T_Empty,
			T_All = T_Empty,
			T_Input,
			T_Map,
			T_Mix,
			T_Store,
			T_Follower,
			T_Timer
		} Type;

		typedef enum
		{
			L_Model,
			L_Type,
			L_Global
		} Level;
	
	
	private:
		Type sourceType;
		uint8_t modelId;
		uint16_t setupSourceId;

		// Value caching is used to reduce duplicate calculations.
		mutable int16_t cachedValue;
		mutable bool valueCached;

		// This is to prevent recursive dead loops.
		mutable bool recursion;

	public:
		// The union which "is" the real object.
		Signal_Source_Union Body;

	public:
		void SetType( Type SourceType);
		Type GetType( void) const;

		Level GetLevel( void) const;

//		void SetModelId( uint8_t ModelId);
		uint8_t GetModelId( void) const;

//		void SetSetupSourceId( uint16_t SetupSourceId);
		uint16_t GetSetupSourceId( void) const;

		// Be aware that to connect sources, they all of them have to be loaded by the
		// SignalProcessor.
		void Initialize( void);
		void Reset( Type SourceType, uint16_t SetupSourceId, uint8_t ModelId);

		// Load setup for this source.
		bool LoadSetup( uint16_t SetupSourceId, uint8_t ModelId);

		// Store setup if modified.
		void StoreIfModified( void);

		// Remove cache flag, so next CalculateValue() call a new value will be calculated.
		void FlushCache( void);

		// Calculate new value or deliver it from the cache.
		int16_t CalculateValue( Signal_Processor* SignalProcessor);

		// Get last calculated value.
		int16_t GetValue( void);
};

#endif
