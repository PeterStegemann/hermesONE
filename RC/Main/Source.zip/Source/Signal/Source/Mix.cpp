// Copyright 2008 Peter Stegemann

#include "Mix.h"

#include "../Processor.h"
#include "Setup/Defines.h"

void Signal_Source_Mix::Initialize( void)
{
	for( uint8_t Index = 0; Index < SETUP_SOURCE_MIX_INPUTS; Index++)
	{
		SignalSourceId[ Index] =
			GLOBAL.SignalProcessor.GetSignalSourceId( Setup.Input[ Index].SetupSourceId);
	}
}

void Signal_Source_Mix::Reset( void)
{
	for( uint8_t Index = 0; Index < SETUP_SOURCE_MIX_INPUTS; Index++)
	{
		SignalSourceId[ Index] = SIGNAL_SOURCE_NONE;
		Setup.Input[ Index].SetupSourceId = SETUP_SOURCE_NONE;
		Setup.Input[ Index].Volume = SIGNAL_SOURCE_MIX_100_PERCENT_VALUE;
	}
}

void Signal_Source_Mix::LoadSetup( uint16_t SetupSourceId)
{
	GLOBAL.SetupService.GetSourceMix( SetupSourceId, &Setup);
}

int16_t Signal_Source_Mix::CalculateValue( Signal_Processor* SignalProcessor)
{
	uint8_t Inputs = 0;
	int32_t Result = 0;

	for( uint8_t Index = 0; Index < SETUP_SOURCE_MIX_INPUTS; Index++)
	{
		uint8_t UseSignalSourceId = SignalSourceId[ Index];

		if( UseSignalSourceId < SIGNAL_SOURCES)
		{
			int32_t Value = SignalProcessor->CalculateSourceValue( UseSignalSourceId);
			Value *= Setup.Input[ Index].Volume;
			Value /= SIGNAL_SOURCE_MIX_100_PERCENT_VALUE;

			Result += Value;

			Inputs++;
		}
		else if( UseSignalSourceId == SIGNAL_SOURCE_FIXED)
		{
			int32_t Value = SIGNAL_MAXIMUM_VALUE;
			Value *= Setup.Input[ Index].Volume;
			Value /= SIGNAL_SOURCE_MIX_100_PERCENT_VALUE;

			Result += Value;

			Inputs++;
		}
	}

	if( Result > SIGNAL_MAXIMUM_VALUE)
	{
		Result = SIGNAL_MAXIMUM_VALUE;
	}
	else if( Result < SIGNAL_MINIMUM_VALUE)
	{
		Result = SIGNAL_MINIMUM_VALUE;
	}

	return( Result);
}
