// Copyright 2008 Peter Stegemann

#include "Channel.h"

#include "Processor.h"
#include "Utility.h"
#include "Setup/Defines.h"

void Signal_Channel::Initialize( void)
{
	cachedValue = SIGNAL_NEUTRAL_VALUE;

	InputSignalSourceId = GLOBAL.SignalProcessor.GetSignalSourceId( Setup.Input.SetupSourceId);
	TrimSignalSourceId = GLOBAL.SignalProcessor.GetSignalSourceId( Setup.Trim.SetupSourceId);
	LimitSignalSourceId = GLOBAL.SignalProcessor.GetSignalSourceId( Setup.Limit.SetupSourceId);
}

void Signal_Channel::Reset( void)
{
	InputSignalSourceId = SIGNAL_SOURCE_NONE;
	TrimSignalSourceId = SIGNAL_SOURCE_NONE;
	LimitSignalSourceId = SIGNAL_SOURCE_NONE;

	Setup.Input.SetupSourceId = SETUP_SOURCE_NONE;
	Setup.Input.Volume = SIGNAL_CHANNEL_INPUT_100_PERCENT_VALUE;
	Setup.Trim.SetupSourceId = SETUP_SOURCE_NONE;
	Setup.Trim.Volume = SIGNAL_CHANNEL_INPUT_100_PERCENT_VALUE;
	Setup.Limit.SetupSourceId = SETUP_SOURCE_NONE;
	Setup.Limit.Volume = SIGNAL_CHANNEL_INPUT_100_PERCENT_VALUE;

	Setup.Reverse = false;

	Setup.Point[ SETUP_CHANNEL_LOW] = - SIGNAL_CHANNEL_100_PERCENT_VALUE;
	Setup.Point[ SETUP_CHANNEL_CENTER] = 0;
	Setup.Point[ SETUP_CHANNEL_HIGH] = SIGNAL_CHANNEL_100_PERCENT_VALUE;
}

int16_t Signal_Channel::CalculateValue( Signal_Processor* SignalProcessor)
{
	int16_t SourceValue =
		Signal_Utility::GetVolumizedSourceValue( SignalProcessor, InputSignalSourceId,
												 SIGNAL_CHANNEL_INPUT_100_PERCENT_VALUE,
												 Setup.Input.Volume);

	int16_t TrimValue =
		Signal_Utility::GetVolumizedSourceValue( SignalProcessor, TrimSignalSourceId,
												 SIGNAL_CHANNEL_INPUT_100_PERCENT_VALUE,
												 Setup.Trim.Volume);

	// If no valid source is set, trim source defaults to 100%, meaning you can set a fixed value
	// with the volume.
	int16_t LimitValue =
		Signal_Utility::GetVolumizedSourceValue( SignalProcessor, LimitSignalSourceId,
												 SIGNAL_MAXIMUM_VALUE,
												 SIGNAL_CHANNEL_INPUT_100_PERCENT_VALUE,
												 Setup.Limit.Volume);

	// Move value into positive realm.
	uint16_t UnsignedValue = ( int32_t) SourceValue - ( int32_t) SIGNAL_MINIMUM_VALUE;

	// Calculate width of one map column.
	uint16_t Width = (( uint16_t) SIGNAL_VALUE_RANGE) / 2;

	// Calculate in which column this value is.
	int32_t Lower, Higher;

	if( SourceValue < 0)
	{
		Lower = Signal_Utility::VolumizeValue( Setup.Point[ SETUP_CHANNEL_LOW],
											   SIGNAL_CHANNEL_100_PERCENT_VALUE, LimitValue);

		Higher = Signal_Utility::AddValues( Setup.Point[ SETUP_CHANNEL_CENTER], TrimValue);
	}
	else if( SourceValue < SIGNAL_MAXIMUM_VALUE)
	{
		Lower = Signal_Utility::AddValues( Setup.Point[ SETUP_CHANNEL_CENTER], TrimValue);

		Higher = Signal_Utility::VolumizeValue( Setup.Point[ SETUP_CHANNEL_HIGH],
											    SIGNAL_CHANNEL_100_PERCENT_VALUE, LimitValue);
	}
	else
	{
		int16_t Result = Signal_Utility::VolumizeValue( Setup.Point[ SETUP_CHANNEL_HIGH],
													    SIGNAL_CHANNEL_100_PERCENT_VALUE,
													    LimitValue);

		if( Setup.Reverse == true)
		{
			Result = -Result;
		}

		return( Result);
	}

	// Now calculate where in the column it is.
	int32_t Where = UnsignedValue % Width;

	int32_t Rise = Higher - Lower;
	int32_t Full = Where * Rise;
	Full /= Width;

	int16_t Result = Lower + Full;

	if( Setup.Reverse == true)
	{
		Result = -Result;
	}

	cachedValue = Result;

	return( Result);
}

int16_t Signal_Channel::GetValue( void)
{
	return cachedValue;
}
