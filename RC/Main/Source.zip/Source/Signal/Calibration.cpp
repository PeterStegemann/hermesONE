// Copyright 2008 Peter Stegemann

#include "Calibration.h"

#include "Defines.h"

Signal_Calibration::Signal_Calibration( void)
{
	Setup.Value[ SETUP_CALIBRATION_HIGH] = 0;
	Setup.Value[ SETUP_CALIBRATION_CENTER] = 0;
	Setup.Value[ SETUP_CALIBRATION_LOW] = 0;
}

int16_t Signal_Calibration::Calibrate( int16_t Value)
{
	if(( Setup.Value[ SETUP_CALIBRATION_CENTER] == Setup.Value[ SETUP_CALIBRATION_LOW]) ||
	   ( Setup.Value[ SETUP_CALIBRATION_CENTER] == Setup.Value[ SETUP_CALIBRATION_HIGH]))
	{
		// Illegal setup, go pass through.
		return( Value);
	}

	int16_t ValueRange;
	int16_t ValueCenter = 0;

	if( Setup.Value[ SETUP_CALIBRATION_LOW] < Setup.Value[ SETUP_CALIBRATION_HIGH])
	{
		if( Value <= Setup.Value[ SETUP_CALIBRATION_CENTER])
		{
			if( Value <= Setup.Value[ SETUP_CALIBRATION_LOW])
			{
				Value = Setup.Value[ SETUP_CALIBRATION_LOW];
			}

			Value -= Setup.Value[ SETUP_CALIBRATION_LOW];
			
			ValueRange = Setup.Value[ SETUP_CALIBRATION_CENTER] -
						 Setup.Value[ SETUP_CALIBRATION_LOW];
			ValueCenter = SIGNAL_MINIMUM_VALUE;
		}
		else
		{
			if( Value >= Setup.Value[ SETUP_CALIBRATION_HIGH])
			{
				Value = Setup.Value[ SETUP_CALIBRATION_HIGH];
			}
			
			Value -= Setup.Value[ SETUP_CALIBRATION_CENTER];
			
			ValueRange = Setup.Value[ SETUP_CALIBRATION_HIGH] -
						 Setup.Value[ SETUP_CALIBRATION_CENTER];
		}
	}
	else
	{
		if( Value <= Setup.Value[ SETUP_CALIBRATION_CENTER])
		{
			if( Value <= Setup.Value[ SETUP_CALIBRATION_HIGH])
			{
				Value = Setup.Value[ SETUP_CALIBRATION_HIGH];
			}
			
			Value -= Setup.Value[ SETUP_CALIBRATION_HIGH];
			
			ValueRange = -( Setup.Value[ SETUP_CALIBRATION_CENTER] -
						    Setup.Value[ SETUP_CALIBRATION_HIGH]);
			ValueCenter = SIGNAL_MAXIMUM_VALUE;
		}
		else
		{
			if( Value >= Setup.Value[ SETUP_CALIBRATION_LOW])
			{
				Value = Setup.Value[ SETUP_CALIBRATION_LOW];
			}
			
			Value -= Setup.Value[ SETUP_CALIBRATION_CENTER];
			
			ValueRange = -( Setup.Value[ SETUP_CALIBRATION_LOW] -
						    Setup.Value[ SETUP_CALIBRATION_CENTER]);
		}
	}

	int32_t CalibratedValue = Value;
	CalibratedValue *= SIGNAL_VALUE_RANGE / 2;
	CalibratedValue /= ValueRange;
	CalibratedValue += ValueCenter;

	return( CalibratedValue);
}
