// Copyright 2010 Peter Stegemann

#include "Utility.h"

#include "Processor.h"

int16_t Signal_Utility::AddValues( int16_t First, int16_t Second)
{
	int32_t ResultValue = First;
	ResultValue += Second;
	
	if( ResultValue < SIGNAL_MINIMUM_VALUE)
	{
		ResultValue = SIGNAL_MINIMUM_VALUE;
	}
	else if( ResultValue > SIGNAL_MAXIMUM_VALUE)
	{
		ResultValue = SIGNAL_MAXIMUM_VALUE;
	}
	
	return( ResultValue);
}

int16_t Signal_Utility::VolumizeValue( int16_t Value, int16_t HundretPercentVolume, int16_t Volume)
{
	int32_t ResultValue = Value;

	ResultValue *= Volume;
	ResultValue /= HundretPercentVolume;

	if( ResultValue < SIGNAL_MINIMUM_VALUE)
	{
		ResultValue = SIGNAL_MINIMUM_VALUE;
	}
	else if( ResultValue > SIGNAL_MAXIMUM_VALUE)
	{
		ResultValue = SIGNAL_MAXIMUM_VALUE;
	}

	return( ResultValue);
}

int16_t Signal_Utility::GetVolumizedSourceValue( Signal_Processor* SignalProcessor,
												 uint8_t SignalSourceId,
												 int16_t HundretPercentVolume, int16_t Volume)
{
	int16_t SourceValue = SignalProcessor->CalculateSourceValue( SignalSourceId);

	return( VolumizeValue( SourceValue, HundretPercentVolume, Volume));
}

int16_t Signal_Utility::GetVolumizedSourceValue( Signal_Processor* SignalProcessor,
												 uint8_t SignalSourceId,
												 int16_t SignalSourceDefault,
												 int16_t HundretPercentVolume, int16_t Volume)
{
	int16_t SourceValue;

	// If no valid source is set, use default.
	if( SignalSourceId < SIGNAL_SOURCES)
	{
		SourceValue = SignalProcessor->CalculateSourceValue( SignalSourceId);
	}
	else
	{
		SourceValue = SignalSourceDefault;
	}

	return( VolumizeValue( SourceValue, HundretPercentVolume, Volume));
}
