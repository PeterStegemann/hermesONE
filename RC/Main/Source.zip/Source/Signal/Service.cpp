// Copyright 2007 Peter Stegemann

#include "Service.h"

#include "Ports.h"
#include "Signal/Utility.h"

#include "AVR/Components/Utility.h"

#include <avr/io.h>	
#include <avr/interrupt.h>
#include <util/delay.h>

// We're using the /8 clock divider.
//#define SIGNAL_SERVICE_PPM_MS_CLOCK_FACTOR	( F_CPU / 100) / 800
#define SIGNAL_SERVICE_PPM_MS_CLOCK_FACTOR	( F_CPU / 100) / 100

// 22.5ms
#define SIGNAL_SERVICE_PPM_SIGNAL_FRAME		((( uint32_t) 225) * SIGNAL_SERVICE_PPM_MS_CLOCK_FACTOR)
//  0.3ms
#define SIGNAL_SERVICE_PPM_SIGNAL_PAUSE		((( uint32_t)   3) * SIGNAL_SERVICE_PPM_MS_CLOCK_FACTOR)
//  1.2ms (Multiplex)
#define SIGNAL_SERVICE_PPM_SIGNAL_CENTER	((( uint32_t)  12) * SIGNAL_SERVICE_PPM_MS_CLOCK_FACTOR)
//  1.1ms (Spektrum Futaba)
//#define SIGNAL_SERVICE_PPM_SIGNAL_NEUTRAL	((( uint32_t)  11) * SIGNAL_SERVICE_PPM_MS_CLOCK_FACTOR)
//  1.1ms
#define SIGNAL_SERVICE_PPM_SIGNAL_RANGE		((( uint32_t)  11) * SIGNAL_SERVICE_PPM_MS_CLOCK_FACTOR)

#define SIGNAL_SERVICE_MATCH_VALUE_1			OCR3A
#define SIGNAL_SERVICE_MATCH_VALUE_2			OCR3B
#define SIGNAL_SERVICE_CLEAR_ON_NEXT_MATCH		SIGNAL_SERVICE_TIMERA = UTILITY_BitValue( COM3A1) | UTILITY_BitValue( COM3B1);
#define SIGNAL_SERVICE_SET_ON_NEXT_MATCH		SIGNAL_SERVICE_TIMERA = UTILITY_BitValue( COM3A1) | UTILITY_BitValue( COM3A0) | UTILITY_BitValue( COM3B1) | UTILITY_BitValue( COM3B0);
#define SIGNAL_SERVICE_MATCH_INTERUPT_ENABLE	OCIE3A
#define SIGNAL_SERVICE_MATCH_INTERUPT			SIG_OUTPUT_COMPARE3A

#define SIGNAL_SERVICE_STATE_PAUSE			0
#define SIGNAL_SERVICE_STATE_SIGNAL			1

static Signal_Service* SignalServiceSingleton;

Signal_Service::Signal_Service( void)
			  : rfEnable( false)
			  , PPMInverted( false)
			  , ppmCenter( SIGNAL_SERVICE_PPM_SIGNAL_CENTER)
			  , channelsValid( false)
			  , waited( 0)
			  , sequence( 0)
{
	SignalServiceSingleton = this;

	// Reset all channels.
	for( uint8_t Count = 0; Count < SIGNAL_SERVICE_CHANNELS; Count++)
	{
		channel[ Count] = ppmCenter;
	}

	// Reset all channel mappings.
	for( uint8_t Count = 0; Count < SIGNAL_SERVICE_CHANNELS; Count++)
	{
		channelMapping[ Count] = Count;
	}

	// Reset all signals.
	// To do this, we just call copyChannles once. This will also calculate the correct sync time.
	channelsValid = true;
	copyChannels();
}

void Signal_Service::copyChannels( void)
{
	if( channelsValid != true)
	{
		// No valid data set yet.
		return;
	}

	// Add up all pauses. One for each channel, one for the sync.
	uint32_t TotalSignalTime = SIGNAL_SERVICE_PPM_SIGNAL_PAUSE * ( SIGNAL_SERVICE_CHANNELS + 1);

	for( uint8_t Count = 0; Count < SIGNAL_SERVICE_CHANNELS; Count++)
	{
		uint16_t currentSignal = channel[ channelMapping[ Count]];
		signal[ Count] = currentSignal;
		TotalSignalTime += currentSignal;
	}

	// Sync time is the first signal.
	sync = SIGNAL_SERVICE_PPM_SIGNAL_FRAME - TotalSignalTime;

	channelsValid = false;
}

void Signal_Service::ProcessSignal( void)
{
	// Every high signal/start phase is followed by a low pause.
	if( signalState == SIGNAL_SERVICE_STATE_PAUSE)
	{
		// Set pause time.
		SIGNAL_SERVICE_MATCH_VALUE_1 = SIGNAL_SERVICE_PPM_SIGNAL_PAUSE;
		SIGNAL_SERVICE_MATCH_VALUE_2 = SIGNAL_SERVICE_PPM_SIGNAL_PAUSE;

		if( PPMInverted)
		{
			// Switch to 1 after this one.
			SIGNAL_SERVICE_SET_ON_NEXT_MATCH
		}
		else
		{
			// Switch to 0 after this one.
			SIGNAL_SERVICE_CLEAR_ON_NEXT_MATCH
		}

		signalState = SIGNAL_SERVICE_STATE_SIGNAL;

		return;
	}

	// Signal phase.
	bool Switch = true;

	if( currentSignal == 0)
	{
		// Set signal width for sync signal. 
		if( sync > 60000)
		{
			// We're not using 60k, but 50k. This leaves a minimum rest of 10k, which gives us
			// enough time for the interrupt code to run.
			SIGNAL_SERVICE_MATCH_VALUE_1 = 50000;
			SIGNAL_SERVICE_MATCH_VALUE_2 = 50000;

			sync -= 50000;

			// Don't switch level and signal on next interrupt.
			Switch = false;
		}
		else
		{
			SIGNAL_SERVICE_MATCH_VALUE_1 = sync;
			SIGNAL_SERVICE_MATCH_VALUE_2 = sync;
		}
	}
	else
	{
		// Set signal width for current signal. 
		SIGNAL_SERVICE_MATCH_VALUE_1 = signal[ currentSignal - 1];
		SIGNAL_SERVICE_MATCH_VALUE_2 = signal[ currentSignal - 1];
	}

	if( Switch == true)
	{
		if( PPMInverted)
		{
			// Switch to 0 after this one.
			SIGNAL_SERVICE_CLEAR_ON_NEXT_MATCH
		}
		else
		{
			// Switch to 1 after this one.
			SIGNAL_SERVICE_SET_ON_NEXT_MATCH
		}

		signalState = SIGNAL_SERVICE_STATE_PAUSE;

		// Skip to next signal.
		currentSignal++;

		if( currentSignal == ( SIGNAL_SERVICE_CHANNELS + 1))
		{
			currentSignal = 0;
			sequence++;

			copyChannels();
		}
	}
}

ISR( SIGNAL_SERVICE_MATCH_INTERUPT)
{
	SignalServiceSingleton->ProcessSignal();
}

void Signal_Service::Start( void)
{
	PPMInverted = GLOBAL.SetupService.GetPPMInverted();
	SetPPMCenter( GLOBAL.SetupService.GetPPMCenter());

	for( uint8_t Index = 0; Index < SIGNAL_SERVICE_CHANNELS; Index++)
	{
		channelMapping[ Index] = GLOBAL.SetupService.GetChannelMapping( Index);
	}

	// Setup RF module lines first.
	// Set enable switch to output and turn RF off.
	UTILITY_SetBit( SIGNAL_SERVICE_DDR, SIGNAL_SERVICE_PPM_ENABLE_1);
	UTILITY_SetBit( SIGNAL_SERVICE_DDR, SIGNAL_SERVICE_PPM_ENABLE_2);
	UTILITY_ClearBit( SIGNAL_SERVICE_PORT, SIGNAL_SERVICE_PPM_ENABLE_1);
	UTILITY_ClearBit( SIGNAL_SERVICE_PORT, SIGNAL_SERVICE_PPM_ENABLE_2);

	// We will start with the start signal.
	currentSignal = 0;

	// Clear counter before use. This will also clear all other settings.
	TCNT3 = 0;
	// Set some lead in time before the first match.
	SIGNAL_SERVICE_MATCH_VALUE_1 = SIGNAL_SERVICE_PPM_SIGNAL_PAUSE;
	SIGNAL_SERVICE_MATCH_VALUE_2 = SIGNAL_SERVICE_PPM_SIGNAL_PAUSE;
	// OCR3A will use PE3 as output, so set it up.
	SIGNAL_SERVICE_DDR |= UTILITY_BitValue( SIGNAL_SERVICE_PPM_OUTPUT_1) |
						  UTILITY_BitValue( SIGNAL_SERVICE_PPM_OUTPUT_2);

	if( PPMInverted)
	{
		// Switch to 1  when matching.
		SIGNAL_SERVICE_SET_ON_NEXT_MATCH
	}
	else
	{
		// Switch to 0 when matching.
		SIGNAL_SERVICE_CLEAR_ON_NEXT_MATCH
	}

	signalState = 1;
	// Clear timer by match and split clock for timer by 8.
	TCCR3B = UTILITY_BitValue( WGM32) | UTILITY_BitValue( CS30);
	// Switch interrupt for compare match on.
	TIMSK3 = UTILITY_BitValue( SIGNAL_SERVICE_MATCH_INTERUPT_ENABLE);
}

void Signal_Service::SetRFEnable( bool Enable)
{
	if( rfEnable == Enable)
	{
		return;
	}

	rfEnable = Enable;

	if( Enable)
	{
		UTILITY_SetBit( SIGNAL_SERVICE_PORT, SIGNAL_SERVICE_PPM_ENABLE_1);
		UTILITY_SetBit( SIGNAL_SERVICE_PORT, SIGNAL_SERVICE_PPM_ENABLE_2);
	}
	else
	{
		UTILITY_ClearBit( SIGNAL_SERVICE_PORT, SIGNAL_SERVICE_PPM_ENABLE_1);
		UTILITY_ClearBit( SIGNAL_SERVICE_PORT, SIGNAL_SERVICE_PPM_ENABLE_2);
	}
}

bool Signal_Service::GetRFEnable( void)
{
	return( rfEnable);
}

void Signal_Service::SetPPMInverted( bool PPMInverted)
{
	PPMInverted = PPMInverted;
}

void Signal_Service::SetPPMCenter( int8_t PPMCenter)
{
	int16_t Value = PPMCenter;
	Value *= SIGNAL_SERVICE_PPM_MS_CLOCK_FACTOR;
	Value += SIGNAL_SERVICE_PPM_SIGNAL_CENTER;

	ppmCenter = Value;
}

void Signal_Service::SetChannelMapping( uint8_t Index, uint8_t ChannelId)
{
	channelMapping[ Index] = ChannelId;
}

void Signal_Service::SetChannel( uint8_t ChannelId, int16_t Value)
{
	if( ChannelId >= SIGNAL_SERVICE_CHANNELS)
	{
		// Invalid channel!
		return;
	}

	// Clip to valid values.
	if( Value > SIGNAL_MAXIMUM_VALUE)
	{
		Value = SIGNAL_MAXIMUM_VALUE;
	}
	else if( Value < SIGNAL_MINIMUM_VALUE)
	{
		Value = SIGNAL_MINIMUM_VALUE;
	}

	int32_t SignalValue = Value * SIGNAL_SERVICE_PPM_SIGNAL_RANGE;
	SignalValue /= SIGNAL_VALUE_RANGE;
	SignalValue += ppmCenter;

	// Wait for the interrupt routine to be ready with fetching the last data set.
	while( ReadyForData() == false)
	{
		_delay_ms( 1);
		waited++;
	}

	channel[ ChannelId] = SignalValue;
}

uint16_t Signal_Service::GetChannel( uint8_t ChannelId)
{
	if( ChannelId >= SIGNAL_SERVICE_CHANNELS)
	{
		// Invalid channel!
		return( 0);
	}

	uint16_t SignalValue = signal[ ChannelId];
//	SignalValue -= ppmCenter;
//	SignalValue *= SIGNAL_VALUE_RANGE;
//	SignalValue /= SIGNAL_SERVICE_PPM_SIGNAL_RANGE;

	return( SignalValue);
}

uint32_t Signal_Service::GetSync( void)
{
	return( sync);
}

void Signal_Service::SetChannelsValid( void)
{
	channelsValid = true;
}

bool Signal_Service::ReadyForData( void)
{
	// As long as the old data was not picked up, we're not ready for new data.
	return( channelsValid != true);
}

uint8_t Signal_Service::GetWaited( void)
{
	return( waited);
}

uint16_t Signal_Service::GetSequence( void)
{
	return( sequence);
}
