// Copyright 2009 Peter Stegemann

#ifndef SETUP_SOURCE_STORE_H
#define SETUP_SOURCE_STORE_H

#include "AVR/Components/Types.h"

struct Setup_Source_Store
{
	uint16_t InputSetupSourceId;

	int16_t Init;
};

#endif
