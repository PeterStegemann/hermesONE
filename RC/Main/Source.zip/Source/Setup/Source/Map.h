// Copyright 2008 Peter Stegemann

#ifndef SETUP_SOURCE_MAP_H
#define SETUP_SOURCE_MAP_H

#include "Tupel.h"

#include "AVR/Components/Types.h"

#define SETUP_SOURCE_MAP_POINTS		7

struct Setup_Source_Map
{
	Setup_Source_Tupel Input;

//	uint8_t Points;

	Setup_Source_Tupel Point[ SETUP_SOURCE_MAP_POINTS];
};

#endif
