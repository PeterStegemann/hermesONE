// Copyright 2008 Peter Stegemann

#ifndef SETUP_SOURCE_MIX_H
#define SETUP_SOURCE_MIX_H

#include "Tupel.h"

#define SETUP_SOURCE_MIX_INPUTS		7

struct Setup_Source_Mix
{
	Setup_Source_Tupel Input[ SETUP_SOURCE_MIX_INPUTS];
};

#endif
