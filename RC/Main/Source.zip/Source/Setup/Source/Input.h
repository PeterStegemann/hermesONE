// Copyright 2008 Peter Stegemann

#ifndef SETUP_SOURCE_INPUT_H
#define SETUP_SOURCE_INPUT_H

#include "AVR/Components/Types.h"

typedef enum
{
	SSIT_Analog,
	SSIT_Button,
	SSIT_Switch,
	SSIT_Ticker,
	SSIT_Rotary,

	SSIT_TypeCount
}
Setup_Source_InputType;

struct Setup_Source_Input
{
	uint8_t Type;

	uint8_t InputIdA;
	uint8_t InputIdB;

	uint8_t Store;
	int16_t Init;
	int16_t Step;
	uint8_t Toggle;

	int16_t Top;
	int16_t Bottom;
};

#endif
