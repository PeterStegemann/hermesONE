// Copyright 2008 Peter Stegemann

#ifndef SETUP_SOURCE_TUPEL_H
#define SETUP_SOURCE_TUPEL_H

#include "AVR/Components/Types.h"

struct Setup_Source_Tupel
{
	uint16_t SetupSourceId;
	int16_t Volume;
};

#endif
