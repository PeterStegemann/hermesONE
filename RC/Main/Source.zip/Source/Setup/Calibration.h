// Copyright 2008 Peter Stegemann

#ifndef SETUP_CALIBRATION_H
#define SETUP_CALIBRATION_H

#include "AVR/Components/Types.h"

#define SETUP_CALIBRATION_VALUES	3

#define SETUP_CALIBRATION_LOW		0
#define SETUP_CALIBRATION_CENTER	1
#define SETUP_CALIBRATION_HIGH		2

struct Setup_Calibration
{
	int16_t Value[ SETUP_CALIBRATION_VALUES];
};

#endif
