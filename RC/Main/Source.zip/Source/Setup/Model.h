// Copyright 2008 Peter Stegemann

#ifndef SETUP_MODEL_H
#define SETUP_MODEL_H

#include "Channel.h"
#include "Defines.h"

#include "Signal/Service.h"

struct Setup_Model
{
	uint8_t State;
	uint8_t SelectedTypeId;

	char Name[ SETUP_MODEL_NAME_SIZE];

	uint16_t StatusTimeId;
	uint16_t StatusSourceId[ SETUP_STATUS_SOURCES];

	Setup_Channel Channel[ SIGNAL_SERVICE_CHANNELS];
	char ChannelName[ SIGNAL_SERVICE_CHANNELS][ SETUP_CHANNEL_NAME_SIZE];
};

#endif
