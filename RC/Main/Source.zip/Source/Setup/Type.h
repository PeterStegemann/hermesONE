// Copyright 2008 Peter Stegemann

#ifndef SETUP_TYPE_H
#define SETUP_TYPE_H

#include "Defines.h"

struct Setup_Type
{
	uint8_t State;

	char Name[ SETUP_MODEL_TYPE_NAME_SIZE];
};

#endif
