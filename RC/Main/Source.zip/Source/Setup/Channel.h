// Copyright 2008 Peter Stegemann

#ifndef SETUP_CHANNEL_H
#define SETUP_CHANNEL_H

#include "Source/Tupel.h"

#include "AVR/Components/Types.h"

#define SETUP_CHANNEL_POINTS	3

#define SETUP_CHANNEL_LOW		0
#define SETUP_CHANNEL_CENTER	1
#define SETUP_CHANNEL_HIGH		2

struct Setup_Channel
{
	Setup_Source_Tupel Input;
	Setup_Source_Tupel Trim;
	Setup_Source_Tupel Limit;

	bool Reverse;

	int16_t Point[ SETUP_CHANNEL_POINTS];
};

#endif
