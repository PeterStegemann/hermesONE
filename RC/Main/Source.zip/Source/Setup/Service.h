// Copyright 2007 Peter Stegemann

#ifndef SERVICE_H
#define SERVICE_H

#include "Signal/Source/Source.h"

#define EEPROMAddress( Address)	(( uint16_t) &( Address))

class Setup_Battery;
class Setup_Calibration;
class Setup_Channel;

class Setup_Service
{
	public:
		typedef enum
		{
			MS_Empty,
			MS_Used
		}
		ModelState;

		typedef enum
		{
			TS_Empty,
			TS_Used
		}
		TypeState;

	private:
		uint8_t selectedModelId;

		void writeString( const char* String, void* EepromString, uint8_t EepromSize);
		void readString( char* String, uint8_t Size, void* EepromString, uint8_t EepromSize);

	public:
		Setup_Service( void);

		void SetOwner( const char* Owner);
		// Supply the size of the target buffer, including room for termination.
		char* GetOwner( char* Owner, uint8_t Size);

		void SetSetupBacklight( uint8_t StatusBacklight);
		uint8_t GetSetupBacklight( void);

		void SetSetupBlankTime( uint16_t StatusBlankTime);
		uint16_t GetSetupBlankTime( void);

		void SetStatusBacklight( uint8_t StatusBacklight);
		uint8_t GetStatusBacklight( void);

		void SetStatusContrast( uint8_t StatusContrast);
		uint8_t GetStatusContrast( void);

		void SetStatusBlankTime( uint16_t StatusBlankTime);
		uint16_t GetStatusBlankTime( void);

		void SetBattery( const Setup_Battery* Battery);
		void GetBattery( Setup_Battery* Battery);

		void SetShowIntro( bool ShowIntro);
		bool GetShowIntro( void);

		void SetCalibration( uint8_t Index, const Setup_Calibration* Calibration);
		void GetCalibration( uint8_t Index, Setup_Calibration* Calibration);

		void SetPPMInverted( bool PPMInverted);
		bool GetPPMInverted( void);

		void SetPPMCenter( int8_t PPMCenter);
		int8_t GetPPMCenter( void);
	
		void SetChannelMapping( uint8_t Index, uint8_t ChannelId);
		uint8_t GetChannelMapping( uint8_t Index);

		// Find next free model slot in the setup memory. Returns false if all slots are used.
		bool FindNextEmptyModel( uint8_t* ModelId);
		// Find next free type slot in the setup memory. Returns false if all slots are used.
		bool FindNextEmptyType( uint8_t* TypeId);

		typedef enum
		{
			CMO_Empty	= 0b00000000,
			CMO_Used	= 0b00000001
		}
		CountModelsOptions;

		uint8_t CountModels( CountModelsOptions UseCountModelsOptions = CMO_Empty);

		typedef enum
		{
			CTO_Empty	= 0b00000000,
			CTO_Used	= 0b00000001
		}
		CountTypesOptions;

		uint8_t CountTypes( CountTypesOptions UseCountTypesOptions = CTO_Empty);

		void SetModelName( uint8_t ModelId, const char* ModelName);
		// Supply the size of the target buffer, including room for termination.
		char* GetModelName( uint8_t ModelId, char* ModelName, uint8_t Size);

		void SetTypeName( uint8_t TypeId, const char* TypeName);
		// Supply the size of the target buffer, including room for termination.
		char* GetTypeName( uint8_t TypeId, char* TypeName, uint8_t Size);

		// State of model.
		void SetModelState( uint8_t ModelId, ModelState State);
		ModelState GetModelState( uint8_t ModelId);

		// State of type.
		void SetTypeState( uint8_t TypeId, TypeState State);
		TypeState GetTypeState( uint8_t TypeId);

		// Find next free source slot in the setup memory. Returns false if all slots are used.
		bool FindNextEmptySource( uint16_t* SetupSourceId);

		typedef enum
		{
			CSO_Empty	= 0b00000000,
			CSO_Used	= 0b00000001
		}
		CountSourcesOptions;

		uint16_t CountSources( CountSourcesOptions UseCountSourcesOptions = CSO_Empty);

		// Name of source.
		void SetSourceName( uint16_t SetupSourceId, const char* SourceName);
		// Supply the size of the target buffer, including room for termination.
		char* GetSourceName( uint16_t SetupSourceId, char* SourceName, uint8_t Size);

		// Type of source.
		void SetSourceType( uint16_t SetupSourceId, Signal_Source_Source::Type SourceType);
		Signal_Source_Source::Type GetSourceType( uint16_t SetupSourceId);

		// Model the source belongs to.
		void SetSourceModelId( uint16_t SetupSourceId, uint8_t ModelId);
		uint8_t GetSourceModelId( uint16_t SetupSourceId);

		void SetSourceFollower( uint16_t SetupSourceId, const Setup_Source_Follower* SourceFollower);
		void GetSourceFollower( uint16_t SetupSourceId, Setup_Source_Follower* SourceFollower);
		void SetSourceInput( uint16_t SetupSourceId, const Setup_Source_Input* SourceInput);
		void GetSourceInput( uint16_t SetupSourceId, Setup_Source_Input* SourceInput);
		void SetSourceMap( uint16_t SetupSourceId, const Setup_Source_Map* SourceMap);
		void GetSourceMap( uint16_t SetupSourceId, Setup_Source_Map* SourceMap);
		void SetSourceMix( uint16_t SetupSourceId, const Setup_Source_Mix* SourceMix);
		void GetSourceMix( uint16_t SetupSourceId, Setup_Source_Mix* SourceMix);
		void SetSourceStore( uint16_t SetupSourceId, const Setup_Source_Store* SourceStore);
		void GetSourceStore( uint16_t SetupSourceId, Setup_Source_Store* SourceStore);
		void SetSourceTimer( uint16_t SetupSourceId, const Setup_Source_Timer* SourceTimer);
		void GetSourceTimer( uint16_t SetupSourceId, Setup_Source_Timer* SourceTimer);

		void SetSource( uint16_t SetupSourceId, const Signal_Source_Source* SignalSource);

		void SetSelectedModelId( uint8_t ModelId);
		uint8_t GetSelectedModelId( void);

		void SetSelectedTypeId( uint8_t ModelId, uint8_t TypeId);
		uint8_t GetSelectedTypeId( uint8_t ModelId);

		void SetChannelName( uint8_t ModelId, uint8_t ChannelId, const char* ChannelName);
		// Supply the size of the target buffer, including room for termination.
		char* GetChannelName( uint8_t ModelId, uint8_t ChannelId, char* ChannelName,
							  uint8_t Size);

		// Same as above for selected model id.
		void SetChannelName( uint8_t ChannelId, const char* ChannelName);
		// Supply the size of the target buffer, including room for termination.
		char* GetChannelName( uint8_t ChannelId, char* ChannelName, uint8_t Size);
	
		void SetChannel( uint8_t ModelId, uint8_t ChannelId, const Setup_Channel* Channel);
		void GetChannel( uint8_t ModelId, uint8_t ChannelId, Setup_Channel* Channel);

		// Set status time source.
		void SetStatusTimeId( uint8_t ModelId, uint16_t SetupSourceId);
		uint16_t GetStatusTimeId( uint8_t ModelId);
		// Same as above for selected model id.
		void SetStatusTimeId( uint16_t SetupSourceId);
		uint16_t GetStatusTimeId( void);

		// Set status info source.
		void SetStatusSourceId( uint8_t ModelId, uint8_t StatusId, uint16_t SetupSourceId);
		uint16_t GetStatusSourceId( uint8_t ModelId, uint8_t StatusId);
		// Same as above for selected model id.
		void SetStatusSourceId( uint8_t StatusId, uint16_t SetupSourceId);
		uint16_t GetStatusSourceId( uint8_t StatusId);

		// Reset all settings.
		void Reset( void);
		// Reset model.
		void ResetModel( uint8_t ModelId, ModelState State);
		// Reset type.
		void ResetType( uint8_t TypeId, TypeState State);
		// Reset source.
		void ResetSource( Signal_Source_Source* SignalSource, uint8_t ModelId,
						  uint16_t SetupSourceId, Signal_Source_Source::Type SourceType);
};

#endif
