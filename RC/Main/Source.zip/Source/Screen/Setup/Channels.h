// Copyright 2008 Peter Stegemann

#ifndef SCREEN_SETUP_CHANNELS_H
#define SCREEN_SETUP_CHANNELS_H

#include "BaseList.h"
#include "GUI/Setup/Gauge.h"
#include "GUI/Setup/Label.h"
#include "Setup/Defines.h"

class Screen_Setup_Channels : public Screen_Setup_BaseList
{
	private:
		GUI_Setup_Label channelLabel[ SCREEN_SETUP_BASELIST_MAXIMUM_LINES];
		char channelName[ SCREEN_SETUP_BASELIST_MAXIMUM_LINES][ SETUP_CHANNEL_NAME_SIZE + 1];
		GUI_Setup_Gauge valueGauge[ SCREEN_SETUP_BASELIST_MAXIMUM_LINES];

		virtual void display( void);
		virtual void update( void);
		virtual bool processMenu( DoMenuResult Result);

		void reDisplay( void);
		void displayMarker( void);

		void doChanged( void);
		void doSelect( uint8_t LineId);

	public:
		Screen_Setup_Channels( void);
};

#endif
