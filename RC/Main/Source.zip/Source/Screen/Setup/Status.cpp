// Copyright 2007 Peter Stegemann

#include "Status.h"

#include "Main/Setup.h"
#include "Setup/Defines.h"
#include "Signal/Service.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"

Screen_Setup_Status::Screen_Setup_Status( void)
				   : Screen_Setup_Base( 0b1, Text::Status, false)
{
	statusGauge[ SETUP_STATUS_SOURCE_LEFT_SIDE].SetOptions(
		( GUI_Setup_Gauge::Options)( GUI_Setup_Gauge::O_Vertical |
									 GUI_Setup_Gauge::O_CenterLine |
									 GUI_Setup_Gauge::O_Reverse |
									 GUI_Setup_Gauge::O_Marker |
									 GUI_Setup_Gauge::O_MarkerLookRight));

	statusGauge[ SETUP_STATUS_SOURCE_RIGHT_SIDE].SetOptions(
		( GUI_Setup_Gauge::Options)( GUI_Setup_Gauge::O_Vertical |
									 GUI_Setup_Gauge::O_CenterLine |
									 GUI_Setup_Gauge::O_Reverse |
									 GUI_Setup_Gauge::O_Marker |
									 GUI_Setup_Gauge::O_MarkerLookLeft));

	statusGauge[ SETUP_STATUS_SOURCE_LEFT_BOTTOM].SetOptions(
		( GUI_Setup_Gauge::Options)( GUI_Setup_Gauge::O_CenterLine |
									 GUI_Setup_Gauge::O_Marker |
									 GUI_Setup_Gauge::O_MarkerLookUp));

	statusGauge[ SETUP_STATUS_SOURCE_RIGHT_BOTTOM].SetOptions(
		( GUI_Setup_Gauge::Options)( GUI_Setup_Gauge::O_CenterLine |
									 GUI_Setup_Gauge::O_Marker |
									 GUI_Setup_Gauge::O_MarkerLookUp));

	// Find sources to display.
	uint8_t SourceLine = 0;

	while( SourceLine < SETUP_STATUS_SOURCES)
	{
		uint16_t SetupSourceId = GLOBAL.SetupService.GetStatusSourceId(
			GLOBAL.SetupService.GetSelectedModelId(), SourceLine);

		source[ SourceLine] = GLOBAL.SignalProcessor.GetSignalSourceId( SetupSourceId);

		SourceLine++;
	}
}

void Screen_Setup_Status::display( void)
{
	// Adjust gauges to frame and set them up.
	uint16_t LeftGaugeLeft = frameLeft + 1;
	uint16_t RightGaugeLeft = ( frameLeft + frameWidth + 5) - SCREEN_SETUP_BASE_GAUGE_THICKNESS;
	uint16_t BottomGaugeSize = ( frameWidth / 2) - 2;
	uint16_t BottomGaugeTop = frameTop + frameHeight - SCREEN_SETUP_BASE_LINE_HEIGHT + 1;
	uint16_t SideGaugeTop = BottomGaugeTop - BottomGaugeSize - 2;

	uint16_t InnerLeft = LeftGaugeLeft + SCREEN_SETUP_BASE_GAUGE_THICKNESS + 1;
	uint16_t InnerRight = RightGaugeLeft - 1;
	uint16_t InnerWidth = InnerRight - InnerLeft - 2;

	statusGauge[ SETUP_STATUS_SOURCE_LEFT_SIDE].SetDimensions( LeftGaugeLeft, SideGaugeTop,
		SCREEN_SETUP_BASE_GAUGE_THICKNESS, BottomGaugeSize);
	statusGauge[ SETUP_STATUS_SOURCE_RIGHT_SIDE].SetDimensions( RightGaugeLeft, SideGaugeTop,
		SCREEN_SETUP_BASE_GAUGE_THICKNESS, BottomGaugeSize);
	statusGauge[ SETUP_STATUS_SOURCE_LEFT_BOTTOM].SetDimensions( LeftGaugeLeft, BottomGaugeTop,
		BottomGaugeSize, SCREEN_SETUP_BASE_GAUGE_THICKNESS);
	statusGauge[ SETUP_STATUS_SOURCE_RIGHT_BOTTOM].SetDimensions( frameLeft + BottomGaugeSize + 3,
		BottomGaugeTop, BottomGaugeSize, SCREEN_SETUP_BASE_GAUGE_THICKNESS);

	uint8_t Line = 3;

	const FONT_Type* Font = FONT::GetFont( FONT::FID_Large);
	uint8_t TextLeft;

	char ModelName[ SETUP_MODEL_NAME_SIZE + 1];
	GLOBAL.SetupService.GetModelName( GLOBAL.SetupService.GetSelectedModelId(), ModelName,
									  sizeof( ModelName));

	TextLeft = frameLeft + (( frameWidth - strlen( ModelName) * Font->CellWidth) / 2);
	GLOBAL.SetupDisplay.Print( TextLeft, frameTop + ( Line++ * Font->CellHeight), FONT::FID_Large,
							   LCD_65K_RGB::White, LCD_65K_RGB::Black, LCD::PO_Proportional,
							   ModelName);

	Line++;

	TextLeft = frameLeft + (( frameWidth - strlen_P( Text::RFDisabled) * Font->CellWidth) / 2);
	rfStatusLabel.SetDimensions( TextLeft, frameTop + ( Line++ * Font->CellHeight));
	rfStatusLabel.SetFont( FONT::FID_Large);

	Line++;

	batteryLabel.SetDimensions( InnerLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT));
	batteryLabel.SetFont( FONT::FID_Large);
	batteryGauge.SetDimensions( InnerLeft + 42,
							    frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT) + 1,
								InnerWidth - 42, SCREEN_SETUP_BASE_GAUGE_THICKNESS);

	Line++;

	TextLeft = frameLeft + (( frameWidth - ( 5 * Font->CellWidth)) / 2);
	timeLabel.SetDimensions( TextLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT));
	timeLabel.SetFont( FONT::FID_Large);

	GLOBAL.SetupDisplay.PrintFormat_P( frameLeft + 45, BottomGaugeTop - Font->CellHeight,
									   FONT::FID_Large, LCD_65K_RGB::White, LCD_65K_RGB::Black,
									   LCD::PO_Proportional, Text::StatusUsageFormat,
									   GLOBAL.SetupService.CountModels( Setup_Service::CMO_Used),
									   SETUP_MODELS,
									   GLOBAL.SetupService.CountSources( Setup_Service::CSO_Used),
									   SETUP_SOURCES);
}

void Screen_Setup_Status::update( void)
{
	Screen_Setup_Base::update();

	// Print all channels.
	for( uint8_t SourceLine = 0; SourceLine < SETUP_STATUS_SOURCES; SourceLine++)
	{
		statusGauge[ SourceLine].Display( SIGNAL_MINIMUM_VALUE, SIGNAL_MAXIMUM_VALUE,
										  GLOBAL.SignalProcessor.GetSourceValue(
											  source[ SourceLine]));
	}

	bool RFEnabled = GLOBAL.SignalService.GetRFEnable();

	const prog_char* RFState;

	if( RFEnabled)
	{
		RFState = Text::RFEnabled;
		rfStatusLabel.ForegroundColor = LCD_65K_RGB::Green;
	}
	else
	{
		RFState = Text::RFDisabled;
		rfStatusLabel.ForegroundColor = LCD_65K_RGB::Red;
	}

	rfStatusLabel.Display_P( RFState);

	// Battery
	batteryLabel.SetVoltage( GLOBAL.StatusBattery.GetVoltage());

	batteryGauge.Display( GLOBAL.StatusBattery.GetMinimumVoltage(),
						  GLOBAL.StatusBattery.GetMaximumVoltage(),
						  GLOBAL.StatusBattery.GetVoltage());

	// Time
	uint16_t SetupSourceId = GLOBAL.SetupService.GetStatusTimeId();

	if( SetupSourceId == SETUP_SOURCE_NONE)
	{
		timeLabel.SetTime( GLOBAL.StatusTime.GetUptime());
	}
	else
	{
		uint8_t TimeId = GLOBAL.SignalProcessor.GetSignalSourceId( SetupSourceId);

		Signal_Source_Source* Source = GLOBAL.SignalProcessor.GetSource( TimeId);

		if( Source->GetType() == Signal_Source_Source::T_Timer)
		{
			timeLabel.SetTime( Source->Body.Timer.GetTime());
		}
	}
}

bool Screen_Setup_Status::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Selected :	return( false);

		default : break;
	}

	return( true);
}
