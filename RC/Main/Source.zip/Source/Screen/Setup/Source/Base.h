// Copyright 2012 Peter Stegemann

#ifndef SCREEN_SETUP_SOURCE_BASE_H
#define SCREEN_SETUP_SOURCE_BASE_H

#include "../Base.h"
#include "GUI/Setup/Gauge.h"
#include "GUI/Setup/Label.h"
#include "GUI/Setup/TextInput.h"

class Screen_Setup_Source_Base : public Screen_Setup_Base
{
	private:
		GUI_Setup_Label currentNameLabel;
		GUI_Setup_Label currentNameValueLabel;
		char currentName[ SETUP_SOURCE_NAME_SIZE + 1];
		GUI_Setup_TextInput currentNameInput;

		GUI_Setup_Gauge currentGauge;

		void doCurrentName( void);

	protected:
		uint8_t signalSourceId;
		uint16_t setupSourceId;

		Signal_Source_Source* source;

		virtual void display( void);
		virtual void update( void);
		virtual bool processMenu( DoMenuResult Result);

		static void doUpdate( void* Object);

		Screen_Setup_Source_Base( uint8_t SignalSourceId, uint32_t MenuPattern,
								  const prog_char* Title);
};

#endif
