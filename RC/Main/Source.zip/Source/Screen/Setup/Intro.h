// Copyright 2007 Peter Stegemann

#ifndef SCREEN_SETUP_INTRO_H
#define SCREEN_SETUP_INTRO_H

class Screen_Setup_Intro
{
	public:
		Screen_Setup_Intro( void);

		// Run screen.
		void Run( void);
};

#endif
