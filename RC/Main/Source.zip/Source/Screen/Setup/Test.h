// Copyright 2007 Peter Stegemann

#ifndef SCREEN_SETUP_TEST_H
#define SCREEN_SETUP_TEST_H

#include "Screen.h"

class Screen_Setup_Test : public Screen_Setup_Base
{
	private:

	public:
		Screen_Setup_Test( void);

		// Run this screen.
		void Run( void);
};

#endif
