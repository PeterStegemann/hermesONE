// Copyright 2008 Peter Stegemann

#include "Channels.h"

#include "Channel.h"
#include "Main/Setup.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"

#include <string.h>

Screen_Setup_Channels::Screen_Setup_Channels( void)
					 : Screen_Setup_BaseList( Text::Channels)
{
	if( SIGNAL_SERVICE_CHANNELS < SCREEN_SETUP_BASELIST_MAXIMUM_LINES)
	{
		visibleLines = SIGNAL_SERVICE_CHANNELS;
	}

	for( uint8_t ChannelLine = 0; ChannelLine < visibleLines; ChannelLine++)
	{
		channelLabel[ ChannelLine].SetText( channelName[ ChannelLine]);

		valueGauge[ ChannelLine].SetOptions(
			( GUI_Setup_Gauge::Options)( GUI_Setup_Gauge::O_Percentage |
										 GUI_Setup_Gauge::O_DualPercentage |
										 GUI_Setup_Gauge::O_CenterLine |
										 GUI_Setup_Gauge::O_Marker));
	}
}

void Screen_Setup_Channels::display( void)
{
	displayMarker();

	// Adjust gauges to frame and set them up.
	const FONT_Type* Font = FONT::GetFont( SCREEN_SETUP_BASE_MAIN_FONT);

	uint16_t GaugeLeft = menuLeft + SETUP_CHANNEL_NAME_SIZE * Font->CellWidth;
	uint16_t GaugeWidth = frameWidth - ( GaugeLeft - frameLeft) - 1;	

	uint8_t Line = 0;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop, SCREEN_SETUP_BASE_MAIN_FONT,
								 LCD_65K_RGB::WarmYellow, LCD_65K_RGB::Black,
								 LCD::PO_Proportional, Text::Exit);

	Line += 2;

	setupScrollMarkers( Line);

	for( uint8_t ChannelLine = 0; ChannelLine < visibleLines; ChannelLine++)
	{
		uint16_t LineTop = frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT);

		channelLabel[ ChannelLine].SetDimensions( menuLeft, LineTop);
		valueGauge[ ChannelLine].SetDimensions( GaugeLeft, LineTop, GaugeWidth,
												SCREEN_SETUP_BASE_GAUGE_THICKNESS);

		Line++;
	}

	reDisplay();
}

void Screen_Setup_Channels::reDisplay( void)
{
	// Clear all channels.
	for( uint8_t SourceLine = 0; SourceLine < visibleLines; SourceLine++)
	{
		valueGauge[ SourceLine].Clear();
	}

	// Update labels.
	for( uint8_t ChannelLine = 0; ChannelLine < visibleLines; ChannelLine++)
	{
		channelLabel[ ChannelLine].Clear();
		GLOBAL.SetupService.GetChannelName( firstLine + ChannelLine, channelName[ ChannelLine],
										    SETUP_CHANNEL_NAME_SIZE + 1);
		channelLabel[ ChannelLine].Display();
	}

	reDisplayMarkers( SIGNAL_SERVICE_CHANNELS);
}

void Screen_Setup_Channels::update( void)
{
	Screen_Setup_BaseList::update();

	// Print all channels.
	for( uint8_t ChannelLine = 0; ChannelLine < visibleLines; ChannelLine++)
	{
		valueGauge[ ChannelLine].Display( SIGNAL_MINIMUM_VALUE, SIGNAL_MAXIMUM_VALUE,
										  GLOBAL.SignalProcessor.GetChannelValue(
											  firstLine + ChannelLine));
	}
}

bool Screen_Setup_Channels::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Selected :
		{
			if( currentMenuEntry == 0)
			{
				return( false);
			}
			else
			{
				doSelect( currentMenuEntry - 1);
			}

			ReDisplay();
		}
		break;

		case DMR_Changed :
		{
			doChanged();
		}
		break;

		default : break;
	}

	return( true);
}

void Screen_Setup_Channels::displayMarker( void)
{
	uint8_t MarkerLine = currentMenuEntry;

	if( MarkerLine > 0)
	{
		// Add one for the gap after exit.
		MarkerLine++;
	}

	menuMarker.Display( markerLeft, markerTop + ( MarkerLine * SCREEN_SETUP_BASE_LINE_HEIGHT));
}

void Screen_Setup_Channels::doChanged( void)
{
	if( Screen_Setup_BaseList::doChanged( SIGNAL_SERVICE_CHANNELS, 1))
	{
		reDisplay();
	}

	displayMarker();
}

void Screen_Setup_Channels::doSelect( uint8_t LineId)
{
	// Just to play safe...
	if( LineId >= visibleLines)
	{
		return;
	}

	Screen_Setup_Channel ChannelScreen( firstLine + LineId);
	ChannelScreen.Run();
}
