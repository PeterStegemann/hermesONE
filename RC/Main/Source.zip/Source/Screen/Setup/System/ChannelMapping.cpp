// Copyright 2011 Peter Stegemann

#include "ChannelMapping.h"

#include "GUI/Setup/Select.h"
#include "Main/Setup.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"

#include <string.h>

Screen_Setup_System_ChannelMapping::Screen_Setup_System_ChannelMapping( void)
								  : Screen_Setup_BaseList( Text::ChannelMapping)
{
	if( SIGNAL_SERVICE_CHANNELS < SCREEN_SETUP_BASELIST_MAXIMUM_LINES)
	{
		visibleLines = SIGNAL_SERVICE_CHANNELS;
	}

	for( uint8_t ChannelLine = 0; ChannelLine < visibleLines; ChannelLine++)
	{
		targetChannelLabel[ ChannelLine].SetText( targetChannelName[ ChannelLine]);
		sourceChannelLabel[ ChannelLine].SetText_P( Text::Int8Format);
	}
}

void Screen_Setup_System_ChannelMapping::display( void)
{
	displayMarker();
	
	// Adjust gauges to frame and set them up.
	const FONT_Type* Font = FONT::GetFont( SCREEN_SETUP_BASE_MAIN_FONT);

	uint16_t SourceLeft = menuLeft + SETUP_CHANNEL_NAME_SIZE * Font->CellWidth;

	uint8_t Line = 0;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop, SCREEN_SETUP_BASE_MAIN_FONT,
								 LCD_65K_RGB::WarmYellow, LCD_65K_RGB::Black,
								 LCD::PO_Proportional, Text::Exit);

	Line += 2;

	setupScrollMarkers( Line);

	for( uint8_t ChannelLine = 0; ChannelLine < visibleLines; ChannelLine++)
	{
		uint16_t LineTop = frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT);

		targetChannelLabel[ ChannelLine].SetDimensions( menuLeft, LineTop);
		sourceChannelLabel[ ChannelLine].SetDimensions( SourceLeft, LineTop);

		Line++;
	}

	reDisplay();
}

void Screen_Setup_System_ChannelMapping::updateSourceChannel( void* Object, GUI_Setup_Label* Label,
														      int8_t Value)
{
	Label->SetValue( Value + 1);
	Label->Display();

	uint8_t ChannelIndex = (( Screen_Setup_System_ChannelMapping*) Object)->currentMenuEntry -
						   (( Screen_Setup_System_ChannelMapping*) Object)->firstLine;

	GLOBAL.SignalService.SetChannelMapping( ChannelIndex, Value);
}

void Screen_Setup_System_ChannelMapping::reDisplay( void)
{
	// Update labels.
	for( uint8_t ChannelLine = 0; ChannelLine < visibleLines; ChannelLine++)
	{
		uint8_t ChannelIndex = firstLine + ChannelLine;

		targetChannelLabel[ ChannelLine].Clear();
		sourceChannelLabel[ ChannelLine].Clear();

		snprintf_P( targetChannelName[ ChannelLine], SETUP_CHANNEL_NAME_SIZE + 1,
				    Text::ChannelNameFormat, ChannelIndex + 1);
		sourceChannelLabel[ ChannelLine].SetValue(
			GLOBAL.SetupService.GetChannelMapping( ChannelIndex) + 1);

		targetChannelLabel[ ChannelLine].Display();
		sourceChannelLabel[ ChannelLine].Display();
	}

	reDisplayMarkers( SIGNAL_SERVICE_CHANNELS);
}

bool Screen_Setup_System_ChannelMapping::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Selected :
		{
			if( currentMenuEntry == 0)
			{
				return( false);
			}
			else
			{
				uint8_t ChannelIndex = ( currentMenuEntry - firstLine) - 1;
				int8_t SourceChannel = GLOBAL.SetupService.GetChannelMapping( ChannelIndex);

				if( GUI_Setup_Select::DoSelect( &SourceChannel, 0, SIGNAL_SERVICE_CHANNELS - 1, 1,
										  &menuMarker,
										  &( sourceChannelLabel[ currentMenuEntry - 1]),
										  this, NULL, &updateSourceChannel))
				{
					GLOBAL.SetupService.SetChannelMapping( ChannelIndex, SourceChannel);
				}
			}
		}
		break;

		case DMR_Changed :
		{
			doChanged();
		}
		break;

		default : break;
	}
	
	return( true);
}

void Screen_Setup_System_ChannelMapping::displayMarker( void)
{
	uint8_t MarkerLine = currentMenuEntry;

	if( MarkerLine > 0)
	{
		// Add one for the gap after exit.
		MarkerLine++;
	}

	menuMarker.Display( markerLeft, markerTop + ( MarkerLine * SCREEN_SETUP_BASE_LINE_HEIGHT));
}

void Screen_Setup_System_ChannelMapping::doChanged( void)
{
	if( Screen_Setup_BaseList::doChanged( SIGNAL_SERVICE_CHANNELS, 1))
	{
		reDisplay();
	}

	displayMarker();
}
