// Copyright 2011 Peter Stegemann

#ifndef SCREEN_SETUP_SYSTEM_CHANNELMAPPING_H
#define SCREEN_SETUP_SYSTEM_CHANNELMAPPING_H

#include "../BaseList.h"
#include "GUI/Setup/Gauge.h"
#include "GUI/Setup/Label.h"
#include "Setup/Defines.h"

class Screen_Setup_System_ChannelMapping : public Screen_Setup_BaseList
{
	private:
		GUI_Setup_Label targetChannelLabel[ SCREEN_SETUP_BASELIST_MAXIMUM_LINES];
		char targetChannelName[ SCREEN_SETUP_BASELIST_MAXIMUM_LINES][ SETUP_CHANNEL_NAME_SIZE + 1];
		GUI_Setup_Label sourceChannelLabel[ SCREEN_SETUP_BASELIST_MAXIMUM_LINES];

		virtual void display( void);
		virtual bool processMenu( DoMenuResult Result);

		void reDisplay( void);
		void displayMarker( void);

		static void updateSourceChannel( void* Object, GUI_Setup_Label* Label, int8_t Value);

		void doChanged( void);
		void doSelect( uint8_t LineId);

	public:
		Screen_Setup_System_ChannelMapping( void);
};

#endif
