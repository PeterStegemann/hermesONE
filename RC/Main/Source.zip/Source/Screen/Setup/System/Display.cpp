// Copyright 2011 Peter Stegemann

#include "Display.h"

#include "GUI/Setup/Select.h"
#include "Text/Text.h"
#include "AVR/Components/Utility.h"

Screen_Setup_System_Display::Screen_Setup_System_Display( void)
						   : Screen_Setup_Base( 0b10110010100101, Text::Display)
						   , showIntro( GLOBAL.SetupService.GetShowIntro())
						   , setupBacklight( GLOBAL.SetupService.GetSetupBacklight())
						   , setupBlankTime( GLOBAL.SetupService.GetSetupBlankTime())
						   , statusBacklight( GLOBAL.SetupService.GetStatusBacklight())
						   , statusContrast( GLOBAL.SetupService.GetStatusContrast())
						   , statusBlankTime( GLOBAL.SetupService.GetStatusBlankTime())
{
}

void Screen_Setup_System_Display::display( void)
{
	// Adjust menu entries to frame and set them up.
	const FONT_Type* Font = FONT::GetFont( SCREEN_SETUP_BASE_MAIN_FONT);

	uint16_t SubMenuLeft = menuLeft + Font->CellWidth;
	uint16_t ContentLeft = SubMenuLeft + 16 * Font->CellWidth;
	uint16_t ContentWidth = frameWidth - ( ContentLeft - frameLeft) - 1;

	uint8_t Line = 0;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop, SCREEN_SETUP_BASE_MAIN_FONT,
								 LCD_65K_RGB::WarmYellow, LCD_65K_RGB::Black, LCD::PO_Proportional,
								 Text::Exit);

	Line += 2;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::ShowIntro);

	showIntroCheckBox.SetDimensions( ContentLeft,
									 frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									 ContentWidth, SCREEN_SETUP_BASE_GAUGE_THICKNESS);
	showIntroCheckBox.Display( showIntro);

	Line++;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::WarmYellow,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Setup);

	GLOBAL.SetupDisplay.Print_P( SubMenuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Backlight);

	setupBacklightGauge.SetDimensions( ContentLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									   ContentWidth, SCREEN_SETUP_BASE_GAUGE_THICKNESS);
	setupBacklightGauge.SetOptions( GUI_Setup_Gauge::O_Percentage);
	setupBacklightGauge.Display( LCD_65K_RGB_BACKLIGHT_OFF, LCD_65K_RGB_BACKLIGHT_FULL,
								 setupBacklight);

	Line++;

	GLOBAL.SetupDisplay.Print_P( SubMenuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::BlankTime);

	setupBlankTimeLabel.SetDimensions( ContentLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT));
	setupBlankTimeLabel.SetOptions( GUI_Setup_Label::O_Fixed);
	setupBlankTimeLabel.SetText( setupBlankTimeLabelText);
	displaySetupBlankTime();

	Line++;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::WarmYellow,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Status);

	GLOBAL.SetupDisplay.Print_P( SubMenuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Backlight);

	statusBacklightGauge.SetDimensions( ContentLeft,
									    frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									    ContentWidth, SCREEN_SETUP_BASE_GAUGE_THICKNESS);
	statusBacklightGauge.SetOptions( GUI_Setup_Gauge::O_Percentage);
	statusBacklightGauge.Display( LCD_DOG_BACKLIGHT_OFF, LCD_DOG_BACKLIGHT_FULL, statusBacklight);

	GLOBAL.SetupDisplay.Print_P( SubMenuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Contrast);

	statusContrastGauge.SetDimensions( ContentLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									   ContentWidth, SCREEN_SETUP_BASE_GAUGE_THICKNESS);
	statusContrastGauge.SetOptions( GUI_Setup_Gauge::O_Percentage);
	statusContrastGauge.Display( LCD_DOG_CONTRAST_OFF, LCD_DOG_CONTRAST_FULL, statusContrast);

	Line++;

	GLOBAL.SetupDisplay.Print_P( SubMenuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::BlankTime);

	statusBlankTimeLabel.SetDimensions( ContentLeft,
									    frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT));
	statusBlankTimeLabel.SetOptions( GUI_Setup_Label::O_Fixed);
	statusBlankTimeLabel.SetText( statusBlankTimeLabelText);
	displayStatusBlankTime();
}

bool Screen_Setup_System_Display::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Selected :
		{
			switch( currentMenuEntry)
			{
				case 0 : return( false);

				case 2 : doShowIntro();			break;

				case 5 : doSetupBacklight();	break;

				case 7 : doSetupBlankTime();	break;

				case 10 : doStatusBacklight();	break;
				case 11 : doStatusContrast();	break;

				case 13 : doStatusBlankTime();	break;

				default : break;
			}
		}
		break;

		default : break;
	}

	return( true);
}

void Screen_Setup_System_Display::doShowIntro( void)
{
	showIntro = UTILITY_Invert( showIntro);
	GLOBAL.SetupService.SetShowIntro( showIntro);
	showIntroCheckBox.Display( showIntro);
}

void Screen_Setup_System_Display::doSetupBacklight( void)
{
	if( GUI_Setup_Select::DoGaugeSelect( &setupBacklight, LCD_DOG_BACKLIGHT_OFF, LCD_DOG_BACKLIGHT_FULL,
								   LCD_65K_RGB_BACKLIGHT_STEPS, &menuMarker, &setupBacklightGauge,
								   &updateSetupBacklight) == true)
	{
		GLOBAL.SetupService.SetSetupBacklight( setupBacklight);
	}
}

void Screen_Setup_System_Display::updateSetupBacklight( uint8_t Value)
{
	GLOBAL.SetupDisplay.SetBacklight( Value);
}

void Screen_Setup_System_Display::doSetupBlankTime( void)
{
	if( GUI_Setup_Select::DoTimeSelect( &setupBlankTime, 0, 5 * 60, 5, &menuMarker,
									    &setupBlankTimeLabel, this, &updateSetupBlankTime))
	{
		GLOBAL.SetupService.SetSetupBlankTime( setupBlankTime);
	}
}

void Screen_Setup_System_Display::displaySetupBlankTime( void)
{
	if( setupBlankTime != 0)
	{
		snprintf_P( setupBlankTimeLabelText, sizeof( setupBlankTimeLabelText), Text::TimeFormat,
					setupBlankTime / 60, setupBlankTime % 60);
		setupBlankTimeLabel.SetText( setupBlankTimeLabelText);
	}
	else
	{
		setupBlankTimeLabel.SetText_P( Text::PaddedOff);
	}

	setupBlankTimeLabel.Display();
}

void Screen_Setup_System_Display::updateSetupBlankTime( void* Object, GUI_Setup_Label* Label,
													    int16_t Value)
{
	GLOBAL.SetSetupBlankTime( Value);

	(( Screen_Setup_System_Display*) Object)->displaySetupBlankTime();
}

void Screen_Setup_System_Display::doStatusBacklight( void)
{
	if( GUI_Setup_Select::DoGaugeSelect( &statusBacklight, LCD_DOG_BACKLIGHT_OFF, LCD_DOG_BACKLIGHT_FULL,
								   LCD_DOG_BACKLIGHT_STEPS, &menuMarker, &statusBacklightGauge,
								   &updateStatusBacklight) == true)
	{
		GLOBAL.SetupService.SetStatusBacklight( statusBacklight);
	}
}

void Screen_Setup_System_Display::updateStatusBacklight( uint8_t Value)
{
	GLOBAL.StatusDisplay.SetBacklight( Value);
}

void Screen_Setup_System_Display::doStatusContrast( void)
{
	if( GUI_Setup_Select::DoGaugeSelect( &statusContrast, LCD_DOG_CONTRAST_OFF, LCD_DOG_CONTRAST_FULL,
								   LCD_DOG_CONTRAST_STEPS, &menuMarker, &statusContrastGauge,
								   &updateStatusContrast) == true)
	{
		GLOBAL.SetupService.SetStatusContrast( statusContrast);
	}
}

void Screen_Setup_System_Display::updateStatusContrast( uint8_t Value)
{
	GLOBAL.StatusDisplay.SetContrast( Value);
}

void Screen_Setup_System_Display::doStatusBlankTime( void)
{
	if( GUI_Setup_Select::DoTimeSelect( &statusBlankTime, 0, 5 * 60, 5, &menuMarker,
									    &statusBlankTimeLabel, this, &updateStatusBlankTime))
	{
		GLOBAL.SetupService.SetStatusBlankTime( statusBlankTime);
	}
}

void Screen_Setup_System_Display::displayStatusBlankTime( void)
{
	if( statusBlankTime != 0)
	{
		snprintf_P( statusBlankTimeLabelText, sizeof( statusBlankTimeLabelText), Text::TimeFormat,
				    statusBlankTime / 60, statusBlankTime % 60);
		statusBlankTimeLabel.SetText( statusBlankTimeLabelText);
	}
	else
	{
		statusBlankTimeLabel.SetText_P( Text::PaddedOff);
	}

	statusBlankTimeLabel.Display();
}

void Screen_Setup_System_Display::updateStatusBlankTime( void* Object, GUI_Setup_Label* Label,
														 int16_t Value)
{
	GLOBAL.SetStatusBlankTime( Value);

	(( Screen_Setup_System_Display*) Object)->displayStatusBlankTime();
}
