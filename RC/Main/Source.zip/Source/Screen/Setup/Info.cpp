// Copyright 2009 Peter Stegemann

#include "Info.h"

#include "Main/Setup.h"
#include "Setup/Struct.h"
#include "Text/Text.h"

#include "AVR/Components/EEPROM.h"

Screen_Setup_Info::Screen_Setup_Info( void)
				 : Screen_Setup_Base( 0b101, Text::Info)
{
	GLOBAL.SetupService.GetOwner( owner, sizeof( owner));

	ownerInput.SetOptions(( GUI_Setup_TextInput::Options)( GUI_Setup_TextInput::O_LimitAlphaNumeric));
}

void Screen_Setup_Info::display( void)
{
	// Adjust menu entries to frame and set them up.
	const FONT_Type* Font = FONT::GetFont( SCREEN_SETUP_BASE_MAIN_FONT);
	
	uint16_t ContentLeft = frameLeft + 12 * Font->CellWidth;

	uint8_t Line = 0;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop, SCREEN_SETUP_BASE_MAIN_FONT,
								 LCD_65K_RGB::WarmYellow, LCD_65K_RGB::Black, LCD::PO_Proportional,
								 Text::Exit);

	Line += 2;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Owner);

	ownerLabel.SetDimensions( ContentLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT));
	ownerInput.SetDimensions( ContentLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT));

	ownerLabel.Display( owner);

	Line += 5;

	GLOBAL.SetupDisplay.PrintFormat_P( menuLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									   SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
									   LCD_65K_RGB::Black, LCD::PO_Proportional, Text::ModelsCount,
									   GLOBAL.SetupService.CountModels( Setup_Service::CMO_Used));
	GLOBAL.SetupDisplay.PrintFormat_P( menuLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									   SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
									   LCD_65K_RGB::Black, LCD::PO_Proportional, Text::TypesCount,
									   GLOBAL.SetupService.CountTypes( Setup_Service::CTO_Used));
	GLOBAL.SetupDisplay.PrintFormat_P( menuLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									   SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
									   LCD_65K_RGB::Black, LCD::PO_Proportional, Text::SourcesCount,
									   GLOBAL.SetupService.CountSources( Setup_Service::CSO_Used));

	Line++;

	GLOBAL.SetupDisplay.PrintFormat_P( menuLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									   SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
									   LCD_65K_RGB::Black, LCD::PO_Proportional,
									   Text::InternalEEPROMSize, sizeof( Setup_Struct), 4096);
	GLOBAL.SetupDisplay.PrintFormat_P( menuLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									   SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
									   LCD_65K_RGB::Black, LCD::PO_Proportional,
									   Text::ExternalEEPROMSize, sizeof( Setup_ExtensionStruct),
									   EEPROM_Size);

	Line++;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::CPUType);
}
/*
void Screen_Setup_Info::update( void)
{
	Screen_Setup_Base::update();

	uint8_t Line = 2;

	GLOBAL.SetupDisplay.PrintFormat( 10, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::Green,
									 LCD_65K_RGB::Black, LCD::PO_Proportional, "sync %ld ",
									 GLOBAL.SignalService.GetSync());

	uint8_t ChannelId = 0;

	while( ChannelId < SIGNAL_SERVICE_CHANNELS)
	{
		GLOBAL.SetupDisplay.PrintFormat( 10, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
										 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::Green,
										 LCD_65K_RGB::Black, LCD::PO_Proportional, "%d %d ",
										 ChannelId, GLOBAL.SignalService.GetChannel( ChannelId));

		ChannelId++;
	}
}
*/
bool Screen_Setup_Info::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Selected :
		{
			switch( currentMenuEntry)
			{
				case 0 : return( false);

				case 2 : doOwner();		break;

				default : break;
			}
		}
		break;

		default : break;
	}

	return( true);
}

void Screen_Setup_Info::doOwner( void)
{
	ownerLabel.Clear();

	ownerInput.ReadText( owner, sizeof( owner) - 1);

	strncpy( owner, ownerInput.GetText(), sizeof( owner));
	owner[ sizeof( owner) - 1] = 0;

	GLOBAL.SetupService.SetOwner( owner);

	ownerInput.Clear();
	ownerLabel.Display();
}
