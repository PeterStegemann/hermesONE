// Copyright 2007 Peter Stegemann

#include "System.h"

#include "GUI/Setup/Popup.h"
#include "GUI/Setup/Select.h"
#include "Main/Setup.h"
#include "Serial/DesktopConnection.h"
#include "System/Battery.h"
#include "System/Calibration.h"
#include "System/ChannelMapping.h"
#include "System/Display.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"

Screen_Setup_System::Screen_Setup_System( void)
				   : Screen_Setup_Base( 0b1010011100110101, Text::System)
				   , ppmInverted( GLOBAL.SetupService.GetPPMInverted())
				   , ppmCenter( GLOBAL.SetupService.GetPPMCenter())
{
}

void Screen_Setup_System::display( void)
{
	// Adjust menu entries to frame and set them up.
	const FONT_Type* Font = FONT::GetFont( SCREEN_SETUP_BASE_MAIN_FONT);

	uint16_t ContentLeft = frameLeft + 18 * Font->CellWidth;
	uint16_t ContentWidth = frameWidth - ( ContentLeft - frameLeft) - 1;

	uint8_t Line = 0;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop, SCREEN_SETUP_BASE_MAIN_FONT,
								 LCD_65K_RGB::WarmYellow, LCD_65K_RGB::Black, LCD::PO_Proportional,
								 Text::Exit);

	Line += 2;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Serial);

	Line++;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Display);
	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Battery);

	Line += 2;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::PPMInverted);

	ppmInvertedCheckBox.SetDimensions( ContentLeft,
									   frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
									   ContentWidth, SCREEN_SETUP_BASE_GAUGE_THICKNESS);

	ppmInvertedCheckBox.Clear();
	ppmInvertedCheckBox.Display( ppmInverted);

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::PPMCenter);

	ppmCenterLabel.SetDimensions( ContentLeft,
								  frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT));
	ppmCenterLabel.SetMillisecond( ppmCenter + 15);
	ppmCenterLabel.Display();

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::ChannelMapping);

	Line += 2;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Calibration);

	Line++;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Reset);
}

void Screen_Setup_System::updatePPMCenter( void)
{
	// Display with a center of 1.5ms.
	ppmCenterLabel.SetMillisecond( ppmCenter + 15);

	GLOBAL.SignalService.SetPPMCenter( ppmCenter);
}

void Screen_Setup_System::updatePPMCenter( void* Object, GUI_Setup_Label* Label, int8_t Value)
{
	(( Screen_Setup_System*) Object)->updatePPMCenter();
}

bool Screen_Setup_System::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Selected :
		{
			switch( currentMenuEntry)
			{
				case 0 : return( false);

				case 2 : doSerial();			break;

				case 4 : doDisplay();			break;
				case 5 : doBattery();			break;

				case 8 : doPPMInverted();		break;
				case 9 : doPPMCenter();			break;
				case 10 : doChannelMapping();	break;

				case 13 : doCalibration();		break;

				case 15 : doReset();			break;

				default : break;
			}
		}
		break;

		default : break;
	}

	return( true);
}

void Screen_Setup_System::doSerial( void)
{
	GUI_Setup_Popup Popup;

	// Set text.
	Popup.SetText_P( Text::SerialAsk);
	Popup.SetOKText_P( Text::Stop);

	Popup.Show();

	Serial_DesktopConnection UseConnection;
	// Set up serial.
	UseConnection.Initialize( SYSTEM_SERIAL_ID);

	UseConnection.DoSerialConnection();

	ReDisplay();
}

void Screen_Setup_System::doDisplay( void)
{
	Screen_Setup_System_Display DisplayScreen;
	DisplayScreen.Run();

	ReDisplay();
}

void Screen_Setup_System::doBattery( void)
{
	Screen_Setup_System_Battery BatteryScreen;
	BatteryScreen.Run();

	ReDisplay();
}

void Screen_Setup_System::doChannelMapping( void)
{
	Screen_Setup_System_ChannelMapping ChannelMappingScreen;
	ChannelMappingScreen.Run();

	ReDisplay();
}

void Screen_Setup_System::doPPMInverted( void)
{
	ppmInverted = !ppmInverted;

	GLOBAL.SetupService.SetPPMInverted( ppmInverted);
	GLOBAL.SignalService.SetPPMInverted( ppmInverted);

	ppmInvertedCheckBox.Display( ppmInverted);
}

void Screen_Setup_System::doPPMCenter( void)
{
	if( GUI_Setup_Select::DoSelect( &ppmCenter, SIGNAL_SERVICE_PPM_CENTER_MINIMUM,
								    SIGNAL_SERVICE_PPM_CENTER_MAXIMUM, 1, &menuMarker,
								    &ppmCenterLabel, this, NULL, &updatePPMCenter))
	{
		GLOBAL.SetupService.SetPPMCenter( ppmCenter);
	}
}

void Screen_Setup_System::doCalibration( void)
{
	Screen_Setup_System_Calibration CalibrationScreen;
	CalibrationScreen.Run();

	ReDisplay();
}

void Screen_Setup_System::doReset( void)
{
	GUI_Setup_Popup Popup;

	// Set text.
	Popup.SetText_P( Text::ResetCheck);
	Popup.SetOKText_P( Text::Reset);
	Popup.SetCancelText_P( Text::Cancel);

	Popup.Show();

	if( Popup.Ask() != true)
	{
		ReDisplay();

		return;
	}

	GLOBAL.SetupService.Reset();

	GLOBAL.SignalProcessor.LoadModel();

	UTILITY::HardReset();
	// No comin' back.
}
