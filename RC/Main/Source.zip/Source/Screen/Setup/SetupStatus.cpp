// Copyright 2009 Peter Stegemann

#include "SetupStatus.h"

#include "Main/Setup.h"
#include "GUI/Setup/Select.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"

Screen_Setup_SetupStatus::Screen_Setup_SetupStatus( void)
						: Screen_Setup_Base( 0b101010100101, Text::Status)
{
	currentSource = 0;

	for( uint8_t SourceLine = 0; SourceLine < SETUP_STATUS_SOURCES; SourceLine++)
	{
		statusGauge[ SourceLine].SetOptions(
			( GUI_Setup_Gauge::Options)( GUI_Setup_Gauge::O_Percentage |
										 GUI_Setup_Gauge::O_DualPercentage |
										 GUI_Setup_Gauge::O_CenterLine |
										 GUI_Setup_Gauge::O_Marker));
	}
}

void Screen_Setup_SetupStatus::display( void)
{
	// Adjust menu entries to frame and set them up.
	const FONT_Type* Font = FONT::GetFont( SCREEN_SETUP_BASE_MAIN_FONT);

	uint16_t ValueLeft = menuLeft + 12 * Font->CellWidth;
	uint16_t SourceLeft = menuLeft + 1 * Font->CellWidth;
	uint16_t GaugeLeft = SourceLeft + ( SETUP_SOURCE_NAME_SIZE + 1) * Font->CellWidth;
	uint16_t GaugeWidth = frameWidth - ( GaugeLeft - frameLeft) - 1;	

	uint8_t Line = 0;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop, SCREEN_SETUP_BASE_MAIN_FONT,
								 LCD_65K_RGB::WarmYellow, LCD_65K_RGB::Black, LCD::PO_Proportional,
								 Text::Exit);

	Line += 2;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Time);
	timerLabel.SetDimensions( ValueLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT));

	Line += 2;

	const prog_char* Name[] =
	{
		Text::LeftSide, Text::LeftBottom, Text::RightSide, Text::RightBottom
	};

	uint16_t LineTop = frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT);

	for( uint8_t SourceLine = 0; SourceLine < SETUP_STATUS_SOURCES; SourceLine++)
	{
		GLOBAL.SetupDisplay.Print_P( menuLeft, LineTop, SCREEN_SETUP_BASE_MAIN_FONT,
									 LCD_65K_RGB::WarmYellow, LCD_65K_RGB::Black,
									 LCD::PO_Proportional, Name[ SourceLine]);

		LineTop += SCREEN_SETUP_BASE_LINE_HEIGHT;

		sourceLabel[ SourceLine].SetDimensions( SourceLeft, LineTop);

		statusGauge[ SourceLine].SetDimensions( GaugeLeft, LineTop, GaugeWidth,
											    SCREEN_SETUP_BASE_GAUGE_THICKNESS);

		LineTop += SCREEN_SETUP_BASE_LINE_HEIGHT;
	}

	reDisplay();
}

void Screen_Setup_SetupStatus::reDisplay( void)
{
	uint16_t SetupSourceId = GLOBAL.SetupService.GetStatusTimeId();
	timerId = GLOBAL.SignalProcessor.GetSignalSourceId( SetupSourceId);

	SetSourceLabel( &timerLabel, timerName, timerId);

	// Clear all channels.
	for( uint8_t SourceLine = 0; SourceLine < SETUP_STATUS_SOURCES; SourceLine++)
	{
		statusGauge[ SourceLine].Clear();
	}

	// Find sources to display.
	uint8_t SourceLine = 0;

	while( SourceLine < SETUP_STATUS_SOURCES)
	{
		SetupSourceId = GLOBAL.SetupService.GetStatusSourceId( SourceLine);

		sourceId[ SourceLine] = GLOBAL.SignalProcessor.GetSignalSourceId( SetupSourceId);

		SetSourceLabel( &( sourceLabel[ SourceLine]), sourceName[ SourceLine],
					    sourceId[ SourceLine]);

		SourceLine++;
	}
}

void Screen_Setup_SetupStatus::update( void)
{
//	GLOBAL.StatusScreen.SetSource( currentSource, sourceId[ currentSource]);

	Screen_Setup_Base::update();

	// Print all channels.
	for( uint8_t SourceLine = 0; SourceLine < SETUP_STATUS_SOURCES; SourceLine++)
	{
		statusGauge[ SourceLine].Display( SIGNAL_MINIMUM_VALUE, SIGNAL_MAXIMUM_VALUE,
										  GLOBAL.SignalProcessor.GetSourceValue(
											sourceId[ SourceLine]));
	}
}

void Screen_Setup_SetupStatus::update( void* Object)
{
	(( Screen_Setup_SetupStatus*) Object)->update();
}

bool Screen_Setup_SetupStatus::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Selected :
		{
			switch( currentMenuEntry)
			{
				case 0 : return( false);

				case 2 :
				{
					uint16_t SetupSourceId = GLOBAL.SetupService.GetStatusTimeId();

					bool SourceChanged = GUI_Setup_Select::DoSourceSelect(
						&timerId, &SetupSourceId, &menuMarker, &timerLabel, NULL, timerName, this,
						&update, false, Signal_Source_Source::L_Global,
						Signal_Source_Source::T_Timer);

					if( SourceChanged == true)
					{
						GLOBAL.SetupService.SetStatusTimeId( SetupSourceId);
					}
				}
				break;

				default :
				{
					currentSource = ( currentMenuEntry - 5) / 2;

					uint16_t SetupSourceId = GLOBAL.SetupService.GetStatusSourceId( currentSource);

					bool SourceChanged = GUI_Setup_Select::DoSourceSelect(
						&( sourceId[ currentSource]), &SetupSourceId, &menuMarker,
						&( sourceLabel[ currentSource]), &( statusGauge[ currentSource]),
						sourceName[ currentSource], this, &update, false,
						Signal_Source_Source::L_Global);

					if( SourceChanged == true)
					{
						GLOBAL.SetupService.SetStatusSourceId( currentSource, SetupSourceId);
					}
				}
				break;
			}
		}
		break;

		default : break;
	}

	return( true);
}
