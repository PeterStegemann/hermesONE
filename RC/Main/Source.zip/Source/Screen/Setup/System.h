// Copyright 2007 Peter Stegemann

#ifndef SCREEN_SETUP_SYSTEM_H
#define SCREEN_SETUP_SYSTEM_H

#include "Base.h"
#include "GUI/Setup/CheckBox.h"
#include "GUI/Setup/MillisecondLabel.h"

class Screen_Setup_System : public Screen_Setup_Base
{
	private:
		GUI_Setup_CheckBox ppmInvertedCheckBox;
		bool ppmInverted;

		GUI_Setup_MillisecondLabel ppmCenterLabel;
		int8_t ppmCenter;

		virtual void display( void);
		virtual bool processMenu( DoMenuResult Result);

		void updatePPMCenter( void);
		static void updatePPMCenter( void* Object, GUI_Setup_Label* Label, int8_t Value);

		void doSerial( void);
		void doDisplay( void);
		void doBattery( void);
		void doPPMInverted( void);
		void doPPMCenter( void);
		void doChannelMapping( void);
		void doCalibration( void);
		void doReset( void);

	public:
		Screen_Setup_System( void);
};

#endif
