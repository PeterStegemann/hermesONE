// Copyright 2007 Peter Stegemann

#include "Model.h"

#include "Sources.h"
#include "Main/Setup.h"
#include "Setup/Service.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"

const prog_char* getTitle( Signal_Source_Source::Level SourceLevel)
{
	switch( SourceLevel)
	{
		case Signal_Source_Source::L_Model :	return( Text::Model);
		case Signal_Source_Source::L_Type :		return( Text::Type);
		case Signal_Source_Source::L_Global :	return( Text::Global);
	}

	return( NULL);
}

uint16_t getMenuPattern( Signal_Source_Source::Level SourceLevel)
{
	switch( SourceLevel)
	{
		case Signal_Source_Source::L_Model :
		case Signal_Source_Source::L_Type :		return( 0b1000001111110101);
		case Signal_Source_Source::L_Global :	return( 0b1000000011111101);
	}

	return( 0);
}

Screen_Setup_Model::Screen_Setup_Model( Signal_Source_Source::Level SourceLevel)
				  : Screen_Setup_Base( getMenuPattern( SourceLevel), getTitle( SourceLevel))
				  , sourceLevel( SourceLevel)
				  , selectedModelId( GLOBAL.SetupService.GetSelectedModelId())
				  , selectedTypeId( GLOBAL.SetupService.GetSelectedTypeId( selectedModelId))
{
	if( sourceLevel == Signal_Source_Source::L_Model)
	{
		GLOBAL.SetupService.GetModelName( selectedModelId, modelName, sizeof( modelName));
	}
	else if( sourceLevel == Signal_Source_Source::L_Type)
	{
		GLOBAL.SetupService.GetTypeName( selectedTypeId, modelName, sizeof( modelName));
	}

	modelNameInput.SetOptions(( GUI_Setup_TextInput::Options)
		( GUI_Setup_TextInput::O_LimitAlphaNumeric));
}

void Screen_Setup_Model::display( void)
{
	// Adjust menu entries to frame and set them up.
	const FONT_Type* Font = FONT::GetFont( SCREEN_SETUP_BASE_MAIN_FONT);

	uint16_t ContentLeft = frameLeft + 10 * Font->CellWidth;

	uint8_t Line = 0;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop, SCREEN_SETUP_BASE_MAIN_FONT,
								 LCD_65K_RGB::WarmYellow, LCD_65K_RGB::Black, LCD::PO_Proportional,
								 Text::Exit);
	Line += 2;

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Name);

	if( sourceLevel != Signal_Source_Source::L_Global)
	{
		modelNameLabel.SetDimensions( ContentLeft,
									  frameTop + ( Line * SCREEN_SETUP_BASE_LINE_HEIGHT));
		modelNameInput.SetDimensions( menuLeft,
									  frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT));

		modelNameLabel.Clear();
		modelNameLabel.Display( modelName);

		Line++;
	}

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Inputs);
	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Maps);
	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Mixers);
	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Stores);
	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Timer);
	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Followers);

	Line += 5;

	if( sourceLevel == Signal_Source_Source::L_Global)
	{
		Line += 2;
	}

	GLOBAL.SetupDisplay.Print_P( menuLeft, frameTop + ( Line++ * SCREEN_SETUP_BASE_LINE_HEIGHT),
								 SCREEN_SETUP_BASE_MAIN_FONT, LCD_65K_RGB::White,
								 LCD_65K_RGB::Black, LCD::PO_Proportional, Text::Sources);
}

bool Screen_Setup_Model::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Selected :
		{
			uint8_t CurrentLine = currentMenuEntry;

			if(( sourceLevel == Signal_Source_Source::L_Global) && ( CurrentLine > 0))
			{
				CurrentLine += 2;
			}

			switch( CurrentLine)
			{
				case  0 : return( false);

				case  2 : doModelName();		break;

				case  4 : doSources( Signal_Source_Source::T_Input);	break;
				case  5 : doSources( Signal_Source_Source::T_Map);		break;
				case  6 : doSources( Signal_Source_Source::T_Mix);		break;
				case  7 : doSources( Signal_Source_Source::T_Store);	break;
				case  8 : doSources( Signal_Source_Source::T_Timer);	break;
				case  9 : doSources( Signal_Source_Source::T_Follower);	break;

				case 15 :
				case 17 : doSources( Signal_Source_Source::T_All);		break;

				default : break;
			}

			ReDisplay();
		}
		break;

		case DMR_Changed :	break;

		default : break;
	}

	return( true);
}

void Screen_Setup_Model::doModelName( void)
{
	modelNameLabel.Clear();

	modelNameInput.ReadText( modelName, sizeof( modelName) - 1);

	strncpy( modelName, modelNameInput.GetText(), sizeof( modelName));
	modelName[ sizeof( modelName) - 1] = 0;

	if( sourceLevel == Signal_Source_Source::L_Model)
	{
		GLOBAL.SetupService.SetModelName( selectedModelId, modelName);
	}
	else if( sourceLevel == Signal_Source_Source::L_Type)
	{
		GLOBAL.SetupService.SetTypeName( selectedTypeId, modelName);
	}

	modelNameInput.Clear();
}

void Screen_Setup_Model::doSources( Signal_Source_Source::Type SourceType)
{
	Screen_Setup_Sources SourcesScreen( SourceType, sourceLevel);
	SourcesScreen.Run();
}
