// Copyright 2010 Peter Stegemann

#include "System.h"

#include "Battery.h"
#include "ChannelMapping.h"
#include "Display.h"
#include "Serial/DesktopConnection.h"
#include "Text/Text.h"

#include "AVR/Components/Utility.h"
#include "AVR/Components/Font/Font.h"
#include "AVR/Components/LCD/LCD_DOG.h"

#define MENU_EXIT				0
#define MENU_SERIAL				1
#define MENU_DISPLAY			2
#define MENU_BATTERY			3
#define MENU_PPM_INVERTED		4
#define MENU_PPM_CENTER			5
#define MENU_CHANNEL_MAPPING	6
#define MENU_COUNT				7

Screen_Status_Menu_System::Screen_Status_Menu_System( void)
						 : Screen_Status_Menu_Base( MENU_COUNT, L_Two)
{
	PPMInverted = GLOBAL.SetupService.GetPPMInverted();
}

Screen_Status_Menu_System::~Screen_Status_Menu_System( void)
{
}

void Screen_Status_Menu_System::display( void)
{
	pickMenu( MENU_SERIAL);
}

bool Screen_Status_Menu_System::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Changed :
		{
			switch( currentMenuEntry)
			{
				case MENU_EXIT :
				{
					SetText_P( Text::Exit);

					SetText_P(( Level)( menuLevel + 1), NULL);
				}
				break;

				case MENU_SERIAL :
				{
					SetText_P( Text::SerialShort);

					SetText_P(( Level)( menuLevel + 1), NULL);
				}
				break;

				case MENU_DISPLAY :
				{
					SetText_P( Text::Display);
					
					SetText_P(( Level)( menuLevel + 1), NULL);
				}
				break;

				case MENU_BATTERY :
				{
					SetText_P( Text::Battery);

					SetText_P(( Level)( menuLevel + 1), NULL);
				}
				break;

				case MENU_PPM_INVERTED :
				{
					SetText_P( Text::PPMInverted);

					updateBoolean( PPMInverted);
				}
				break;

				case MENU_PPM_CENTER :
				{
					SetText_P( Text::PPMCenter);

//					updateBoolean( PPMInverted);
				}
				break;

				case MENU_CHANNEL_MAPPING :
				{
					SetText_P( Text::ChannelMapping);

					SetText_P(( Level)( menuLevel + 1), NULL);
				}
				break;
			}
		}
		break;

		case DMR_Selected :
		{
			switch( currentMenuEntry)
			{
				case MENU_EXIT : return( false);

				case MENU_SERIAL :
				{
					drawMenuMarker( menuLevel, false, false);

					SetText_P(( Level)( menuLevel + 1), Text::Cancel);

					Serial_DesktopConnection UseConnection;
					// Set up serial.
					UseConnection.Initialize( SYSTEM_SERIAL_ID);

					UseConnection.DoSerialConnection();

					SetText_P(( Level)( menuLevel + 1), NULL);
					drawMenuMarker();
				}
				break;

				case MENU_DISPLAY :
				{
					Screen_Status_Menu_Display DisplayScreen;
					DisplayScreen.Run();

					SetText_P(( Level)( menuLevel + 1), NULL);
					drawMenuMarker();
				}
				break;

				case MENU_BATTERY :
				{
					Screen_Status_Menu_Battery BatteryScreen;
					BatteryScreen.Run();

					SetText_P(( Level)( menuLevel + 1), NULL);
					drawMenuMarker();
				}
				break;

				case MENU_PPM_INVERTED :
				{
					PPMInverted = UTILITY_Invert( PPMInverted);

					GLOBAL.SetupService.SetPPMInverted( PPMInverted);
					GLOBAL.SignalService.SetPPMInverted( PPMInverted);

					updateBoolean( PPMInverted);
				}
				break;

				case MENU_PPM_CENTER :
				{
//					PPMInverted = UTILITY_Invert( PPMInverted);

//					GLOBAL.SetupService.SetPPMInverted( PPMInverted);
//					GLOBAL.SignalService.SetPPMInverted( PPMInverted);
					
//					updateBoolean( PPMInverted);
				}
				break;

				case MENU_CHANNEL_MAPPING :
				{
					Screen_Status_Menu_ChannelMapping ChannelMappingScreen;
					ChannelMappingScreen.Run();
					
					SetText_P(( Level)( menuLevel + 1), NULL);
					drawMenuMarker();
				}
				break;
			}
		}
		break;

		default : break;
	}

	return( true);
}
