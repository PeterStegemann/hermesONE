// Copyright 2011 Peter Stegemann

#include "ChannelMapping.h"

#include "Text/Text.h"

#include "AVR/Components/Utility.h"
#include "AVR/Components/Font/Font.h"
#include "AVR/Components/LCD/LCD_DOG.h"

#define MENU_EXIT				0
#define MENU_CHANNELS_START		1
#define MENU_COUNT				MENU_CHANNELS_START + SIGNAL_SERVICE_CHANNELS

Screen_Status_Menu_ChannelMapping::Screen_Status_Menu_ChannelMapping( void)
						         : Screen_Status_Menu_Base( MENU_COUNT, L_Three)
{
}

Screen_Status_Menu_ChannelMapping::~Screen_Status_Menu_ChannelMapping( void)
{
}

void Screen_Status_Menu_ChannelMapping::display( void)
{
	pickMenu( MENU_CHANNELS_START);
}

void Screen_Status_Menu_ChannelMapping::updateChannelMapping( int8_t Value)
{
	if( currentMenuEntry >= MENU_CHANNELS_START)
	{
		uint8_t ChannelIndex = currentMenuEntry - MENU_CHANNELS_START;

		char String[ 2];

		snprintf_P( String, sizeof( String), Text::Int8Format, Value + 1);

		SetText(( Level)( menuLevel + 1), String);

		GLOBAL.SignalService.SetChannelMapping( ChannelIndex, Value);
	}
}

void Screen_Status_Menu_ChannelMapping::updateChannelMapping( void* Object, int8_t Value)
{
	(( Screen_Status_Menu_ChannelMapping*) Object)->updateChannelMapping( Value);
}

bool Screen_Status_Menu_ChannelMapping::processMenu( DoMenuResult Result)
{
	switch( Result)
	{
		case DMR_Changed :
		{
			switch( currentMenuEntry)
			{
				case MENU_EXIT :
				{
					SetText_P( Text::Exit);
					SetText(( Level)( menuLevel + 1), NULL);
				}
				break;

				default :
				{
					uint8_t ChannelIndex = currentMenuEntry - MENU_CHANNELS_START;

					char String[ 10];

					snprintf_P( String, sizeof( String), Text::ChannelNameFormat, ChannelIndex + 1);

					SetText( String);
					updateChannelMapping( GLOBAL.SetupService.GetChannelMapping( ChannelIndex));
				}
				break;
			}
		}
		break;

		case DMR_Selected :
		{
			switch( currentMenuEntry)
			{
				case MENU_EXIT : return( false);

				default :
				{
					uint8_t ChannelIndex = currentMenuEntry - MENU_CHANNELS_START;

					int8_t Value = GLOBAL.SetupService.GetChannelMapping( ChannelIndex);

					if( selectValue( &Value, 0, SIGNAL_SERVICE_CHANNELS - 1, 1, this,
									 &updateChannelMapping) == true)
					{
						GLOBAL.SetupService.SetChannelMapping( ChannelIndex, Value);
					}

					drawMenuMarker();
				}
				break;
			}
		}
		break;

		default : break;
	}

	return( true);
}
