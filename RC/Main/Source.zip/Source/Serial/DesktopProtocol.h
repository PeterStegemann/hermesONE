// Copyright 2008 Peter Stegemann

#ifndef SERIAL_DESKTOPPROTOCOL_H
#define SERIAL_DESKTOPPROTOCOL_H

#include "AVR/Components/Serial/Serial_Protocol.h"

class Serial_DesktopProtocol : public SERIAL_Protocol
{
	public:
		enum Id		// uint8
		{
			Id_Ok,
			Id_Error,

			Id_Ping,
			Id_ReadConfiguration,
			Id_WriteConfiguration,

			Id_Configuration,
			Id_Owner,
			Id_SetupBacklight,
			Id_SetupBlankTime,
			Id_StatusBacklight,
			Id_StatusContrast,
			Id_StatusBlankTime,
			Id_ShowIntro,
			Id_SelectedModelId,

			Id_Calibrations,
			Id_Calibration,
			Id_CalibrationHigh,
			Id_CalibrationCenter,
			Id_CalibrationLow,

			Id_Battery,
			Id_BatteryWarnLowVoltage,
			Id_BatteryWarnCriticalVoltage,
			Id_BatteryMinimumVoltage,
			Id_BatteryMaximumVoltage,
			Id_BatteryCalibrationVoltage,

			Id_Models,
			Id_Model,
			Id_ModelState,
			Id_ModelName,
			Id_ModelTypeId,

			Id_StatusSources,
			Id_StatusSource,

			Id_Types,
			Id_Type,
			Id_TypeState,
			Id_TypeName,

			Id_Channels,
			Id_Channel,
			Id_ChannelName,
			Id_ChannelInput,
			Id_ChannelPoints,
			Id_ChannelPoint,
			Id_ChannelTrim,
			Id_ChannelLimit,
			Id_ChannelReverse,

			Id_Sources,
			Id_Source,
			Id_SourceType,
			Id_SourceName,
			Id_SourceModelId,
			Id_SourceTupelSourceId,
			Id_SourceTupelVolume,

			Id_SourceInputAnalog,
			Id_SourceInputAnalogInput,

			Id_SourceInputButton,
			Id_SourceInputButtonInput,
			Id_SourceInputButtonStore,
			Id_SourceInputButtonInit,
			Id_SourceInputButtonToggle,
			Id_SourceInputButtonTop,
			Id_SourceInputButtonBottom,

			Id_SourceInputRotary,
			Id_SourceInputRotaryAInput,
			Id_SourceInputRotaryBInput,
			Id_SourceInputRotaryStore,
			Id_SourceInputRotaryInit,
			Id_SourceInputRotaryStep,
			Id_SourceInputRotaryTop,
			Id_SourceInputRotaryBottom,

			Id_SourceInputSwitch,
			Id_SourceInputSwitchLowInput,
			Id_SourceInputSwitchHighInput,
			Id_SourceInputSwitchTop,
			Id_SourceInputSwitchBottom,

			Id_SourceInputTicker,
			Id_SourceInputTickerLowInput,
			Id_SourceInputTickerHighInput,
			Id_SourceInputTickerStore,
			Id_SourceInputTickerInit,
			Id_SourceInputTickerStep,
			Id_SourceInputTickerTop,
			Id_SourceInputTickerBottom,

			Id_SourceMap,
			Id_SourceMapInput,
			Id_SourceMapPoints,
			Id_SourceMapPoint,

			Id_SourceMix,
			Id_SourceMixInputs,
			Id_SourceMixInput,

			Id_SourceStore,
			Id_SourceStoreInput,
			Id_SourceStoreInit,

			Id_SourceTimer,
			Id_SourceTimerInit,

			Id_ChannelMappings,
			Id_ChannelMapping,

			Id_PPMInverted,
			Id_PPMCenter,

			Id_AnalogInputs,
			Id_DigitalInputs,
			Id_OutputChannels,

			Id_SourceFollower,
			Id_SourceFollowerTarget,
			Id_SourceFollowerStep,
			Id_SourceFollowerTrigger,
			Id_SourceFollowerTriggerHighLimit,
			Id_SourceFollowerTriggerLowLimit,

			Id_SourceTimerStore,

			Id_StatusTime,

			Id_NumberOfIds
		};
};

#endif
