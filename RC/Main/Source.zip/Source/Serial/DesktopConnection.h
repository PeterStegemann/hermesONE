// Copyright 2008 Peter Stegemann

#ifndef SERIAL_DESKTOPCONNECTION_H
#define SERIAL_DESKTOPCONNECTION_H

#include "DesktopProtocol.h"
#include "Setup/Source/Tupel.h"

#include "AVR/Components/Types.h"
#include "AVR/Components/Serial/Serial_TypedConnection.h"

class Serial_DesktopConnection : public SERIAL_TypedConnection
{
	private:
		void sendSetupSourceTupel( uint8_t Id, Setup_Source_Tupel* Value);
		void sendConfiguration( void);
		void sendCalibrations( void);
		void sendChannelMappings( void);
		void sendBattery( void);
		void sendModels( void);
		void sendChannels( uint8_t ModelId);
		void sendStatusSources( uint8_t ModelId);
		void sendTypes( void);
		void sendSources( void);
		void sendSourceFollower( uint8_t SourceId);
		void sendSourceInput( uint8_t SourceId);
		void sendSourceMap( uint8_t SourceId);
		void sendSourceMix( uint8_t SourceId);
		void sendSourceStore( uint8_t SourceId);
		void sendSourceTimer( uint8_t SourceId);

		void receiveConfiguration( void);
		void receiveCalibrations( void);
		void receiveCalibration( uint8_t CalibrationId);
		void receiveChannelMappings( void);
		void receiveBattery( void);
		void receiveModels( void);
		void receiveModel( uint8_t ModelId);
		void receiveChannels( uint8_t ModelId);
		void receiveChannel( uint8_t ModelId, uint8_t ChannelId);
		void receiveChannelPoints( int16_t* Values, uint8_t NumberOfValues, uint16_t ValueId);
		void receiveStatusSources( uint8_t ModelId);
		void receiveSetupSourceTupel( Setup_Source_Tupel* Value);
		void receiveSetupSourceTupels( Setup_Source_Tupel* Values, uint8_t NumberOfValues,
									   uint16_t ValueId);
		void receiveTypes( void);
		void receiveType( uint8_t TypeId);
		void receiveSources( void);
		void receiveSource( uint16_t SourceId);
		void receiveSourceFollower( uint16_t SourceId);
		void receiveSourceInputAnalog( uint16_t SourceId);
		void receiveSourceInputButton( uint16_t SourceId);
		void receiveSourceInputSwitch( uint16_t SourceId);
		void receiveSourceInputTicker( uint16_t SourceId);
		void receiveSourceInputRotary( uint16_t SourceId);
		void receiveSourceMap( uint16_t SourceId);
		void receiveSourceMix( uint16_t SourceId);
		void receiveSourceStore( uint16_t SourceId);
		void receiveSourceTimer( uint16_t SourceId);

	public:
		Serial_DesktopConnection( void);

		void DoSerialConnection( void);
//		void DoSerialConnectionTest( void);
};

#endif
