// Copyright 2008 Peter Stegemann

#include "DesktopConnection.h"

#include "Setup/Defines.h"
#include "Signal/Service.h"

#include "AVR/Components/Types.h"
#include "AVR/Components/Utility.h"

Serial_DesktopConnection::Serial_DesktopConnection( void)
{
}

void Serial_DesktopConnection::sendSetupSourceTupel( uint8_t Id, Setup_Source_Tupel* Value)
{
	sendComplexOpen( Id);

		sendInteger( Serial_DesktopProtocol::Id_SourceTupelSourceId, Value->SetupSourceId);
		sendInteger( Serial_DesktopProtocol::Id_SourceTupelVolume, Value->Volume);

	sendComplexClose();
}

void Serial_DesktopConnection::sendConfiguration( void)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_Configuration);

		sendInteger( Serial_DesktopProtocol::Id_AnalogInputs,
					 SIGNAL_PROCESSOR_ANALOG_INPUTS);
		sendInteger( Serial_DesktopProtocol::Id_DigitalInputs,
					 SIGNAL_PROCESSOR_DIGITAL_INPUTS);
		sendInteger( Serial_DesktopProtocol::Id_OutputChannels,
					 SIGNAL_SERVICE_CHANNELS);

		sendString( Serial_DesktopProtocol::Id_Owner,
				    GLOBAL.SetupService.GetOwner( stringBuffer, SERIAL_STRING_SIZE));
		sendInteger( Serial_DesktopProtocol::Id_SetupBlankTime,
					 GLOBAL.SetupService.GetSetupBlankTime());
		sendInteger( Serial_DesktopProtocol::Id_StatusBlankTime,
					 GLOBAL.SetupService.GetStatusBlankTime());
		sendInteger( Serial_DesktopProtocol::Id_SetupBacklight,
					 GLOBAL.SetupService.GetSetupBacklight());
		sendInteger( Serial_DesktopProtocol::Id_StatusBacklight,
					 GLOBAL.SetupService.GetStatusBacklight());
		sendInteger( Serial_DesktopProtocol::Id_StatusContrast,
					 GLOBAL.SetupService.GetStatusContrast());
		sendBool( Serial_DesktopProtocol::Id_ShowIntro, GLOBAL.SetupService.GetShowIntro());
		sendInteger( Serial_DesktopProtocol::Id_SelectedModelId,
					 GLOBAL.SetupService.GetSelectedModelId());
		sendBool( Serial_DesktopProtocol::Id_PPMInverted, GLOBAL.SetupService.GetPPMInverted());
		sendInteger( Serial_DesktopProtocol::Id_PPMCenter, GLOBAL.SetupService.GetPPMCenter());

		sendCalibrations();
		sendChannelMappings();
		sendBattery();
		sendModels();
		sendTypes();
		sendSources();

	sendComplexClose();
}

void Serial_DesktopConnection::sendCalibrations( void)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_Calibrations);
	
	for( uint8_t CalibrationId = 0; CalibrationId < SIGNAL_PROCESSOR_ANALOG_INPUTS; CalibrationId++)
	{
		sendComplexOpen( Serial_DesktopProtocol::Id_Calibration);

			Setup_Calibration Calibration;

			GLOBAL.SetupService.GetCalibration( CalibrationId, &Calibration);

			sendInteger( Serial_DesktopProtocol::Id_CalibrationHigh,
						 Calibration.Value[ SETUP_CALIBRATION_HIGH]);
			sendInteger( Serial_DesktopProtocol::Id_CalibrationCenter,
						 Calibration.Value[ SETUP_CALIBRATION_CENTER]);
			sendInteger( Serial_DesktopProtocol::Id_CalibrationLow,
						 Calibration.Value[ SETUP_CALIBRATION_LOW]);

		sendComplexClose();
	}

	sendComplexClose();
}

void Serial_DesktopConnection::sendChannelMappings( void)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_ChannelMappings);

	for( uint8_t ChannelId = 0; ChannelId < SIGNAL_SERVICE_CHANNELS; ChannelId++)
	{
		sendInteger( Serial_DesktopProtocol::Id_ChannelMapping,
					 GLOBAL.SetupService.GetChannelMapping( ChannelId));
	}

	sendComplexClose();
}

void Serial_DesktopConnection::sendBattery( void)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_Battery);

	Setup_Battery Battery;

	GLOBAL.SetupService.GetBattery( &Battery);

	sendInteger( Serial_DesktopProtocol::Id_BatteryWarnLowVoltage, Battery.WarnLowVoltage);
	sendInteger( Serial_DesktopProtocol::Id_BatteryWarnCriticalVoltage, Battery.WarnCriticalVoltage);
	sendInteger( Serial_DesktopProtocol::Id_BatteryMinimumVoltage, Battery.MinimumVoltage);
	sendInteger( Serial_DesktopProtocol::Id_BatteryMaximumVoltage, Battery.MaximumVoltage);
	sendInteger( Serial_DesktopProtocol::Id_BatteryCalibrationVoltage, Battery.CalibrationVoltage);

	sendComplexClose();
}

void Serial_DesktopConnection::sendModels( void)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_Models);

		for( uint8_t ModelId = 0; ModelId < SETUP_MODELS; ModelId++)
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_Model);

				sendInteger( Serial_DesktopProtocol::Id_ModelState,
							 GLOBAL.SetupService.GetModelState( ModelId));

				if( GLOBAL.SetupService.GetModelState( ModelId) != Setup_Service::MS_Empty)
				{
					sendString( Serial_DesktopProtocol::Id_ModelName,
							    GLOBAL.SetupService.GetModelName( ModelId, stringBuffer,
														 SERIAL_STRING_SIZE));

					sendInteger( Serial_DesktopProtocol::Id_ModelTypeId,
								 GLOBAL.SetupService.GetSelectedTypeId( ModelId));

					sendChannels( ModelId);

					sendInteger( Serial_DesktopProtocol::Id_StatusTime,
								 GLOBAL.SetupService.GetStatusTimeId( ModelId));

					sendStatusSources( ModelId);
				}

			sendComplexClose();
		}

	sendComplexClose();
}

void Serial_DesktopConnection::sendChannels( uint8_t ModelId)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_Channels);

		for( uint8_t ChannelId = 0; ChannelId < SIGNAL_SERVICE_CHANNELS; ChannelId++)
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_Channel);

				sendString( Serial_DesktopProtocol::Id_ChannelName,
						    GLOBAL.SetupService.GetChannelName( ModelId, ChannelId, stringBuffer,
															    SERIAL_STRING_SIZE));

				Setup_Channel Channel;

				GLOBAL.SetupService.GetChannel( ModelId, ChannelId, &Channel);

				sendSetupSourceTupel( Serial_DesktopProtocol::Id_ChannelInput, &( Channel.Input));
				sendSetupSourceTupel( Serial_DesktopProtocol::Id_ChannelTrim, &( Channel.Trim));
				sendSetupSourceTupel( Serial_DesktopProtocol::Id_ChannelLimit, &( Channel.Limit));

				sendBool( Serial_DesktopProtocol::Id_ChannelReverse, Channel.Reverse);

				sendComplexOpen( Serial_DesktopProtocol::Id_ChannelPoints);

					for( uint8_t PointId = 0; PointId < SETUP_CHANNEL_POINTS; PointId++)
					{
						sendInteger( Serial_DesktopProtocol::Id_ChannelPoint,
									 Channel.Point[ PointId]);
					}

				sendComplexClose();

			sendComplexClose();
		}

	sendComplexClose();
}

void Serial_DesktopConnection::sendStatusSources( uint8_t ModelId)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_StatusSources);

		for( uint8_t StatusSourceId = 0; StatusSourceId < SETUP_STATUS_SOURCES; StatusSourceId++)
		{
			sendInteger( Serial_DesktopProtocol::Id_StatusSource,
						 GLOBAL.SetupService.GetStatusSourceId( ModelId, StatusSourceId));
		}

	sendComplexClose();
}

void Serial_DesktopConnection::sendTypes( void)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_Types);

		for( uint8_t TypeId = SETUP_MODEL_TYPE_START; TypeId < SETUP_MODEL_TYPE_END; TypeId++)
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_Type);

				sendInteger( Serial_DesktopProtocol::Id_TypeState,
							 GLOBAL.SetupService.GetTypeState( TypeId));

				if( GLOBAL.SetupService.GetTypeState( TypeId) != Setup_Service::TS_Empty)
				{
					sendString( Serial_DesktopProtocol::Id_TypeName,
								GLOBAL.SetupService.GetTypeName( TypeId, stringBuffer,
																 SERIAL_STRING_SIZE));
				}

			sendComplexClose();
		}

	sendComplexClose();
}

void Serial_DesktopConnection::sendSources( void)
{
	sendComplexOpen( Serial_DesktopProtocol::Id_Sources);

		for( uint16_t SourceId = 0; SourceId < SETUP_SOURCES; SourceId++)
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_Source);

//				sendInteger( Serial_DesktopProtocol::Id_SourceType,
//							 GLOBAL.SetupService.GetSourceType( SourceId));

				if( GLOBAL.SetupService.GetSourceType( SourceId) != Signal_Source_Source::T_Empty)
				{
					sendString( Serial_DesktopProtocol::Id_SourceName,
							    GLOBAL.SetupService.GetSourceName( SourceId, stringBuffer,
														  SERIAL_STRING_SIZE));

					sendInteger( Serial_DesktopProtocol::Id_SourceModelId,
								 GLOBAL.SetupService.GetSourceModelId( SourceId));

					switch( GLOBAL.SetupService.GetSourceType( SourceId))
					{
						case Signal_Source_Source::T_Follower :	sendSourceFollower( SourceId);	break;
						case Signal_Source_Source::T_Input :	sendSourceInput( SourceId);		break;
						case Signal_Source_Source::T_Map :		sendSourceMap( SourceId);		break;
						case Signal_Source_Source::T_Mix :		sendSourceMix( SourceId);		break;
						case Signal_Source_Source::T_Store :	sendSourceStore( SourceId);		break;
						case Signal_Source_Source::T_Timer :	sendSourceTimer( SourceId);		break;

						case Signal_Source_Source::T_Empty : break;
					}
				}

			sendComplexClose();
		}
	
	sendComplexClose();
}

void Serial_DesktopConnection::sendSourceFollower( uint8_t SourceId)
{
	Setup_Source_Follower SourceFollower;

	GLOBAL.SetupService.GetSourceFollower( SourceId, &SourceFollower);
	
	sendComplexOpen( Serial_DesktopProtocol::Id_SourceFollower);

	sendSetupSourceTupel( Serial_DesktopProtocol::Id_SourceFollowerTarget,
						  &( SourceFollower.Target));
	sendSetupSourceTupel( Serial_DesktopProtocol::Id_SourceFollowerStep, &( SourceFollower.Step));

	sendInteger( Serial_DesktopProtocol::Id_SourceFollowerTrigger,
				 SourceFollower.TriggerSetupSourceId);
	sendInteger( Serial_DesktopProtocol::Id_SourceFollowerTriggerHighLimit,
				 SourceFollower.TriggerHighLimit);
	sendInteger( Serial_DesktopProtocol::Id_SourceFollowerTriggerLowLimit,
				 SourceFollower.TriggerLowLimit);
	
	sendComplexClose();
}

void Serial_DesktopConnection::sendSourceInput( uint8_t SourceId)
{
	Setup_Source_Input SourceInput;

	GLOBAL.SetupService.GetSourceInput( SourceId, &SourceInput);

	switch( SourceInput.Type)
	{
		case SSIT_Analog :
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_SourceInputAnalog);

				sendInteger( Serial_DesktopProtocol::Id_SourceInputAnalogInput,
							 SourceInput.InputIdA);

			sendComplexClose();
		}
		break;

		case SSIT_Button :
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_SourceInputButton);

				sendInteger( Serial_DesktopProtocol::Id_SourceInputButtonInput,
							 SourceInput.InputIdA);

				sendBool( Serial_DesktopProtocol::Id_SourceInputButtonStore, SourceInput.Store);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputButtonInit, SourceInput.Init);
				sendBool( Serial_DesktopProtocol::Id_SourceInputButtonToggle, SourceInput.Toggle);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputButtonTop, SourceInput.Top);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputButtonBottom,
							 SourceInput.Bottom);

			sendComplexClose();
		}
		break;
			
		case SSIT_Switch :
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_SourceInputSwitch);

				sendInteger( Serial_DesktopProtocol::Id_SourceInputSwitchLowInput,
							 SourceInput.InputIdA);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputSwitchHighInput,
							 SourceInput.InputIdB);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputSwitchTop, SourceInput.Top);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputSwitchBottom,
							 SourceInput.Bottom);

			sendComplexClose();
		}
		break;
			
		case SSIT_Ticker :
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_SourceInputTicker);

				sendInteger( Serial_DesktopProtocol::Id_SourceInputTickerLowInput,
							 SourceInput.InputIdA);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputTickerHighInput,
							 SourceInput.InputIdB);

				sendBool( Serial_DesktopProtocol::Id_SourceInputTickerStore, SourceInput.Store);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputTickerInit, SourceInput.Init);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputTickerStep, SourceInput.Step);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputTickerTop, SourceInput.Top);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputTickerBottom,
							 SourceInput.Bottom);

			sendComplexClose();
		}
		break;
			
		case SSIT_Rotary :
		{
			sendComplexOpen( Serial_DesktopProtocol::Id_SourceInputRotary);

				sendInteger( Serial_DesktopProtocol::Id_SourceInputRotaryAInput,
							 SourceInput.InputIdA);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputRotaryBInput,
							 SourceInput.InputIdB);

				sendBool( Serial_DesktopProtocol::Id_SourceInputRotaryStore, SourceInput.Store);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputRotaryInit, SourceInput.Init);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputRotaryStep, SourceInput.Step);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputRotaryTop, SourceInput.Top);
				sendInteger( Serial_DesktopProtocol::Id_SourceInputRotaryBottom,
							 SourceInput.Bottom);

			sendComplexClose();
		}
		break;
	}
}

void Serial_DesktopConnection::sendSourceMap( uint8_t SourceId)
{
	Setup_Source_Map SourceMap;
	
	GLOBAL.SetupService.GetSourceMap( SourceId, &SourceMap);

	sendComplexOpen( Serial_DesktopProtocol::Id_SourceMap);

		sendSetupSourceTupel( Serial_DesktopProtocol::Id_SourceMapInput, &( SourceMap.Input));
	//											sendInteger( Serial_DesktopProtocol::Id_SourceMapPoints,
	//													   SourceMap.Points);

		sendComplexOpen( Serial_DesktopProtocol::Id_SourceMapPoints);

			for( uint8_t PointId = 0; PointId < SETUP_SOURCE_MAP_POINTS; PointId++)
			{
				sendSetupSourceTupel( Serial_DesktopProtocol::Id_SourceMapPoint,
									  &( SourceMap.Point[ PointId]));
			}

		sendComplexClose();

	sendComplexClose();
}

void Serial_DesktopConnection::sendSourceMix( uint8_t SourceId)
{
	Setup_Source_Mix SourceMix;
	
	GLOBAL.SetupService.GetSourceMix( SourceId, &SourceMix);

	sendComplexOpen( Serial_DesktopProtocol::Id_SourceMix);
	
		sendComplexOpen( Serial_DesktopProtocol::Id_SourceMixInputs);

			for( uint8_t InputId = 0; InputId < SETUP_SOURCE_MIX_INPUTS; InputId++)
			{
				sendSetupSourceTupel( Serial_DesktopProtocol::Id_SourceMixInput,
									  &( SourceMix.Input[ InputId]));
			}

		sendComplexClose();

	sendComplexClose();
}

void Serial_DesktopConnection::sendSourceStore( uint8_t SourceId)
{
	Setup_Source_Store SourceStore;

	GLOBAL.SetupService.GetSourceStore( SourceId, &SourceStore);

	sendComplexOpen( Serial_DesktopProtocol::Id_SourceStore);

		sendInteger( Serial_DesktopProtocol::Id_SourceStoreInput, SourceStore.InputSetupSourceId);
		sendInteger( Serial_DesktopProtocol::Id_SourceStoreInit, SourceStore.Init);

	sendComplexClose();
}

void Serial_DesktopConnection::sendSourceTimer( uint8_t SourceId)
{
	Setup_Source_Timer SourceTimer;

	GLOBAL.SetupService.GetSourceTimer( SourceId, &SourceTimer);

	sendComplexOpen( Serial_DesktopProtocol::Id_SourceTimer);

	sendInteger( Serial_DesktopProtocol::Id_SourceTimerInit, SourceTimer.InitTime);
	sendBool( Serial_DesktopProtocol::Id_SourceTimerStore, SourceTimer.Store);

	sendComplexClose();
}

void Serial_DesktopConnection::receiveConfiguration( void)
{
	sendState( Serial_DesktopProtocol::Id_Ok);

	uint8_t Type = receiveByte();
	uint8_t Id = receiveByte();

	switch( Type)
	{
		case SERIAL_Protocol::T_State : break;

		case SERIAL_Protocol::T_Value : consumeValue(); break;

		case SERIAL_Protocol::T_Complex :
		{
			switch( Id)
			{
				case Serial_DesktopProtocol::Id_Configuration :
				{
					bool Loop = true;

					while( Loop)
					{
						Type = receiveByte();

						switch( Type)
						{
							case SERIAL_Protocol::T_ComplexEnd :
							{
								Loop = false;
							}
							break;

							case SERIAL_Protocol::T_Value :
							{
								Id = receiveByte();

								receiveValue( stringBuffer, SERIAL_STRING_SIZE);

								switch( Id)
								{
									case Serial_DesktopProtocol::Id_Owner :
									{
										GLOBAL.SetupService.SetOwner( stringBuffer);
									}
									break;

									case Serial_DesktopProtocol::Id_SetupBlankTime :
									{
										GLOBAL.SetupService.SetSetupBlankTime( atol( stringBuffer));
									}
									break;

									case Serial_DesktopProtocol::Id_StatusBlankTime :
									{
										GLOBAL.SetupService.SetStatusBlankTime( atol( stringBuffer));
									}
									break;

									case Serial_DesktopProtocol::Id_SetupBacklight :
									{
										GLOBAL.SetupService.SetSetupBacklight( atol( stringBuffer));
									}
									break;

									case Serial_DesktopProtocol::Id_StatusBacklight :
									{
										GLOBAL.SetupService.SetStatusBacklight( atol( stringBuffer));
									}
									break;

									case Serial_DesktopProtocol::Id_StatusContrast :
									{
										GLOBAL.SetupService.SetStatusContrast( atol( stringBuffer));
									}
									break;

									case Serial_DesktopProtocol::Id_ShowIntro :
									{
										GLOBAL.SetupService.SetShowIntro(
											UTILITY::String2Boolean( stringBuffer));
									}
									break;

									case Serial_DesktopProtocol::Id_SelectedModelId :
									{
										GLOBAL.SetupService.SetSelectedModelId( atol( stringBuffer));
									}
									break;

									case Serial_DesktopProtocol::Id_PPMInverted :
									{
										GLOBAL.SetupService.SetPPMInverted( 
											UTILITY::String2Boolean( stringBuffer));
									}
									break;

									case Serial_DesktopProtocol::Id_PPMCenter :
									{
										GLOBAL.SetupService.SetPPMCenter( atol( stringBuffer));
									}
									break;

									default : break;
								}
							}
							break;

							case SERIAL_Protocol::T_Complex :
							{
								Id = receiveByte();

								switch( Id)
								{
									case Serial_DesktopProtocol::Id_Calibrations :
									{
										receiveCalibrations();
									}
									break;

									case Serial_DesktopProtocol::Id_ChannelMappings :
									{
										receiveChannelMappings();
									}
									break;
										
									case Serial_DesktopProtocol::Id_Battery :
									{
										receiveBattery();
									}
									break;

									case Serial_DesktopProtocol::Id_Models :
									{
										receiveModels();
									}
									break;

									case Serial_DesktopProtocol::Id_Types :
									{
										receiveTypes();
									}
									break;

									case Serial_DesktopProtocol::Id_Sources :
									{
										receiveSources();
									}
									break;

									default : consumeComplex(); break;
								}
							}
							break;

							default : consumeItem( Type); break;
						}
					}
				}
				break;

				default : consumeComplex(); break;
			}
		}
		break;
	}
}

void Serial_DesktopConnection::receiveCalibrations( void)
{
	uint8_t CalibrationId = 0;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_Calibration :
					{
						receiveCalibration( CalibrationId);

						CalibrationId++;
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveCalibration( uint8_t CalibrationId)
{
	Setup_Calibration Calibration;

	GLOBAL.SetupService.GetCalibration( CalibrationId, &Calibration);	

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_CalibrationHigh :
					{
						Calibration.Value[ SETUP_CALIBRATION_HIGH] = atol( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_CalibrationCenter :
					{
						Calibration.Value[ SETUP_CALIBRATION_CENTER] = atol( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_CalibrationLow :
					{
						Calibration.Value[ SETUP_CALIBRATION_LOW] = atol( stringBuffer);
					}
					break;
						
					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetCalibration( CalibrationId, &Calibration);	
}

void Serial_DesktopConnection::receiveChannelMappings( void)
{
	uint8_t ChannelId = 0;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_ChannelMapping :
					{
						GLOBAL.SetupService.SetChannelMapping( ChannelId, atol( stringBuffer));

						ChannelId++;
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveBattery( void)
{
	Setup_Battery Battery;

	GLOBAL.SetupService.GetBattery( &Battery);	

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);
				
				switch( Id)
				{
					case Serial_DesktopProtocol::Id_BatteryWarnLowVoltage :
					{
						Battery.WarnLowVoltage = atol( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_BatteryWarnCriticalVoltage :
					{
						Battery.WarnCriticalVoltage = atol( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_BatteryMinimumVoltage :
					{
						Battery.MinimumVoltage = atol( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_BatteryMaximumVoltage :
					{
						Battery.MaximumVoltage = atol( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_BatteryCalibrationVoltage :
					{
						Battery.CalibrationVoltage = atol( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetBattery( &Battery);	
}

void Serial_DesktopConnection::receiveModels( void)
{
	uint8_t ModelId = 0;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_Model :
					{
						receiveModel( ModelId);
						
						ModelId++;
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveModel( uint8_t ModelId)
{
	// Clear model for the case it has been deleted.
	GLOBAL.SetupService.SetModelState( ModelId, Setup_Service::MS_Empty);
	
	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_ModelState :
					{
						Setup_Service::ModelState Value =
							( Setup_Service::ModelState) atoi( stringBuffer);
						GLOBAL.SetupService.SetModelState( ModelId, Value);
					}
					break;

					case Serial_DesktopProtocol::Id_ModelName :
					{
						GLOBAL.SetupService.SetModelName( ModelId, stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_ModelTypeId :
					{
						GLOBAL.SetupService.SetSelectedTypeId( ModelId, atoi( stringBuffer));
					}
					break;

					case Serial_DesktopProtocol::Id_StatusTime :
					{
						GLOBAL.SetupService.SetStatusTimeId( ModelId, atoi( stringBuffer));
					}
					break;

					default : break;
				}
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_Channels :
					{
						receiveChannels( ModelId);
					}
					break;

					case Serial_DesktopProtocol::Id_StatusSources :
					{
						receiveStatusSources( ModelId);
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveChannels( uint8_t ModelId)
{
	uint8_t ChannelId = 0;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_Channel :
					{
						receiveChannel( ModelId, ChannelId);

						ChannelId++;
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveChannel( uint8_t ModelId, uint8_t ChannelId)
{
	Setup_Channel Channel;

	GLOBAL.SetupService.GetChannel( ModelId, ChannelId, &Channel);

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_ChannelName :
					{
						GLOBAL.SetupService.SetChannelName( ModelId, ChannelId, stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_ChannelReverse :
					{
						Channel.Reverse = UTILITY::String2Boolean( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_ChannelInput :
					{
						receiveSetupSourceTupel( &( Channel.Input));
					}
					break;

					case Serial_DesktopProtocol::Id_ChannelTrim :
					{
						receiveSetupSourceTupel( &( Channel.Trim));
					}
					break;

					case Serial_DesktopProtocol::Id_ChannelLimit :
					{
						receiveSetupSourceTupel( &( Channel.Limit));
					}
					break;

					case Serial_DesktopProtocol::Id_ChannelPoints :
					{
						receiveChannelPoints( Channel.Point, SETUP_CHANNEL_POINTS,
											  Serial_DesktopProtocol::Id_ChannelPoint);
					}
					break;
						
					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetChannel( ModelId, ChannelId, &Channel);
}

void Serial_DesktopConnection::receiveChannelPoints( int16_t* Values, uint8_t NumberOfValues,
													 uint16_t ValueId)
{
	uint8_t PointId = 0;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				if( Id == ValueId)
				{
					// Don't read to many.
					if( PointId < NumberOfValues)
					{
						Values[ PointId++] =  atol( stringBuffer);
					}
					else
					{
						// Skip
					}
				}
				else
				{
					// Skip
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveStatusSources( uint8_t ModelId)
{
	uint8_t SourceId = 0;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_StatusSource :
					{
						GLOBAL.SetupService.SetStatusSourceId( ModelId, SourceId,
															   atol( stringBuffer));

						SourceId++;
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveSetupSourceTupels( Setup_Source_Tupel* Values,
														 uint8_t NumberOfValues, uint16_t ValueId)
{
	uint8_t PointId = 0;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				if( Id == ValueId)
				{
					// Don't read to many.
					if( PointId < NumberOfValues)
					{
						receiveSetupSourceTupel( &Values[ PointId]);
					}
					else
					{
						consumeComplex();
					}
					
					PointId++;
				}
				else
				{
					consumeComplex();
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveSetupSourceTupel( Setup_Source_Tupel* Value)
{
	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceTupelSourceId :
					{
						Value->SetupSourceId = atol( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceTupelVolume :
					{
						Value->Volume = atol( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveTypes( void)
{
	uint8_t TypeId = SETUP_MODEL_TYPE_START;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_Type :
					{
						receiveType( TypeId);
						
						TypeId++;
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveType( uint8_t TypeId)
{
	// Clear type for the case it has been deleted.
	GLOBAL.SetupService.SetTypeState( TypeId, Setup_Service::TS_Empty);

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_TypeState :
					{
						Setup_Service::TypeState Value =
							( Setup_Service::TypeState) atoi( stringBuffer);
						GLOBAL.SetupService.SetTypeState( TypeId, Value);
					}
					break;

					case Serial_DesktopProtocol::Id_TypeName :
					{
						GLOBAL.SetupService.SetTypeName( TypeId, stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveSources( void)
{
	uint16_t SourceId = 0;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_Source :
					{
						receiveSource( SourceId);

						SourceId++;
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveSource( uint16_t SourceId)
{
	// Clear source for the case it has been deleted.
	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Empty);

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceName :
					{
						GLOBAL.SetupService.SetSourceName( SourceId, stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceModelId :
					{
						GLOBAL.SetupService.SetSourceModelId( SourceId, atoi( stringBuffer));
					}
					break;

					default : break;
				}
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceFollower :
					{
						receiveSourceFollower( SourceId);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputAnalog :
					{
						receiveSourceInputAnalog( SourceId);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputButton :
					{
						receiveSourceInputButton( SourceId);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputSwitch :
					{
						receiveSourceInputSwitch( SourceId);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputTicker :
					{
						receiveSourceInputTicker( SourceId);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputRotary :
					{
						receiveSourceInputRotary( SourceId);
					}

					case Serial_DesktopProtocol::Id_SourceMap :
					{
						receiveSourceMap( SourceId);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceMix :
					{
						receiveSourceMix( SourceId);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceStore :
					{
						receiveSourceStore( SourceId);
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}
}

void Serial_DesktopConnection::receiveSourceFollower( uint16_t SourceId)
{
	Setup_Source_Follower SourceFollower;

	GLOBAL.SetupService.GetSourceFollower( SourceId, &SourceFollower);

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;
				
			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceFollowerTrigger :
					{
						SourceFollower.TriggerSetupSourceId = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceFollowerTriggerHighLimit :
					{
						SourceFollower.TriggerHighLimit = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceFollowerTriggerLowLimit :
					{
						SourceFollower.TriggerLowLimit = atoi( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceFollowerTarget :
					{
						receiveSetupSourceTupel( &( SourceFollower.Target));
					}
					break;

					case Serial_DesktopProtocol::Id_SourceFollowerStep :
					{
						receiveSetupSourceTupel( &( SourceFollower.Step));
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Follower);
	GLOBAL.SetupService.SetSourceFollower( SourceId, &SourceFollower);
}

void Serial_DesktopConnection::receiveSourceInputAnalog( uint16_t SourceId)
{
	Setup_Source_Input SourceInput;

	GLOBAL.SetupService.GetSourceInput( SourceId, &SourceInput);

	SourceInput.Type = SSIT_Analog;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceInputAnalogInput :
					{
						SourceInput.InputIdA = atoi( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Input);
	GLOBAL.SetupService.SetSourceInput( SourceId, &SourceInput);
}

void Serial_DesktopConnection::receiveSourceInputButton( uint16_t SourceId)
{
	Setup_Source_Input SourceInput;

	GLOBAL.SetupService.GetSourceInput( SourceId, &SourceInput);

	SourceInput.Type = SSIT_Button;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceInputButtonInput :
					{
						SourceInput.InputIdA = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputButtonStore :
					{
						SourceInput.Store = UTILITY::String2Boolean( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputButtonInit :
					{
						SourceInput.Init = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputButtonToggle :
					{
						SourceInput.Toggle = UTILITY::String2Boolean( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputButtonTop :
					{
						SourceInput.Top = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputButtonBottom :
					{
						SourceInput.Bottom = atoi( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Input);
	GLOBAL.SetupService.SetSourceInput( SourceId, &SourceInput);
}

void Serial_DesktopConnection::receiveSourceInputSwitch( uint16_t SourceId)
{
	Setup_Source_Input SourceInput;

	GLOBAL.SetupService.GetSourceInput( SourceId, &SourceInput);

	SourceInput.Type = SSIT_Switch;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceInputSwitchLowInput :
					{
						SourceInput.InputIdA = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputSwitchHighInput :
					{
						SourceInput.InputIdB = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputSwitchTop :
					{
						SourceInput.Top = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputSwitchBottom :
					{
						SourceInput.Bottom = atoi( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Input);
	GLOBAL.SetupService.SetSourceInput( SourceId, &SourceInput);
}

void Serial_DesktopConnection::receiveSourceInputTicker( uint16_t SourceId)
{
	Setup_Source_Input SourceInput;

	GLOBAL.SetupService.GetSourceInput( SourceId, &SourceInput);

	SourceInput.Type = SSIT_Ticker;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);
				
				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceInputTickerLowInput :
					{
						SourceInput.InputIdA = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputTickerHighInput :
					{
						SourceInput.InputIdB = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputTickerStore :
					{
						SourceInput.Store = UTILITY::String2Boolean( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputTickerInit :
					{
						SourceInput.Init = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputTickerStep :
					{
						SourceInput.Step = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputTickerTop :
					{
						SourceInput.Top = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputTickerBottom :
					{
						SourceInput.Bottom = atoi( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Input);
	GLOBAL.SetupService.SetSourceInput( SourceId, &SourceInput);
}

void Serial_DesktopConnection::receiveSourceInputRotary( uint16_t SourceId)
{
	Setup_Source_Input SourceInput;

	GLOBAL.SetupService.GetSourceInput( SourceId, &SourceInput);

	SourceInput.Type = SSIT_Rotary;

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);
				
				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceInputRotaryAInput :
					{
						SourceInput.InputIdA = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputRotaryBInput :
					{
						SourceInput.InputIdB = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputRotaryStore :
					{
						SourceInput.Store = UTILITY::String2Boolean( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputRotaryInit :
					{
						SourceInput.Init = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputRotaryStep :
					{
						SourceInput.Step = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputRotaryTop :
					{
						SourceInput.Top = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceInputRotaryBottom :
					{
						SourceInput.Bottom = atoi( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Input);
	GLOBAL.SetupService.SetSourceInput( SourceId, &SourceInput);
}

void Serial_DesktopConnection::receiveSourceMap( uint16_t SourceId)
{
	Setup_Source_Map SourceMap;

	GLOBAL.SetupService.GetSourceMap( SourceId, &SourceMap);

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceMapInput :
					{
						receiveSetupSourceTupel( &( SourceMap.Input));
					}
					break;

					case Serial_DesktopProtocol::Id_SourceMapPoints :
					{
						receiveSetupSourceTupels( SourceMap.Point, SETUP_SOURCE_MAP_POINTS,
												  Serial_DesktopProtocol::Id_SourceMapPoint);
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Map);
	GLOBAL.SetupService.SetSourceMap( SourceId, &SourceMap);
}

void Serial_DesktopConnection::receiveSourceMix( uint16_t SourceId)
{
	Setup_Source_Mix SourceMix;

	GLOBAL.SetupService.GetSourceMix( SourceId, &SourceMix);

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Complex :
			{
				uint8_t Id = receiveByte();

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceMixInputs :
					{
						receiveSetupSourceTupels( SourceMix.Input, SETUP_SOURCE_MIX_INPUTS,
												  Serial_DesktopProtocol::Id_SourceMixInput);
					}
					break;

					default : consumeComplex(); break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Mix);
	GLOBAL.SetupService.SetSourceMix( SourceId, &SourceMix);
}

void Serial_DesktopConnection::receiveSourceStore( uint16_t SourceId)
{
	Setup_Source_Store SourceStore;

	GLOBAL.SetupService.GetSourceStore( SourceId, &SourceStore);

	bool Loop = true;

	while( Loop)
	{
		uint8_t Type = receiveByte();

		switch( Type)
		{
			case SERIAL_Protocol::T_ComplexEnd :
			{
				Loop = false;
			}
			break;

			case SERIAL_Protocol::T_Value :
			{
				uint8_t Id = receiveByte();

				receiveValue( stringBuffer, SERIAL_STRING_SIZE);

				switch( Id)
				{
					case Serial_DesktopProtocol::Id_SourceStoreInput :
					{
						SourceStore.InputSetupSourceId = atoi( stringBuffer);
					}
					break;

					case Serial_DesktopProtocol::Id_SourceStoreInit :
					{
						SourceStore.Init = atoi( stringBuffer);
					}
					break;

					default : break;
				}
			}
			break;

			default : consumeItem( Type); break;
		}
	}

	GLOBAL.SetupService.SetSourceType( SourceId, Signal_Source_Source::T_Store);
	GLOBAL.SetupService.SetSourceStore( SourceId, &SourceStore);
}

void Serial_DesktopConnection::DoSerialConnection( void)
{
	while( true)
	{
		// Receive command.
		if( ReadyToReceive())
		{
			uint8_t Type = receiveByte();

			switch( Type)
			{
				case SERIAL_Protocol::T_Command :
				{
					uint8_t Command = receiveByte();
					
					switch( Command)
					{
						case Serial_DesktopProtocol::Id_Ping :
						{
							sendState( Serial_DesktopProtocol::Id_Ok);
						}
						break;

						case Serial_DesktopProtocol::Id_ReadConfiguration :
						{
							sendConfiguration();
						}
						break;

						case Serial_DesktopProtocol::Id_WriteConfiguration :
						{
							receiveConfiguration();

							GLOBAL.SetupDisplay.Clear( LCD_65K_RGB::Black);
							UTILITY::HardReset();
							// No comin' back.
						}
						break;

						default :
						{
							sendState( Serial_DesktopProtocol::Id_Error);
						}
						break;
					}
				}
				break;

				default :
				{
					sendState( Serial_DesktopProtocol::Id_Error);
				}
				break;
			}
		}

		UTILITY::Pause( 5);

		// Exit on button toggle.
		uint8_t RotaryButton;

		// Try rotary.
		GLOBAL.InputService.GetRotary( NULL, &RotaryButton, NULL);

		if( RotaryButton > 0)
		{
			break;
		}
	}
}
/*
void Serial_DesktopConnection::DoSerialConnectionTest( void)
{	
	char DataToSend = 'A';

	while( true)
	{
		// Send
		if( GLOBAL.ReadyToSend())
		{
			sendByte( DataToSend);

			GLOBAL.Lcd.PrintFormat( 0, 10, FONT::FID_Mini, LCD::White, LCD::Black,
			LCD::PO_Proportional, "%c", DataToSend);

			DataToSend++;

			if( DataToSend == ( 'Z' + 1))
			{
				DataToSend = 'A';
			}
		}

		// Receive
		if( readyToReceive())
		{
			char DataReceived = receiveByte();

			GLOBAL.Lcd.PrintFormat( 0, 20, FONT::FID_Mini, LCD::White, LCD::Black,
								  LCD::PO_Proportional, "%c", DataReceived);
		}

		// Exit on button to be toggle.
		uint8_t RotaryButton;

		// Try rotary.
		GLOBAL.InputService.GetRotary( NULL, &RotaryButton, NULL);

		if( RotaryButton > 0)
		{
			break;
		}
	}
}
*/
