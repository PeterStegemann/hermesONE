// Copyright 2009 Peter Stegemann

#ifndef INTERRUPT_SERVICE_H
#define INTERRUPT_SERVICE_H

#include "AVR/Components/Types.h"

class Interrupt_Service
{
	private:
		volatile uint16_t timeMillis;

	public:
		// Start processing loop.
		void Start( void);

		// This is for the interrupt, not for you.
		void Process( void);
};

#endif
