// Copyright 2013 Peter Stegemann

#ifndef SCREEN_SETUP_SOURCE_PROXY_H
#define SCREEN_SETUP_SOURCE_PROXY_H

#include "Base.h"
#include "GUI/Setup/Gauge.h"
#include "GUI/Setup/Label.h"
#include "GUI/Setup/TextInput.h"
#include "Setup/Source/Source.h"

class Screen_Setup_Source_Proxy : public Screen_Setup_Source_Base
{
	private:
		Signal_Source_Proxy* sourceProxy;

		GUI_Setup_Label slotLabel;
		uint8_t slot;

		virtual void display( void);
		virtual bool processMenu( DoMenuResult Result);

		static void updateSlot( void* Object, GUI_Setup_Label* Label, int8_t Value);

	public:
		Screen_Setup_Source_Proxy( uint8_t SignalSourceId);
};

#endif
